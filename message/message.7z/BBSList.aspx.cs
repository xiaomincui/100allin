﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class message_BBSList : System.Web.UI.Page
{
    // 设置每页显示的行数  
    int totalrowcount = 6;
    // 自动填充的行数
    int numcount = 0;

    protected void GridView4_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            // 计算自动填充的行数
            numcount++;
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            // 计算完毕，在此添加缺少的行
            int toleft = totalrowcount - numcount;


            for (int i = 0; i < toleft; i++)
            {

                GridViewRow row = new GridViewRow(-1, -1, DataControlRowType.EmptyDataRow, DataControlRowState.Normal);

                TableCell cell = new TableCell();
                cell.Text = "&nbsp;";
                row.Cells.Add(cell);

                Unit a = new Unit("30px");
                Unit b = new Unit("382px");
                row.Height = a;
                row.Width = b;

                Repeater4.Controls[0].Controls.AddAt(numcount + 1 + i, row);
            }
        }
    }





    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            LoadRecord(Repeater1, "1");
            LoadRecord(Repeater3, "3");
            LoadRecord(Repeater2, "2");
            LoadRecord(Repeater4, "4");
            LoadRecord(Repeater5, "5");
            //LoadRecord(Repeater6, "6");


            //Loadddllist();
        }
    }



    public void LoadRecord(Repeater g, string types)
    {

        data_conn cn = new data_conn();
        string sql;
        sql = "select top 6 id,title from TB_BBS where types=" + types + " ORDER BY TB_BBS.UpdateDate DESC,TB_BBS.id";
        DataSet ds = cn.mdb_ds(sql, "bbs1");
        g.DataSource = ds.Tables["bbs1"].DefaultView;
        g.DataBind();
        //g.Attributes.Add("bordercolor ", "#D3EBF3");
    }
}
