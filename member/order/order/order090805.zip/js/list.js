﻿function SendOrder1(c)
{
var delQus;
delQus=confirm('确认提交订单给对方');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnSendOrder1").click();
}	
}

function DelOrder1(c)
{
var delQus;
delQus=confirm('真的要删除这份订单吗？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnDelOrder1").click();
}	
}

function RecoverOrder10(c)
{
var delQus;
delQus=confirm('您要恢复这份订单吗？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnRecoverOrder1").click();
}
}

function AcceptOrder2(c)
{
var delQus;
delQus=confirm('您要接受这份订单吗？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnAcceptOrder1").click();
}	
}

function ShipperFinishOrder3(c)
{
var delQus;
delQus=confirm('确认完成出运？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnFinishOrderShipper1").click();
}	
}

function ForwardFinishOrder3(c)
{
var delQus;
delQus=confirm('同意完成出运？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnFinishOrderForward1").click();
}	
}

function ForwardFinishOrder4(c)
{
var delQus;
delQus=confirm('确认完成出运？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnFinishOrderForward2").click();
}	
}


function RejectOrderForward2(c)
{
var delQus;
delQus=confirm('不接受该订舱？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnRejectOrderForward").click();
}	
}

function RerejectOrderForward6(c)
{
var delQus;
delQus=confirm('重新接受该订舱？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnRerejectOrderForward").click();
}	
}

function CancelOrder2(c)
{
var delQus;
delQus=confirm('撤销该订舱？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnCancelOrder2").click();
}	
}

function CancelOrder3(c)
{
var delQus;
delQus=confirm('撤销该订舱？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnCancelOrder3").click();
}	
}

function CancelOrder4(c)
{
var delQus;
delQus=confirm('撤销该订舱？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnCancelOrder4").click();
}	
}

function CancelCancelOrder7(c)
{
var delQus;
delQus=confirm('取消撤销该订舱？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnCancelCancelOrder7").click();
}	
}

function CancelCancelOrder8(c)
{
var delQus;
delQus=confirm('取消撤销该订舱？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnCancelCancelOrder8").click();
}	
}

function CancelCancelOrder9(c)
{
var delQus;
delQus=confirm('取消撤销该订舱？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnCancelCancelOrder9").click();
}	
}

function RecoverOrder11(c)
{
var delQus;
delQus=confirm('您要恢复这份订单吗？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnRecoverOrder11").click();
}
}

function RecoverOrder12(c)
{
var delQus;
delQus=confirm('您要恢复这份订单吗？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnRecoverOrder12").click();
}
}

function RecoverOrder13(c)
{
var delQus;
delQus=confirm('您要恢复这份订单吗？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnRecoverOrder13").click();
}
}

function RecoverOrder14(c)
{
var delQus;
delQus=confirm('您要恢复这份订单吗？');
if (delQus==true){
    document.getElementById("txtCode").value = c;
	document.getElementById("btnRecoverOrder14").click();
}
}