
function gotoRepaste()
{var to_url="/!repaste/repaste.php";parent.window.location.href=to_url;}
function gotoFriend()
{var to_url="/!repaste/friend.php";parent.window.location.href=to_url;}
function showOtherUrlView(surl,viewname)
{var s1="http://localhost";var s2="http://localhost";if(surl.substr(0,s1.length)==s1||surl.substr(0,s2.length)==s2)
{var to_url=surl;window.open(to_url);}
else
{s(viewname);}}
function gotoDetail(uid,urpid)
{var to_url="/!repaste/detail.php?uid="+uid+"&urpid="+urpid+'&rand='+Math.random();parent.window.location.href=to_url;}
function gotoIndex(uid)
{var to_url="/!repaste/index.php?uid="+uid;parent.window.location.href=to_url;}
function repasteVote(uid,urpid,verify,answernum,hasvoted,suid,surpid)
{if(hasvoted==1)
{alert("每人只能表达一次互动观点。你已经表达过了！");return;}
var to_url="/repaste/vote_submit.php?urpid="+urpid+"&verify="+verify+"&voteuid="+uid+"&answernum="+answernum+"&suid="+suid+"&surpid="+surpid;parent.window.location.href=to_url;}
function showAddViewpointDlg(vtype,verify)
{openWindow('/repaste/add_viewpoint_dialog.php?vtype='+vtype+'&do=start&verify='+verify,330,180,'转帖');}
function showSetPrivacyDlg(vtype,verify,rpid)
{openWindow('/repaste/set_privacy_dialog.php?vtype='+vtype+'&do=start&verify='+verify+'&rpid='+rpid,330,278,'转帖');}
function showNotifyDlg(verify,urpid,rpid)
{openWindow('/repaste/notify_friend_dialog.php?urpid='+urpid+'&do=start&verify='+verify+'&rpid='+rpid,400,225,'转帖');}
function gotoRepastePhotoView(uid,urpid,pid)
{var showexif=0;if($("exif")&&$("exif").style.display==''){showexif=1;}
var to_url="/!repaste/photo_view.php?urpid="+urpid+"&uid="+uid+"&pid="+pid+"&showexif="+showexif;parent.window.location.href=to_url;return false;}
function delRepaste(urpid,verify)
{if(confirm("你确定要删除该转帖内容吗?"))
{var to_url="/repaste/del_submit.php?urpid="+urpid+"&verify="+verify;parent.window.location.href=to_url;}}
var otherfriend_display=false;function viewOtherFriendRepaste()
{$('xx_sh').innerHTML='<img src="http://img1.kaixin001.com.cn/i/xx_xx1.gif" class="cp" onmouseover="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx2.gif\';" onmouseout="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx1.gif\';" alt="好友的真心话" />';$('fsg_nr').style.display="none";if(otherfriend_display==false)
{otherfriend_display=true;doAjaxOtherFriend();}
else if(otherfriend_display==true)
{otherfriend_display=false;$("otherfriendrepaste").style.display="none";}}
function doAjaxOtherFriend()
{var aid=1088;var appurl="/!repaste/index.php";var url="/interface/appfriend.php";var pars="aid="+aid;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){otherAjaxShow(req,appurl);}});}
function otherAjaxShow(req,appurl)
{eval("r="+req.responseText);var html='';for(var i=0;i<r.length;i++)
{html+='<div class="bb1d8"><a style="cursor:pointer;" class="sl2_r" href="'+appurl+'?uid='+r[i].uid+'"><div class="l" style="width:5em;">'+r[i].name+'</div><div class="l" style="width:3em;">'+'('+r[i].index_num+')</div><div class="l" style="width:2em;">'+'&gt;&gt;</div><div class="c"></div></a>'+'</div>';}
if(r.length==0)
{html+='<div class="p5 c9">你的好友还没有添加过该组件</div>';}
$("NM_lis").innerHTML=html;$("otherfriendrepaste").style.display="block";}
function f2_afterseluid(uid)
{gotoUser(uid);}
function fs2_superOnclick_repaste()
{otherfriend_display=false;$("otherfriendrepaste").style.display="none";fs2_superOnclick();}
function fs2_viewAllfriend_repaste()
{otherfriend_display=false;$("otherfriendrepaste").style.display="none";fs2_viewAllfriend();}
function close_otherfriend()
{otherfriend_display=false;$("otherfriendrepaste").style.display="none";}
function gotoUser(uid)
{var url="/repaste/check.php";var pars="verify="+g_verify+"&fuid="+uid;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){gotouserAjaxShow(req);}});}
function gotouserAjaxShow(req)
{eval("r="+req.responseText);if(r.appinstall==1)
{window.location.href="/!repaste/index.php?uid="+r.uid;}
else
{alert(r.real_name+"还没有添加此组件！");}}
var g_repaste_uinfo={};function repaste_showComment(uid,urpid,start)
{if(typeof g_repaste_uinfo[uid]!="undefined")
{repaste_showComment2(uid,urpid,start);}
else
{var url="/interface/user.php";var pars="uid="+uid;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){repaste_AjaxShow(req,uid,urpid,start);}});}}
function repaste_AjaxShow(req,uid,urpid,start)
{eval("r="+req.responseText);g_repaste_uinfo[uid]=r;repaste_showComment2(uid,urpid,start);}
function repaste_showComment2(uid,urpid,start)
{if(g_repaste_uinfo[uid].commentright==-2)
{alert(g_repaste_uinfo[uid].real_name+"关闭评论功能");return;}
if(g_repaste_uinfo[uid].commentright==-1)
{alert("仅"+g_repaste_uinfo[uid].real_name+"的好友才能评论");return;}
refresh("/!repaste/detail.php?uid="+uid+"&urpid="+urpid+"&start"+start+"&_lgmode=pri"+"#anchorcomment");}
function refresh(url)
{if(typeof(url)=="undefined")
{url=window.location.href;while(url.substr(url.length-1,1)=="#")
{url=url.substr(0,url.length-1);}
var lastpos=url.lastIndexOf("&_lgmode=pri");if(url.substr(lastpos,12)=="&_lgmode=pri")
{window.location.href=url;}
else
{window.location.href=url+'&_lgmode=pri';}}
else
{window.location.href=url;}}