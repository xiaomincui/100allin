

var friendSuggestSingleInputRegistry={inputObjects:{},add:function(id,obj_parent,pars,select_callback){var obj=new FriendSuggestSingleInput(id,obj_parent,select_callback);obj.setSuggestAjaxParams(pars);if(friendSuggestSingleInputRegistry.inputObjects[id]){delete friendSuggestSingleInputRegistry.inputObjects[id];}
friendSuggestSingleInputRegistry.inputObjects[id]=obj;return obj;},get:function(id){if(friendSuggestSingleInputRegistry.inputObjects[id]){return friendSuggestSingleInputRegistry.inputObjects[id];}
return null;}};function addFriendSuggest(id,obj_parent,pars,select_callback){return friendSuggestSingleInputRegistry.add(id,obj_parent,pars,select_callback);}
function FriendSuggestSingleInput(id,obj_parent,select_callback)
{this.id=id;this.inputid=id+'input';this.word1='请输入好友姓名(支持拼音首字母输入)';this.word2='姓名不在好友列表, 请重新输入';this.frienddata=[];this.seluid=0;this.pars='';this.usersel_callback=select_callback;this.inner_suggest=this.id+"_suggest";this.inner_empty_suggest=this.id+"_emptysuggest";this.parentObject=obj_parent;this.suggestUrl="/interface/suggestfriend.php";}
FriendSuggestSingleInput.prototype.setStringProperty=function(property,value){value=value.strip();if(value!=''&&property in this){this[property]=value;}};FriendSuggestSingleInput.prototype.getSuggestion=function(){return this.seluid;};FriendSuggestSingleInput.prototype.setSuggestAjaxParams=function(pars){this.setStringProperty('pars',pars);};FriendSuggestSingleInput.prototype.setHint=function(hint_input,hint_noMatch){this.setStringProperty('word1',hint_input);this.setStringProperty('word2',hint_noMatch);};FriendSuggestSingleInput.prototype.getValue=function(){$(this.inputid).value=$(this.inputid).value.strip();return $(this.inputid).value;};FriendSuggestSingleInput.prototype.clear=function(){$(this.inputid).value='';};FriendSuggestSingleInput.prototype.setInputBox=function(){return;};FriendSuggestSingleInput.prototype.showInputBox=function(containerID){if(!$(containerID)){alert(containerID+' not exists');return;}
if($(this.inputid)){$(this.inputid).parentNode.removeChild($(this.inputid));}
$(containerID).innerHTML='<span class="it_s l"><input id="'+this.inputid+'" type="text" onblur="this.className=\'it1\'; friendSuggestSingleInputRegistry.get(\''+this.id+'\').inputOnblur();" onfocus="this.style.color=\'#333\';; friendSuggestSingleInputRegistry.get(\''+this.id+'\').inputOnfocus(event, this);" onkeyup="friendSuggestSingleInputRegistry.get(\''+this.id+'\').inputOnkeyup(event,this)" onkeydown="return friendSuggestSingleInputRegistry.get(\''+this.id+'\').inputOnkeydown(event ,this)" style="width: 80px; height: 14px;*height:12px;" class="it1" value=""/></span>\n';var obj=$(this.inputid);if($(this.inner_suggest)!=null)
{if($(this.inner_suggest).parentNode!=obj.parentNode)
{$(this.inner_suggest).parentNode.removeChild($(this.inner_suggest));}
else
{return;}}
var pos=getpos($(this.inputid));var html='<div id="'+this.inner_suggest+'" class="fsg_nl" style="display:none; border-width: 1px;  z-index: 99999; width:'+(pos.right-pos.left-5)+'px;"></div>\n';html+='<div  class="fsg_nl" id="'+this.inner_empty_suggest+'" style="display:none; border-width: 1px; background: rgb(238, 238, 238) none repeat scroll 0% 0%; z-index: 99999; display: none; font-size: 12px; padding-left: 7px; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; color: rgb(102, 102, 102); width:'+(pos.right-pos.left-9)+'px;"></div>';new Insertion.After(this.inputid,html);this.adjustPos();}
FriendSuggestSingleInput.prototype.adjustPos=function()
{var pos=getpos($(this.inputid));try
{$(this.inner_suggest).style.left=parseInt(pos.left)+"px";$(this.inner_suggest).style.top=parseInt(pos.bottom+1)+"px";$(this.inner_suggest).style.width=parseInt(pos.right-pos.left-5+12)+"px";$(this.inner_empty_suggest).style.left=parseInt(pos.left)+"px";$(this.inner_empty_suggest).style.top=parseInt(pos.bottom+1)+"px";$(this.inner_empty_suggest).style.width=parseInt(pos.right-pos.left-9+11)+"px";}
catch(e)
{}}
FriendSuggestSingleInput.prototype.focus=function(){$(this.inputid).focus();}
FriendSuggestSingleInput.prototype.inputOnfocus=function(event,thisobj)
{if(thisobj.value=="")
{this.adjustPos();$(this.inner_empty_suggest).innerHTML=this.word1;$(this.inner_empty_suggest).style.display="block";}}
FriendSuggestSingleInput.prototype.inputOnkeydown=function(evnt,thisobj)
{if(evnt.keyCode==13)
{return false;}
var hotinfo=this.getHotNum();var hotnum=hotinfo.hotnum;var num=hotinfo.totalnum;if(evnt.keyCode==40)
{if($(this.inner_suggest+"_0")!=null&&$(this.inner_suggest).style.display=="block")
{if(hotnum==-1)
{$(this.inner_suggest+"_0").className="sgt_on";}
else
{var nextnum=hotnum==num-1?0:hotnum+1;$(this.inner_suggest+"_"+hotnum).className="sgt_of";$(this.inner_suggest+"_"+nextnum).className="sgt_on";}
return false;}}
if(evnt.keyCode==38)
{if($(this.inner_suggest+"_0")!=null&&$(this.inner_suggest).style.display=="block")
{if(hotnum==-1)
{$(this.inner_suggest+"_"+(num-1)).className="sgt_on";}
else
{var prevnum=hotnum==0?num-1:hotnum-1;$(this.inner_suggest+"_"+hotnum).className="sgt_of";$(this.inner_suggest+"_"+prevnum).className="sgt_on";}}}}
FriendSuggestSingleInput.prototype.inputOnkeyup=function(evnt,thisobj)
{var hasthisperson=false;for(var i=0;i<this.frienddata.length;i++)
{if(this.frienddata[i].real_name==this.getValue())
{hasthisperson=true;}}
if(hasthisperson==false)
{this.seluid=0;}
if(evnt.keyCode==13)
{var hotinfo=this.getHotNum();var hotnum=hotinfo.hotnum;var totalnum=hotinfo.totalnum;if($(this.inner_suggest).style.display=="block"&&hotnum!=-1&&totalnum>0)
{$(this.inputid).value=this.frienddata[hotnum].real_name_unsafe;this.seluid=this.frienddata[hotnum].uid;if('function'==typeof(this.usersel_callback))
{this.usersel_callback(this.seluid,this.parentObject);}
$(this.inner_suggest).style.display="none";}}
else
{if(evnt.keyCode==38||evnt.keyCode==40)
{}
else
{if(evnt.keyCode!=37&&evnt.keyCode!=39){this.seluid=0;}
this.ajax_submit();}}}
FriendSuggestSingleInput.prototype.ajax_submit=function()
{var url=this.suggestUrl;var text=encodeURIComponent(this.getValue());var pars=this.getFixedAjaxParams()+"&text="+text;var obj=this;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:this.ajax_showFriends.bind(this)});}
FriendSuggestSingleInput.prototype.getFixedAjaxParams=function()
{return"pars="+this.pars+this.getDefaultAjaxParams();};FriendSuggestSingleInput.prototype.setDefaultAjaxParams=function(params)
{this.defaultAjaxParams=params;};FriendSuggestSingleInput.prototype.getDefaultAjaxParams=function()
{return(this.defaultAjaxParams!='')?'&'+this.defaultAjaxParams:'';};FriendSuggestSingleInput.prototype.setAjaxUrl=function(url)
{url=url.strip();if(url!='')
{this.suggestUrl=url;}}
FriendSuggestSingleInput.prototype.ajax_showFriends=function(req)
{var arr=eval(req.responseText);this.frienddata=arr;if(arr.length==0)
{$(this.inner_suggest).style.display="none";if(this.getValue()=="")
{$(this.inner_empty_suggest).innerHTML=this.word1;$(this.inner_empty_suggest).style.display="block";}
else
{if(this.word2=="")
{$(this.inner_empty_suggest).style.display="none";}
else
{$(this.inner_empty_suggest).innerHTML=this.word2;$(this.inner_empty_suggest).style.display="block";}}
return;}
var html="";for(var i=0;i<arr.length;i++)
{html+='<div id="'+this.inner_suggest+'_'+i+'" class="sgt_of" style="border-width: 1px 1px 1px 1px;font-size:12px;height:auto;width:'+(parseInt($(this.inner_suggest).style.width)-10)+'px;" onmouseover="friendSuggestSingleInputRegistry.get(\''+this.id+'\').suggestOnmouseover(this)" onmousedown="friendSuggestSingleInputRegistry.get(\''+this.id+'\').suggestOnmousedown(this);">'+arr[i].real_name+'&nbsp;&nbsp;'+this.logo20(arr[i])+'</div>';}
$(this.inner_suggest).innerHTML=html;$(this.inner_suggest).style.display="block";$(this.inner_empty_suggest).style.display="none";this.adjustPos();if($(this.inner_suggest+"_0")!=null&&$(this.inner_suggest).style.display=="block")
{$(this.inner_suggest+"_0").className="sgt_on";}}
FriendSuggestSingleInput.prototype.getHotNum=function()
{var obj;var num=0;var hotnum=-1;while((obj=$(this.inner_suggest+"_"+num))!=null)
{if(obj.className=="sgt_on")
{hotnum=num;}
num++;}
return{"hotnum":hotnum,"totalnum":num};};FriendSuggestSingleInput.prototype.suggestOnmouseover=function(thisobj)
{auto_id=thisobj.id.substr(this.id.length+1,thisobj.id.length-this.id.length-1);var arr=auto_id.split('_');var thisnum=arr[1];var obj;var num=0;while((obj=$(this.inner_suggest+"_"+num))!=null)
{if(thisnum==num)
{obj.className="sgt_on";}
else
{obj.className="sgt_of";}
num++;}};FriendSuggestSingleInput.prototype.suggestOnmousedown=function(thisobj)
{auto_id=thisobj.id.substr(this.id.length+1,thisobj.id.length-this.id.length-1);var arr=auto_id.split('_');var num=arr[1];$(this.inputid).value=this.frienddata[num].real_name_unsafe;this.seluid=this.frienddata[num].uid;if('function'==typeof(this.usersel_callback))
{this.usersel_callback(this.seluid,this.parentObject);}
$(this.inner_suggest).style.display="none";};FriendSuggestSingleInput.prototype.getUsername=function(uid){var obj=this.getInfoObject(uid);if(obj==null)return'';return obj.real_name;};FriendSuggestSingleInput.prototype.getLogo=function(uid){var obj=this.getInfoObject(uid);if(obj==null)return null;return obj.logo20;};FriendSuggestSingleInput.prototype.getInfoObject=function(uid){for(var i=0;i<this.frienddata.length;i++){if(this.frienddata[i].uid==uid){return this.frienddata[i];}}
return null;};FriendSuggestSingleInput.prototype.inputOnblur=function()
{if($j.browser.msie&&parent.document.getElementById('dialogBox')){if($(this.inputid).value!='')return;}
if($(this.inner_suggest))
{$(this.inner_suggest).style.display="none";}
$(this.inner_empty_suggest).style.display="none";};FriendSuggestSingleInput.prototype.logo20=function(obj)
{var logo20="";if(typeof obj.logo20!="undefined")
{logo20="<img src='"+obj.logo20+"'  align=absmiddle width=15  />";}
return logo20;};

KxRequire("css/suggestion.css");var friendSuggestSuperInputRegistry={inputObjects:{},add:function(id,maxcount,freeInputAllowed){var obj=new FriendSuggestSuperInput(id,maxcount,freeInputAllowed);if(friendSuggestSuperInputRegistry.inputObjects[id]){delete friendSuggestSuperInputRegistry.inputObjects[id];}
friendSuggestSuperInputRegistry.inputObjects[id]=obj;return obj;},get:function(id){if(friendSuggestSuperInputRegistry.inputObjects[id]){return friendSuggestSuperInputRegistry.inputObjects[id];}
return null;}};function initSuperFriendSuggest(id,maxcount){return friendSuggestSuperInputRegistry.add(id,maxcount,false);}
function FriendSuggestSuperInput(id,maxcount,freeInputAllowed){this.id=id;this.allowFreeInput(freeInputAllowed);this.data=[];this.isDirty=false;this.frienddata=[];this.needAlert=false;this.maxcount=maxcount;this.imgHost='img1.kaixin001.com.cn';this.superInputID=id+"superinput";this.imgSwitchBtn=id+"xx_sh";this.suggestViewContainer=id+"sug_area";this.activeInputID=id+"active";this.superInputSuggestID=id+"suggest";this.superInputEmptySuggestID=id+"emptysuggest";this.activeInputDivID=id+"activediv";this.suggestViewObject=null;this.suggestViewID=id+'view';this.update_callback=Prototype.emptyFunction;this.suggestpars='';this.width=420;this.paddingLeft=0;};FriendSuggestSuperInput.prototype.allowFreeInput=function(allowed){this.mode=(allowed?1:0);};FriendSuggestSuperInput.prototype.setPaddingLeft=function(width){this.paddingLeft=parseInt(width);};FriendSuggestSuperInput.prototype.setWidth=function(width){var w=parseInt(width);this.width=w;};FriendSuggestSuperInput.prototype.getWidth=function(){return this.width;};FriendSuggestSuperInput.prototype.setAjaxSuggestParameter=function(param){this.suggestpars=param;};FriendSuggestSuperInput.prototype.setMaxSelection=function(maxCount){if(maxCount<2){maxCount=1;}
this.maxcount=maxCount;this.suggestViewObject.setMaxSelection(maxCount);};FriendSuggestSuperInput.prototype.setUpdateCallback=function(func){if('function'==typeof(func)){this.update_callback=func;}else{this.update_callback=Prototype.emptyFunction;}};FriendSuggestSuperInput.prototype.show=function(containerID){this.outputHTML(containerID);this.update();this.initSuggestView();};FriendSuggestSuperInput.prototype.initSuggestView=function(){this.suggestViewObject=addFriendSuggestView(this.suggestViewID,this.maxcount,this,this.selectSuggestedFriends.bind(this),this.closeSuggestView.bind(this));this.suggestViewObject.outputHTML(this.suggestViewContainer);};FriendSuggestSuperInput.prototype.outputHTML=function(containerID){if(!$(containerID)){return;}
if(this.paddingLeft>0){paddingLeft='style="position:relative;padding-left: '+this.paddingLeft+'px;"';}else{paddingLeft='style="position:relative;"';}
var data={imgHost:this.imgHost,inputID:this.superInputID,imgSwitchBtnID:this.imgSwitchBtn,inputObj:'friendSuggestSuperInputRegistry.get(\''+this.id+'\')',viewContainer:this.suggestViewContainer,width:this.width,inputWidth:this.width-30,paddingLeft:paddingLeft};var html='<div class="l" #{paddingLeft} >\n';html+='<div class="it_s" style="width: #{width}px;">\n';html+='<div class="it1">\n';html+='<div id="#{inputID}" class="fsg21" style="cursor: text; height: 23px; width: #{inputWidth}px;">&nbsp;</div>\n';html+='<div class="fsg22">\n';html+='<div id="#{imgSwitchBtnID}" onclick="javascript:void(0);">\n';html+='<img class="cp" alt="选择好友" onmouseout="this.src=\'http://#{imgHost}/i/xx_xx1.gif\';" onmouseover="this.src=\'http://#{imgHost}/i/xx_xx2.gif\';" src="http://#{imgHost}/i/xx_xx1.gif"/>\n';html+='</div>\n';html+='</div>\n';html+='<div class="c"/>\n';html+='</div>\n';html+='</div>\n';html+='</div>\n';html+='<div class="c"></div>\n';html+='<!--suggestion图层-->\n';html+='<div id="#{viewContainer}" class="sug_area" style="width: 310px; display: none;"></div>\n';html+='<!--suggestion图层END-->\n';var tmpl=new Template(html);$(containerID).innerHTML=tmpl.evaluate(data);$(this.imgSwitchBtn).observe('click',this.toggleSuggestView.bind(this));$(this.superInputID).observe('click',this.superOnclick.bind(this));};FriendSuggestSuperInput.prototype.clear=function(){this.data.clear();this.frienddata.clear();this.suggestViewObject.clearPanelData();this.update();};FriendSuggestSuperInput.prototype.checkCount=function(v_alert)
{var c=0;var len=this.data.length;for(var i=0;i<len;i++)
{if(this.data[i].type=="static")
{c++;}}
if(c>this.maxcount)
{this.needAlert=v_alert;}
return c<=this.maxcount;};FriendSuggestSuperInput.prototype.hasActive=function()
{var len=this.data.length;for(var i=0;i<len;i++)
{if(this.data[i].type=="active")
{return i;}}
return-1;};FriendSuggestSuperInput.prototype.superOnclick=function()
{if(!this.closeSuggestView())
{return;}
if(this.hasActive()!=-1)
{if($(this.activeInputID).value!=""&&$(this.superInputSuggestID).style.display=="none")
{$(this.activeInputID).value="";}
$(this.activeInputID).focus();}
else
{this.data[this.data.length]={type:"active"};this.update();}
$(this.superInputID).parentNode.className="it2";};FriendSuggestSuperInput.prototype.activeFocus=function()
{for(var i=0;i<5;i++)
{if($(this.activeInputID))
{$(this.activeInputID).focus();}}};FriendSuggestSuperInput.prototype.update=function()
{var html="";var len=this.data.length;var htmlStaticEmptyUID='<div class="fsg_hy2" style="background:#fff9d7;">#{friendName}<a style="cursor:pointer;" onclick="javascript:#{inputObject}.inputDelete(#{dataIndex});"><img border="0" align="absmiddle" alt="移除" src="http://#{imgHost}/i2/del.gif"/></a></div>';var tmplStaticEmptyUID=new Template(htmlStaticEmptyUID);var htmlStaticValidUID='<div class="fsg_hy2">#{friendName}#{logo}&nbsp;&nbsp;<a style="cursor:pointer;" onclick="javascript:#{inputObject}.inputDelete(#{dataIndex});"><img border="0" align="absmiddle" alt="移除" src="http://#{imgHost}/i2/del.gif"/></a></div>';var tmplStaticValidUID=new Template(htmlStaticValidUID);var htmlActiveInput='<div class="fsg_id" id="#{inputDivID}" style="width:50px;"><input onkeypress="return #{inputObject}.inputOnkeypress(event)" onkeydown="return #{inputObject}.inputOnkeydown(event)" onkeyup="#{inputObject}.inputOnkeyup(event)" onblur="#{inputObject}.inputOnblur(this);" onfocus="#{inputObject}.inputOnfocus(this);" id="#{inputID}" name="#{inputID}" type="text" value="" class="fsg_it" size="2" Autocomplete="off" maxlength="50" /><div class="fsg_nl" id="#{inputSuggestID}" style="display:none;width:210px;"></div><div id="#{emptySuggestID}" class="fsg_nl" style="padding-left:7px;background:#eeeeee;color:#666666;width:220px;">请输入好友的姓名(开心网上姓名)</div></div></div>';var tmplActiveInput=new Template(htmlActiveInput);var showData={inputDivID:this.activeInputDivID,inputID:this.activeInputID,inputSuggestID:this.superInputSuggestID,emptySuggestID:this.superInputEmptySuggestID,inputObject:'friendSuggestSuperInputRegistry.get(\''+this.id+'\')',imgHost:this.imgHost,dataIndex:-1,friendName:'',logo:''};for(var i=0;i<len;i++)
{if(this.data[i].type=="static")
{showData.friendName=this.data[i].real_name;showData.dataIndex=i;if(this.data[i].uid=="0"||this.data[i].uid==0)
{html+=tmplStaticEmptyUID.evaluate(showData);}
else
{var logo=this.logo(this.data[i]);if(logo!="")
{showData.logo='&nbsp;&nbsp;'+logo;}else{showData.logo='';}
html+=tmplStaticValidUID.evaluate(showData);}}
else
{html+=tmplActiveInput.evaluate(showData);}}
$(this.superInputID).innerHTML=html==""?"&nbsp;":html;var childs=$(this.superInputID).childNodes;var mintop=1000000;var maxbottom=0;var len=childs.length;for(var i=0;i<len;i++)
{if(childs[i].className=="fsg_hy2"||childs[i].className=="fsg_id")
{var pos=Element.cumulativeOffset(childs[i]);var dim=Element.getDimensions(childs[i]);if(pos.top<mintop)
{mintop=pos.top;}
if(pos.top+dim.height>maxbottom)
{maxbottom=pos.top+dim.height;}}}
var height=maxbottom-mintop;height=height<23?23:height;$(this.superInputID).style.height=height+"px";this.activeFocus();if(this.needAlert)
{this.needAlert=false;alert("最多只能选择"+this.maxcount+"个用户！");}
this.update_callback();};FriendSuggestSuperInput.prototype.getHotNum=function()
{var obj;var num=0;var hotnum=-1;while((obj=$(this.superInputSuggestID+'_'+num))!=null)
{if(obj.className=="sgt_on")
{hotnum=num;}
num++;}
return{"hotnum":hotnum,"totalnum":num};};FriendSuggestSuperInput.prototype.inputOnblur=function(thisobj)
{if($(this.activeInputID)&&$(this.activeInputID).value!="")
{this.getUser();$(this.activeInputID).value="";$(this.activeInputID).blur();}
$(this.superInputID).parentNode.className="it1";$(this.superInputSuggestID).style.display="none";$(this.superInputEmptySuggestID).style.display="none";};FriendSuggestSuperInput.prototype.inputOnfocus=function(thisobj)
{if(this.data.length>this.maxcount)
{return false;}
if(this.data.length<=1&&thisobj.value=="")
{$(this.superInputEmptySuggestID).style.display="block";$(this.superInputEmptySuggestID).innerHTML="请输入好友的姓名(支持拼音首字母输入)";}
else
{$(this.superInputEmptySuggestID).style.display="none";}};FriendSuggestSuperInput.prototype.inputDelete=function(index)
{$(this.superInputID).blur();if(index<0||index>=this.data.length){return;}
this.data.splice(index,1);this.isDirty=true;this.update();return;};FriendSuggestSuperInput.prototype.inputOnkeypress=function(evnt)
{if(evnt.keyCode==13)
{if(typeof(evnt.preventDefault)=="function")
{evnt.preventDefault();}}
return true;};FriendSuggestSuperInput.prototype.inputOnkeydown=function(evnt)
{if(this.data.length>this.maxcount)
{if(evnt.preventDefault)
{evnt.preventDefault();}
else
{evnt.returnValue=0;}}
$(this.activeInputID).style.width=b_strlen($(this.activeInputID).value)*6+20+"px";if(evnt.keyCode==13)
{if($(this.activeInputID))
{$(this.activeInputID).value="";}
return false;}
var activenum=this.hasActive();if(evnt.keyCode==8&&this.data[activenum-1]&&$(this.activeInputID).value=="")
{if(typeof(evnt.preventDefault)=="function")
{evnt.preventDefault();}
var fs_data2=[];var j=0;var len=this.data.length;for(var i=0;i<len;i++)
{if(activenum-1==i)
{continue;}
fs_data2[j]=this.data[i];j++;}
this.data=fs_data2;this.isDirty=true;this.update();return;}
if(evnt.keyCode==37&&this.data[activenum-1]&&$(this.activeInputID).value=="")
{return;var obj=this.data[activenum];this.data[activenum]=this.data[activenum-1];this.data[activenum-1]=obj;this.update();return;}
if(evnt.keyCode==39&&this.data[activenum+1]&&$(this.activeInputID).value=="")
{return;var obj=this.data[activenum];this.data[activenum]=this.data[activenum+1];this.data[activenum+1]=obj;this.update();return;}
var hotinfo=this.getHotNum();var hotnum=hotinfo.hotnum;var num=hotinfo.totalnum;if(evnt.keyCode==40)
{if($(this.superInputSuggestID+"_0")!=null&&$(this.superInputSuggestID).style.display=="block")
{if(hotnum==-1)
{$(this.superInputSuggestID+"_0").className="sgt_on";}
else
{var nextnum=hotnum==num-1?0:hotnum+1;$(this.superInputSuggestID+'_'+hotnum).className="sgt_of";$(this.superInputSuggestID+'_'+nextnum).className="sgt_on";}
return false;}}
if(evnt.keyCode==38)
{if($(this.superInputSuggestID+"_0")!=null&&$(this.superInputSuggestID).style.display=="block")
{if(hotnum==-1)
{$(this.superInputSuggestID+'_'+(num-1)).className="sgt_on";}
else
{var prevnum=hotnum==0?num-1:hotnum-1;$(this.superInputSuggestID+'_'+hotnum).className="sgt_of";$(this.superInputSuggestID+'_'+prevnum).className="sgt_on";}}}};FriendSuggestSuperInput.prototype.getUser=function()
{var hotinfo=this.getHotNum();var hotnum=hotinfo.hotnum;var totalnum=hotinfo.totalnum;var hasuser=$(this.superInputSuggestID).style.display=="block"&&hotnum!=-1&&totalnum>0;if(this.mode==1&&!hasuser&&$(this.activeInputID).value.length)
{if(this.checkCount(true))
{var escape_real_name=$(this.activeInputID).value.replace(/&/g,"&amp;");escape_real_name=escape_real_name.replace(/</g,"&lt;");escape_real_name=escape_real_name.replace(/>/g,"&gt;");var friendobj={uid:"0",real_name:escape_real_name,real_name_unsafe:$(this.activeInputID).value,type:"static"};if(!this.userAdded(friendobj)){var activenum=this.hasActive();for(var i=this.data.length;i>activenum;i--)
{this.data[i]=this.data[i-1];}
this.data[activenum]=friendobj;this.isDirty=true;}}
this.update();}
else if(hasuser)
{if(this.checkCount(true))
{var friendobj=this.frienddata[hotnum];friendobj.type="static";if(!this.userAdded(friendobj)){var activenum=this.hasActive();for(var i=this.data.length;i>activenum;i--)
{this.data[i]=this.data[i-1];}
this.data[activenum]=friendobj;this.isDirty=true;}}
this.update();}};FriendSuggestSuperInput.prototype.inputOnkeyup=function(evnt)
{if(evnt.keyCode==13)
{this.getUser();}
if(evnt.keyCode==27)
{this.suggestClose();}
else if(evnt.keyCode==38||evnt.keyCode==40)
{}
else if(this.data.length<=this.maxcount)
{this.ajax_getFriendList();}else{}};FriendSuggestSuperInput.prototype.ajax_getFriendList=function()
{var url="/interface/suggestfriend.php";var text=encodeURIComponent($(this.activeInputID).value);var pars="text="+text+'&t='+Math.random();var obj=this;if(("undefined"!=typeof this.suggestpars)&&this.suggestpars!='')
{pars+='&pars='+this.suggestpars;}
var myAjax=new Ajax.Request(url,{method:"get",parameters:pars,onSuccess:this.ajax_getFriendList_cb.bind(this),onFailure:function(req){}});};FriendSuggestSuperInput.prototype.ajax_getFriendList_cb=function(req)
{var arr=eval(req.responseText);this.frienddata.clear();if(arr.length==0)
{$(this.superInputSuggestID).style.display="none";if(this.data.length>this.maxcount)
{$(this.superInputEmptySuggestID).style.display="none";}
else
{$(this.superInputEmptySuggestID).style.display="block";}
if($(this.activeInputID).value=="")
{if(this.data.length>1)
{$(this.superInputEmptySuggestID).style.display="none";}
else
{$(this.superInputEmptySuggestID).innerHTML="请输入好友的姓名(支持拼音首字母输入)";}}
else
{if(this.mode==1)
{$(this.superInputEmptySuggestID).style.display="none";}
else
{$(this.superInputEmptySuggestID).innerHTML="姓名不在好友列表哦，请重新输入";}}
return;}
this.frienddata=arr;var htmlTemplate='<div id="#{divID}" class="sgt_of" style="width:200px;" onmouseover="#{obj}.suggestOnmouseover(this)" onmousedown="#{obj}.suggestOnmousedown(this);">#{friendName}#{logo}</div>';var data={divID:'',obj:'friendSuggestSuperInputRegistry.get(\''+this.id+'\')',friendName:'',logo:''};var template=new Template(htmlTemplate);var html="";for(var i=0;i<arr.length;i++)
{data.divID=this.superInputSuggestID+'_'+i;data.friendName=arr[i].real_name;data.logo=this.logo(arr[i]);html+=template.evaluate(data);}
$(this.superInputSuggestID).innerHTML=html;$(this.superInputSuggestID).style.display="block";$(this.superInputEmptySuggestID).style.display="none";if($(this.superInputSuggestID+"_0")!=null&&$(this.superInputSuggestID).style.display=="block")
{$(this.superInputSuggestID+"_0").className="sgt_on";}};FriendSuggestSuperInput.prototype.suggestcloseOnMouseover=function()
{var num=0;while((obj=$(this.superInputSuggestID+'_'+num))!=null)
{if(obj.className=="sgt_on")
{obj.className="sgt_of";}
num++;}};FriendSuggestSuperInput.prototype.suggestClose=function()
{this.update();};FriendSuggestSuperInput.prototype.extractInputIndex=function(obj){if(obj&&('id'in obj)){return obj.id.substring(this.superInputSuggestID.length+1,obj.id.length);}
return-1;};FriendSuggestSuperInput.prototype.suggestOnmouseover=function(thisobj)
{var thisnum=this.extractInputIndex(thisobj);var obj;var num=0;while((obj=$(this.superInputSuggestID+'_'+num))!=null)
{if(thisnum==num)
{obj.className="sgt_on";}
else
{obj.className="sgt_of";}
num++;}};FriendSuggestSuperInput.prototype.suggestOnmousedown=function(thisobj)
{if(this.checkCount(true))
{var num=this.extractInputIndex(thisobj);var friendobj=this.frienddata[num];friendobj.type="static";if(!this.userAdded(friendobj)){var activenum=this.hasActive();for(var i=this.data.length;i>activenum;i--)
{this.data[i]=this.data[i-1];}
this.data[activenum]=friendobj;this.isDirty=true;}}
if($(this.activeInputID))
{$(this.activeInputID).value="";}
this.update();};FriendSuggestSuperInput.prototype.toggleSuggestView=function()
{if($(this.suggestViewContainer).style.display=="block")
{this.closeSuggestView();}
else
{this.showSuggestView();}};FriendSuggestSuperInput.prototype.closeSuggestView=function(){if(!this.suggestViewObject.clearSuggestViewData())
{return false;}
$(this.suggestViewContainer).style.display="none";$(this.imgSwitchBtn).innerHTML='<img src="http://'+this.imgHost+'/i/xx_xx1.gif" class="cp" onmouseover="this.src=\'http://'+this.imgHost+'/i/xx_xx2.gif\';" onmouseout="this.src=\'http://'+this.imgHost+'/i/xx_xx1.gif\';" alt="选择好友" />';this.update();return true;};FriendSuggestSuperInput.prototype.getSuggestion=function(){return this.data;}
FriendSuggestSuperInput.prototype.setSuggestion=function(data){if(!data instanceof Array)return;this.data.clear();var user=null;for(var i=0;i<data.length;i++){user=data[i];if(user==null)continue;this.addUser(user,'static');}
return;}
FriendSuggestSuperInput.prototype.observeRecentContacts=function(btn)
{$(btn).observe('click',this.saveSelectedFriends.bind(this));}
FriendSuggestSuperInput.prototype.saveSelectedFriends=function(cb){var fs_data=this.data;var pars='';for(var i=0;i<fs_data.length;i++){if(fs_data[i].uid==null||fs_data[i].uid==0)continue;pars+=fs_data[i].uid+",";}
if(pars.length<1){return;}
pars="fuids="+pars.substr(0,pars.length-1)+'&t='+Math.random();var url="/interface/setrecentcontacts.php";var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onSuccess:this.ajax_saveSelectedFriends_cb.bind(this),onComplete:function(req){if(typeof(cb)=="function")cb();}});}
FriendSuggestSuperInput.prototype.ajax_saveSelectedFriends_cb=function(req){var retValue=req.responseText.strip();if(retValue=='-1'){}else{}}
FriendSuggestSuperInput.prototype.showSuggestView=function(){$(this.suggestViewContainer).style.display="block";this.suggestViewObject.initSuggestViewData();};FriendSuggestSuperInput.prototype.logo=function(obj)
{var logo20="";if(typeof obj.logo20!="undefined")
{logo20="<img src='"+obj.logo20+"'  align=absmiddle width=15  />";}
return logo20;};FriendSuggestSuperInput.prototype.addUser=function(objUser,type){if(objUser==null||objUser.uid==null||objUser.uid==0){return;}
if(!('type'in objUser)||objUser.type=='')
{objUser.type=type;}
this.data=this.removeNonStaticData();if(!this.userAdded(objUser)){this.data[this.data.length]=objUser;}};FriendSuggestSuperInput.prototype.removeNonStaticData=function()
{if(this.data.length<1)return this.data;buffer=[];for(var i=0,j=0;i<this.data.length;i++)
{if('type'in this.data[i]&&this.data[i].type=='static')
{buffer[j++]=this.data[i];}}
return buffer;};FriendSuggestSuperInput.prototype.reachMaxCount=function(){return(this.data.length>this.maxcount);};FriendSuggestSuperInput.prototype.userAdded=function(objUser){if(objUser==null||!objUser.uid||objUser.uid==0){return true;}
for(var i=0;i<this.data.length;i++){obj=this.data[i];if(obj.uid==null){continue;}
if(obj.uid==objUser.uid){return true;}}
return false;};FriendSuggestSuperInput.prototype.selectSuggestedFriends=function(selFriList)
{var arr=selFriList;var len=arr.length;for(var i=0;i<len;i++)
{this.addUser(arr[i],'static');}
var fs_data2=[];var j=0;len=this.data.length;for(var i=0;i<len;i++)
{if(this.data[i].type=="active")
{continue;}
if(j>=this.maxcount)
{this.needAlert=true;break;}
fs_data2[j++]=this.data[i];}
this.data=fs_data2;this.isDirty=true;return fs_data2;};

var FriendSuggestViewLocale={freqFriUnsave:'常用联系人还没保存，离开该页将会丢失所做的修改，你确定要离开吗？',clearRecentContacts:'你确定要清空所有最近联系人吗？',freqFriNumExceed:'抱歉！最多只能设置#{freqLimit}个常用联系人',chgPanelOnFriChecked:"切换页面后将清空你刚才勾选的好友，你确定要切换吗？"}
var friendSuggestSuperViewRegistry={viewObjects:{},add:function(id,maxcount,objHost,callback_friendsSelected,callback_closeView){var obj=new FriendSuggestView(id,maxcount,objHost,callback_friendsSelected,callback_closeView);if(friendSuggestSuperViewRegistry.viewObjects[id]){delete friendSuggestSuperViewRegistry.viewObjects[id];}
friendSuggestSuperViewRegistry.viewObjects[id]=obj;return obj;},get:function(id){if(friendSuggestSuperViewRegistry.viewObjects[id]){return friendSuggestSuperViewRegistry.viewObjects[id];}
return null;}};function addFriendSuggestView(id,maxcount,objectHost,callback_friendsSelected,callback_closeView){var obj=friendSuggestSuperViewRegistry.add(id,maxcount,objectHost,callback_friendsSelected,callback_closeView);obj.setSingleSelection(maxcount<2);return obj;}
function FriendSuggestView(id,maxcount,objectHost,callback_friendsSelected,callback_closeView){this.frequentFriendsNumLimit=30;this.locale=FriendSuggestViewLocale;this.id=id;this.host_object=objectHost;this.selectpars="gf_me";this.div_sug_panel=id+'sug_box';this.div_sug_navbar=id+'sug_nav';this.container_navbar=id+'panels';this.container_groups=id+'sug_group';this.div_friends=id+'sug_cont';this.label_selectedGroupName=id+'group_name';this.btn_selection=id+'fs_selection_';this.btn_confirm=id+'btn_qd';this.div_ff_inner_suggestion=id+'div_frequent_friends_suggestion';this.suggest=null;this.freqf_input_id=id+'inner';this.div_freqFriendSuggestion=id+'inner_friend_suggestion';this.btn_addFrequentFriend=id+'btn_fb';this.btn_saveFrequentFriends=id+'div_btn_saveff';this.frequentListDirty=false;this.container_frequentFriendsDragDrop=id+'ff_container';this.ff_drag_name=id+'ffdnd_';this.allFriendsListId=id+'all_friends_list';this.div_select_all=id+'div_select_all';this.btn_selall=id+'selall';this.btn_unselall=id+'unselall';this.btn_clear=id+'clear';this.container_buttons=id+'but_area';this.div_btn_confirm=id+'div_btn_confirm';this.panel_allFriends=id+'panel_all';this.panel_frequent=id+'panel_frequent';this.panel_recent=id+'panel_recent';this.currentPanel=id+'panel_all';this.currentFriendNum=0;this.currentGroup='n/a';this.allgroupdata=[];this.selectedUid=0;this.allfrienddata=[];this.frequentFriends=[];this.frequentFriendsBackup=[];this.recentFriends=[];this.maxSelection=maxcount;this.callback_selectFriends=callback_friendsSelected;this.callback_closeView=callback_closeView;this.panelUpdated=false;this.maxNameLength=4;this.queryTimestamps=new Hash();this.cacheTime=60*1000;this.imgHost='img1.kaixin001.com.cn';}
FriendSuggestView.prototype.outputHTML=function(containerID){var html=this.getSuggestPanelHTML();if($(containerID)){$(containerID).innerHTML=html;[this.panel_allFriends,this.panel_frequent,this.panel_recent].each((function(pid){var link=$(pid).down('a');if(pid==this.panel_allFriends)
{link.observe('click',this.toggleArrowBtn.bindAsEventListener(this));}
link.observe('click',this.changePanelEvt.bindAsEventListener(this,pid));link.observe('focus',function(evt){evt.element().blur()});}).bind(this));$(this.container_navbar).next('div').down('a').observe('click',this.callback_closeView);var addFriBtn=$(this.btn_addFrequentFriend);addFriBtn.observe('click',this.addFrequentFriend.bind(this));addFriBtn.observe('mouseout',function(evt){evt.element().className='gb3'});addFriBtn.observe('mouseover',function(evt){evt.element().className='gb4'});var confirmBtn=$(this.btn_confirm);confirmBtn.observe('click',this.clickOkButton.bind(this));confirmBtn.observe('mouseout',function(evt){evt.element().className='gb3'});confirmBtn.observe('mouseover',function(evt){evt.element().className='gb4'});$(this.btn_selall).observe('click',this.selectAll.bind(this));$(this.btn_unselall).observe('click',this.unselectAll.bind(this));$(this.btn_clear).observe('click',this.clearAll.bind(this));}};FriendSuggestView.prototype.getHostObject=function(){return this.host_object;};FriendSuggestView.prototype.getSuggestPanelHTML=function(){var data={container_navbar:this.container_navbar,panel_allFriends:this.panel_allFriends,panel_frequent:this.panel_frequent,panel_recent:this.panel_recent,container_groups:this.container_groups,div_friends:this.div_friends,div_select_all:this.div_select_all,div_ff_inner_suggestion:this.div_ff_inner_suggestion,div_freqFriendSuggestion:this.div_freqFriendSuggestion,btn_saveFrequentFriends:this.btn_saveFrequentFriends,div_btn_confirm:this.div_btn_confirm,label_selectedGroupName:this.label_selectedGroupName,btn_selall:this.btn_selall,btn_unselall:this.btn_unselall,btn_clear:this.btn_clear,btn_addFrequentFriend:this.btn_addFrequentFriend,btn_confirm:this.btn_confirm,img_host:this.imgHost};var htmlb=new Array;htmlb.push('<div class="sug_box">\n');htmlb.push('<div class="sug_nav">\n');htmlb.push('<ul id="#{container_navbar}" class="snav">\n');htmlb.push('<li id="#{panel_allFriends}" class="s_on cp" style="position:relative;"><a href="javascript:void(0);" class="sl2" title="全部好友"><span id="#{label_selectedGroupName}">全部好友</span>&nbsp;<img id="toogleArrowBtn" src="http://#{img_host}/i2/xiasanjiao.gif" align="absmiddle" style="position:absolute;top:9px;right:4px;" /></a></li>\n');htmlb.push('<li id="#{panel_frequent}" class="s_off"><a href="javascript:void(0);" class="sl2">常用联系人</a></li>\n');htmlb.push('<li id="#{panel_recent}" class="s_off"><a href="javascript:void(0);" class="sl2">最近联系人</a></li>\n');htmlb.push('</ul>\n');htmlb.push('<div class="close">\n');htmlb.push('<a href="javascript:void(0);"><img src="http://#{img_host}/i2/black_del.gif" title="关闭"/></a>\n');htmlb.push('</div>\n');htmlb.push('<div id="#{container_groups}" class="sug_group" style="display:none;">\n');htmlb.push('</div>\n');htmlb.push('</div>\n');htmlb.push('<div id="#{div_friends}" class="sug_cont">\n');htmlb.push('</div>\n');htmlb.push('<div class="but_area">\n');htmlb.push('<div class="all_slc" style="width:200px;">\n');htmlb.push('<div class="l" id="#{div_select_all}" style="display:none;margin-left:4px;*margin-top:2px;padding-left:5px;*margin-right:-8px;"><a href="javascript:void(0);" class="sl" id="#{btn_selall}">全选</a><a href="javascript: void(0);" class="sl" id="#{btn_unselall}">取消</a> <a href="javascript: " class="sl ml5" id="#{btn_clear}" style="display:none;">清空</a></div>\n');htmlb.push('<div id="#{div_ff_inner_suggestion}" class="l ml10" style="position:relative; display:none;">\n');htmlb.push('<div style="position: absolute; z-index:10;" id="#{div_freqFriendSuggestion}">\n');htmlb.push('</div>\n');htmlb.push('<div class="flw5">&nbsp;</div>\n');htmlb.push('<div style="position:absolute; left:95px;*left:100px; z-index:1;" class="gbs1"><input type="button"  class="gb3" style="height:23px;line-height:20px;padding:0 3px 3px 3px;" title="添加" value="添加" id="#{btn_addFrequentFriend}"/></div>\n');htmlb.push('<div class="c"></div>\n');htmlb.push('</div>\n');htmlb.push('</div>\n');htmlb.push('<div class="flw5">&nbsp;</div>\n');htmlb.push('<div class="gbs1" id="#{div_btn_confirm}" style="visibility:hidden;float:right;"><input type="button" style="height:23px;line-height:20px;padding:0 3px 3px 3px;" class="gb3" title="确定" value="确定" id="#{btn_confirm}"></div>\n');htmlb.push('<div class="c"></div>\n');htmlb.push('</div>\n');htmlb.push('</div>\n');var html=htmlb.join('');var htmlTemplate=new Template(html);return htmlTemplate.evaluate(data);};FriendSuggestView.prototype.clearPanelData=function(){this.clearAllChecked();this.clearFrequentFriendsData();this.recentFriends.clear();this.selectedUid=0;this.allfrienddata.clear();this.currentGroup='';};FriendSuggestView.prototype.clearFrequentFriendsData=function(){this.frequentFriends.clear();this.frequentListDirty=false;};FriendSuggestView.prototype.clearQueryTimestamps=function(){this.queryTimestamps.set(this.panel_allFriends,0);this.queryTimestamps.set(this.panel_recent,0);this.queryTimestamps.set(this.panel_frequent,0);};FriendSuggestView.prototype.toggleGroupList=function(){var grouplist=$(this.container_groups);if(!grouplist){return;}
if(grouplist.style.display=='none')
{this.getGroupList();if(this.allgroupdata.length>0)
{this.showElement(this.container_groups,false);}}
else
{this.hideElement(this.container_groups);}};FriendSuggestView.prototype.toggleElement=function(element){if(!$(element)){return;}
$(element).style.display=($(element).style.display=='none')?'block':'none';};FriendSuggestView.prototype.changePanelEvt=function(evt,panel){if(this.currentPanel!=panel)
{Event.stop(evt);}
this.changePanel(panel);}
FriendSuggestView.prototype.changePanel=function(panel){if(this.currentPanel==panel){if(this.currentPanel==this.panel_allFriends){this.toggleGroupList();}
return;}
if(panel!=this.panel_frequent)
{if(this.suggest)this.suggest.clear();}
if(this.currentPanel==this.panel_allFriends){this.hideElement($(this.container_groups));}else if(this.currentPanel==this.panel_frequent&&this.frequentListDirty){if(!confirm(this.locale.freqFriUnsave)){return;}
this.clearFrequentDirtyFlag();this.restoreFrequentFriendData();}
if(!this.checkPrevPanelSelection(this.locale.chgPanelOnFriChecked)){return;}
this.hidePanelButtons();if(this.currentPanel!=''){$(this.currentPanel).className='s_off';}
$(panel).className='s_on cp';this.currentPanel=panel;this.loadPanelData();$('toogleArrowBtn').src='http://'+this.imgHost+'/i2/xiasanjiao.gif';return;};FriendSuggestView.prototype.toggleArrowBtn=function(event){var el=Event.element(event);if(el.tagName=='IMG')var target=el;else if(el.tagName=='A')var target=el.down('img');else if(el.tagName=='SPAN')var target=el.next('img');if(target.src.indexOf('xia')!=-1){target.src='http://img1.kaixin001.com.cn/i2/shangsanjiao.gif';}else if(target.src.indexOf('shang')!=-1){target.src='http://img1.kaixin001.com.cn/i2/xiasanjiao.gif';}}
FriendSuggestView.prototype.setQueryCacheTime=function(seconds){seconds=parseInt(seconds);if(seconds<=0){this.cacheTime=0;}else{this.cacheTime=seconds*1000;}};FriendSuggestView.prototype.loadPanelData=function(){this.panelUpdated=false;if(this.currentPanel==this.panel_allFriends){this.changeGroup(this.currentGroup,true);}else{current=new Date().getTime();lasttime=this.queryTimestamps.get(this.currentPanel);lasttime=(lasttime)?lasttime:0;if(this.cacheTime>0&&current-lasttime<this.cacheTime){switch(this.currentPanel){case this.panel_frequent:this.updateFrequentFriendsPanel();this.initDragDrop();break;case this.panel_recent:this.updateRecentFriendsPanel();break;default:alert('无效的参数');}}else{switch(this.currentPanel){case this.panel_frequent:this.ajax_viewFrequentFriends();break;case this.panel_recent:if(this.recentFriends.length<1){this.ajax_viewRecentFriends();}else{this.updateRecentFriendsPanel();}
break;default:alert('无效的参数');}}}};FriendSuggestView.prototype.hidePanelButtons=function(){this.hideElementInSitu(this.div_btn_confirm);this.hideElement(this.div_select_all);this.hideElement(this.btn_selall);this.hideElement(this.btn_unselall);this.hideFreqFriendSuggestion();};FriendSuggestView.prototype.showElementInSitu=function(element){if($(element)){$(element).style.visibility="visible";}};FriendSuggestView.prototype.hideElementInSitu=function(element){if($(element)){$(element).style.visibility="hidden";}};FriendSuggestView.prototype.hideElement=function(element){if($(element)){$(element).style.display="none";}};FriendSuggestView.prototype.showElement=function(element,inline){if($(element)){inline?$(element).style.display="inline":$(element).style.display="block";}};FriendSuggestView.prototype.backupFrequentFriendData=function(){this.frequentFriendsBackup.splice(0,this.frequentFriendsBackup.length);for(var i=0;i<this.frequentFriends.length;i++)
{this.frequentFriendsBackup[i]=this.frequentFriends[i];}};FriendSuggestView.prototype.restoreFrequentFriendData=function(){this.frequentFriends.splice(0,this.frequentFriends.length);for(var i=0;i<this.frequentFriendsBackup.length;i++)
{this.frequentFriends[i]=this.frequentFriendsBackup[i];}};FriendSuggestView.prototype.showFreqFriendSuggestion=function(){this.showElement($(this.div_ff_inner_suggestion));if(!this.suggest){this.suggest=addFriendSuggest(this.freqf_input_id,this,"gf_ri",this.selectUser_cb.bind(this));this.suggest.showInputBox(this.div_freqFriendSuggestion);}};FriendSuggestView.prototype.hideFreqFriendSuggestion=function(){this.hideElement($(this.div_ff_inner_suggestion));};FriendSuggestView.prototype.ajax_viewFrequentFriends=function(){this.loadingData();this.clearFrequentFriendsData();var url='/interface/frequentcontacts.php';var obj=this;var myAjax=new Ajax.Request(url,{method:"get",parameters:'t='+Math.random(),onSuccess:this.ajax_viewFrequentFriends_cb.bind(this),onFailure:this.ajax_error_cb.bind(this,'访问服务器超时, 请稍候重试')});};FriendSuggestView.prototype.ajax_viewRecentFriends=function(){this.hideFreqFriendSuggestion();this.loadingData();this.recentFriends.clear();var url='/interface/recentcontacts.php';var obj=this;var myAjax=new Ajax.Request(url,{method:"get",parameters:'t='+Math.random(),onSuccess:this.ajax_viewRecentFriends_cb.bind(this),onFailure:this.ajax_error_cb.bind(this,'访问服务器超时, 请稍候重试')});};FriendSuggestView.prototype.updateRecentFriendsPanel=function(){var arr=this.recentFriends;if(arr.length<1){this.noRecentFriends();return;}
var templateHTML='<li title="开心ID：#{uid}"><label for="#{btn_id}"><input id="#{btn_id}" type="'+this.selectionType+'" title="开心ID：#{uid}" onclick="#{view_obj}.countcheck(this);" name="#{btn_name}" value="#{uid}" /> #{real_name}#{logo}</label></li>\n';var templateFriend=new Template(templateHTML);var data={view_obj:'friendSuggestSuperViewRegistry.get(\''+this.id+'\')',btn_name:this.btn_selection+'uid',uid:0,btn_id:'',real_name:'',logo:''};var recentLHeight=Math.ceil(arr.length/3)*25+'px';var html='<ul class="s_list" style="height:'+recentLHeight+';">\n';for(var i=0;i<arr.length;i++)
{if(arr[i])
{data.uid=arr[i].uid;data.btn_id=this.btn_selection+i;data.real_name=this.truncateName(arr[i],this.maxNameLength);data.logo=this.logo(arr[i]);html+=templateFriend.evaluate(data);}}
html+='</ul>\n';this.setPanelContent(html);this.setPanelButtons(arr.length,this.maxcount);this.panelUpdated=true;this.countcheck(null);};FriendSuggestView.prototype.setPanelButtons=function(friendNum,maxCount){this.hideElement(this.btn_clear);this.currentFriendNum=friendNum;if(friendNum>0){this.showElementInSitu(this.div_btn_confirm);this.showElement(this.div_select_all,'inline');if(this.singleSelection){this.hideElement(this.btn_selall);this.hideElement(this.btn_unselall);}else if(friendNum>maxCount){this.hideElement(this.btn_selall);}else{this.showElement(this.btn_selall,'inline');}
if(this.currentPanel==this.panel_recent){this.showElement(this.btn_clear,'inline');}}else{this.hideElementInSitu(this.div_btn_confirm);this.hideElement(this.div_select_all);}
if(this.isFrequentFriendsChanged()){this.showElementInSitu(this.div_btn_confirm);}};FriendSuggestView.prototype.ajax_clearRecentFriends=function(){if(this.recentFriends.length<1)return;var url='/interface/setrecentcontacts.php';var obj=this;var myAjax=new Ajax.Request(url,{method:"get",parameters:'flag=clear&t='+Math.random(),onSuccess:this.ajax_clearRecentFriends_cb.bind(this),onFailure:function(req){alert('清空常用联系人失败');}});};FriendSuggestView.prototype.ajax_saveFrequentFriends=function(){var uids='';var logo=0;for(var i=0;i<this.frequentFriends.length;i++){if(!this.frequentFriends[i].uid){continue;}
logo=(this.frequentFriends[i].logo20==null)?0:1;uids+=this.frequentFriends[i].uid+':'+logo+',';}
if(uids.length>0){uids=uids.substr(0,uids.length-1);}
var url='/interface/setfrequentcontacts.php';var obj=this;var myAjax=new Ajax.Request(url,{method:"get",parameters:'list='+uids+'&t='+Math.random(),onSuccess:this.ajax_saveFrequentFriends_cb.bind(this),onFailure:this.debug.bind(this,'保存常用联系人失败')});};FriendSuggestView.prototype.validateInt=function(data)
{var re=/^\d+$/;return data.match(re);}
FriendSuggestView.prototype.ajax_saveFrequentFriends_cb=function(req){var response=req.responseText;if(!this.validateInt(response)){alert('保存常用联系人失败');}else{if(parseInt(response)==0){alert("常用联系人列表已清空");}
else{alert("保存成功");}
this.clearFrequentDirtyFlag();this.backupFrequentFriendData();}}
FriendSuggestView.prototype.ajax_viewFrequentFriends_cb=function(req){var response=req.responseText;if(response==''){this.error('服务器超时, 如确认已登录, 请稍候再试');this.hidePanelButtons();this.queryTimestamps.set(this.panel_frequent,0);return;}
this.queryTimestamps.set(this.panel_frequent,new Date().getTime());var data=eval("("+response+")");if(data!=null&&data instanceof Array){this.frequentFriends=data;}
else
{this.error('访问服务器超时, 请稍后重试');this.queryTimestamps.set(this.panel_frequent,0);this.hidePanelButtons();return;}
if(this.currentPanel!=this.panel_frequent){this.debug('ajax_frequentFriend called in another panel');return;}
if(data==null){this.error('访问服务器超时, 请稍后重试');this.queryTimestamps.set(this.panel_frequent,0);this.hidePanelButtons();return;}
this.backupFrequentFriendData();this.updateFrequentFriendsPanel();this.initDragDrop();return;}
FriendSuggestView.prototype.ajax_viewRecentFriends_cb=function(req){var response=req.responseText;if(response==''){this.error('服务器超时, 如确认已登录, 请稍候再试');this.queryTimestamps.set(this.panel_recent,0);this.hidePanelButtons();return;}
var data=eval("("+response+")");if(this.currentPanel!=this.panel_recent){this.debug('ajax_recentFriend called in another panel');return;}
if(data==null||!data instanceof Array){this.error('访问服务器超时, 请稍后重试');this.queryTimestamps.set(this.panel_recent,0);this.hidePanelButtons();return;}else{this.queryTimestamps.set(this.panel_recent,new Date().getTime());this.recentFriends=data;this.updateRecentFriendsPanel();}
return;}
FriendSuggestView.prototype.error=function(message){var html='<div class="pt40 tac">\n';html+='<span class="c9">'+message+'</span>\n';html+='</div>\n';this.setPanelContent(html);this.hideElementInSitu(this.div_btn_confirm);this.hideElement(this.div_select_all);};FriendSuggestView.prototype.ajax_error_cb=function(message){this.error(message);this.hidePanelButtons();}
FriendSuggestView.prototype.noRecentFriends=function(){var html='<div class="pt40 tac">\n';html+='<span class="c9">暂时没有最近联系人</span>\n';html+='</div>\n';this.setPanelContent(html);this.hidePanelButtons();this.hideElementInSitu(this.div_btn_confirm);this.hideElement(this.div_select_all);};FriendSuggestView.prototype.noFrequentFriends=function(){var html='<div class="mt30 tac">\n';html+='<span class="c9">请添加常用联系人</span>\n';html+='</div>\n';this.setPanelContent(html);};FriendSuggestView.prototype.addFrequentFriend=function(){if(!this.selectedUid||this.selectedUid==null){this.suggest.focus();return;}
uid=this.selectedUid;name=this.suggest.getUsername(uid).strip();if(name==''){this.selectedUid=0;this.suggest.focus();return;}
var inputName=this.suggest.getValue();if(name!=inputName){this.debug('选择的UID对应的名字"'+name+'"与选取的名字"'+inputName+'"不符');this.suggest.focus();return;}
if(this.isInFrequentUserList(uid)){alert(name+' 已在常用联系人列表');this.suggest.clear();return;}
if(this.frequentFriends.length>1){this.frequentFriends=this.getSortedFrequentFriendData();}
var obj=this.suggest.getInfoObject(uid);if(obj==null)
{alert('指定UID '+uid+' 没有找到');}
else if(this.frequentFriends.length>=this.frequentFriendsNumLimit)
{alert((new Template(this.locale.freqFriNumExceed)).evaluate({freqLimit:this.frequentFriendsNumLimit}));this.suggest.clear();return;}
else
{this.frequentFriends[this.frequentFriends.length]=obj;}
this.resetFrequentFriendPanel();this.selectedUid=0;this.suggest.clear();this.setFrequentDirtyFlag();$(this.div_friends).scrollTop=9999;return this.frequentFriends.length;};FriendSuggestView.prototype.showRenumberButton=function(i){var id=this.btn_selection+'renumber_'+i;if($(id)){this.showElement($(id));}};FriendSuggestView.prototype.hideRenumberButton=function(i){var id=this.btn_selection+'renumber_'+i;if($(id)){this.hideElement($(id));}};FriendSuggestView.prototype.renumberFrequentFriend=function(index,operation){if(index<0||index>=this.frequentFriends.length||this.frequentFriends.length==0){return;}
switch(operation){case'del':if(confirm('确定要把 '+this.frequentFriends[index].real_name+' 从常用联系人里删除吗?')){var elementName=this.ff_drag_name+index;if($(elementName)){$(elementName).remove();this.setFrequentDirtyFlag();this.frequentFriends=this.getSortedFrequentFriendData();this.resetFrequentFriendPanel();}}
break;default:return;}};FriendSuggestView.prototype.truncateName=function(objUidInfo,maxLength){var name=objUidInfo.real_name;if(!this.isInstitution(objUidInfo))
{name=this.truncateString(objUidInfo.real_name,maxLength);}
return name;};FriendSuggestView.prototype.isCelebrity=function(objUidInfo){if(!this.isStar(objUidInfo))return false;return objUidInfo.startype==0;};FriendSuggestView.prototype.isInstitution=function(objUidInfo){if(!this.isStar(objUidInfo))return false;return objUidInfo.startype==1;};FriendSuggestView.prototype.isStar=function(objUidInfo){if(!('startype'in objUidInfo))return false;return true;};FriendSuggestView.prototype.truncateString=function(string,maxLength){string=string.strip();var byteLength=2*maxLength;var currentByteLength=0;var characterPos=0;for(var i=0;i<string.length&&currentByteLength<byteLength;i++)
{if(string.charCodeAt(i)>255)
{if(currentByteLength+2<=byteLength)
{currentByteLength+=2;}
else
{break;}}
else
{currentByteLength++;}
characterPos=i;}
return(characterPos+1<string.length)?(string.substr(0,characterPos)+'..'):string;};FriendSuggestView.prototype.initDragDrop=function(){var obj=this;if(obj.frequentFriends.length==0)
{return;}
Position.includeScrollOffsets=true;Sortable.create(this.container_frequentFriendsDragDrop,{overlap:'horizontal',constraint:false,scroll:$(this.div_friends),onChange:function(el){obj.dragEl=el;obj.dragEl.down('input').disabled=true;},onUpdate:function(){obj.setFrequentDirtyFlag();setTimeout(function(){obj.dragEl.down('input').disabled=false},10);}});};FriendSuggestView.prototype.getSortedFrequentFriendData=function(){var renumbered=[];var dragables=Sortable.sequence(this.container_frequentFriendsDragDrop);var index=0;var ids='';for(var i=0,j=0;i<dragables.length;i++){index=dragables[i];if(index&&this.frequentFriends[index]){ids+=index+' ';index=parseInt(index);if(index>=0&&index<this.frequentFriends.length){renumbered[j++]=this.frequentFriends[index];}}}
return renumbered;};FriendSuggestView.prototype.resetFrequentFriendPanel=function(){this.updateFrequentFriendsPanel();this.initDragDrop();};FriendSuggestView.prototype.saveFrequentFriends=function(){if(this.frequentFriends.length>0&&this.frequentFriends.length<=this.frequentFriendsNumLimit){this.frequentFriends=this.getSortedFrequentFriendData();}
else if(this.frequentFriends.length>this.frequentFriendsNumLimit)
{alert((new Template(this.locale.freqFriNumExceed)).evaluate({freqLimit:this.frequentFriendsNumLimit}));return;}
this.resetFrequentFriendPanel();this.ajax_saveFrequentFriends();};FriendSuggestView.prototype.getFrequentFriendItemTemplate=function(){if(navigator.userAgent.indexOf('MSIE 6.0')!=-1)var bottomValue='6px';else if(navigator.userAgent.indexOf('MSIE 7.0')!=-1)var bottomValue=0;else var bottomValue='8px';var templateHTML='<li style="position:relative;" title="开心ID：#{uid}" id="#{dragdrop_id}" onmouseover="this.getElementsByTagName(\'span\')[1].style.display=\'inline\';" onmouseout="this.getElementsByTagName(\'span\')[1].style.display=\'none\';">\n';templateHTML+='<span class="s_name"><label for="#{btn_id}" style="cursor:move;"><input id="#{btn_id}" style="cursor:default;" type="'+this.selectionType+'" title="开心ID：#{uid}" onclick="#{view_obj}.countcheck(this);this.blur();" name="#{btn_name}" value="#{uid}" /> #{real_name}#{logo}</label></span>\n';templateHTML+='<span id="#{edit_btn_area_id}" class="s_set" style="display:none;position:absolute;right:8px;*right:2px;bottom:'+bottomValue+';" >\n';templateHTML+='<a href="javascript:#{view_obj}.renumberFrequentFriend(#{seq}, \'del\');"><img src="http://#{img_host}/i2/suggestion/del.gif" title="删除" onmouseover="this.src=\'http://#{img_host}/i2/suggestion/del2.gif\';" onmouseout="this.src=\'http://#{img_host}/i2/suggestion/del.gif\';" /></a>\n';templateHTML+='</span>\n';templateHTML+='</li>\n';return templateHTML;};FriendSuggestView.prototype.prepareFrequentFriendItem=function(i,obj){var data={img_host:this.imgHost,seq:''+i,view_obj:'friendSuggestSuperViewRegistry.get(\''+this.id+'\')',btn_name:this.btn_selection+'uid',uid:obj.uid,btn_id:this.btn_selection+i,real_name:'',logo:this.logo(obj),dragdrop_id:this.ff_drag_name+i,edit_btn_area_id:this.btn_selection+'renumber_'+i};if(data.logo!='')
{maxLength=this.maxNameLength-1;}
else
{maxLength=this.maxNameLength;}
data.real_name=this.truncateName(obj,maxLength);return data;};FriendSuggestView.prototype.generateFrequentFriendItem=function(index,dataObj){var template=new Template(this.getFrequentFriendItemTemplate());var data=this.prepareFrequentFriendItem(index,dataObj);return template.evaluate(data);};FriendSuggestView.prototype.updateFrequentFriendsPanel=function(){this.showFreqFriendSuggestion();var arr=this.frequentFriends;if(arr.length<1){this.noFrequentFriends();}else{var templateHTML=this.getFrequentFriendItemTemplate();var templateFriend=new Template(templateHTML);var frequestFLHeight=Math.ceil(arr.length/3)*25+'px';var html='<ul style="height:'+frequestFLHeight+';" class="s_list" id="'+this.container_frequentFriendsDragDrop+'">\n';var maxLength=this.maxNameLength;for(var i=0,j=0;i<arr.length;i++)
{if(arr[i])
{data=this.prepareFrequentFriendItem(j++,arr[i]);html+=templateFriend.evaluate(data);}}
html+='</ul>\n';this.setPanelContent(html);}
this.setPanelButtons(arr.length,this.maxcount);this.panelUpdated=true;this.countcheck(null);};FriendSuggestView.prototype.isInFrequentUserList=function(uid){if(isNaN(parseInt(uid))){return false;}
for(var i=0;i<this.frequentFriends.length;i++){if(this.frequentFriends[i].uid==uid){return true;}}
return false;};FriendSuggestView.prototype.isFrequentFriendsChanged=function(){return(this.currentPanel==this.panel_frequent&&this.frequentListDirty);};FriendSuggestView.prototype.clickOkButton=function(){if(this.isFrequentFriendsChanged()){this.saveFrequentFriends();}else{this.callback_selectFriends(this.getSelectedFriends());this.callback_closeView();}};FriendSuggestView.prototype.clearFrequentDirtyFlag=function(){this.frequentListDirty=false;$(this.btn_confirm).value='确定';$(this.btn_confirm).title='确定';$(this.btn_confirm).setStyle({paddingLeft:'3px',paddingRight:'3px'});};FriendSuggestView.prototype.setFrequentDirtyFlag=function(){this.frequentListDirty=true;$(this.btn_confirm).value='保存修改';$(this.btn_confirm).title='保存修改';if(navigator.userAgent.indexOf('MSIE')!=-1)$(this.btn_confirm).setStyle({paddingLeft:0,paddingRight:0});};FriendSuggestView.prototype.selectUser_cb=function(uid){if(!isNaN(parseInt(uid))){this.selectedUid=uid;}};FriendSuggestView.prototype.setPanelContent=function(htmlContents){$(this.div_friends).innerHTML=htmlContents;};FriendSuggestView.prototype.setMaxSelection=function(maxCount){if(maxCount<2){maxCount=1;}
this.maxSelection=maxCount;this.setSingleSelection(maxCount<2);};FriendSuggestView.prototype.setSingleSelection=function(singleSelection){this.clearPanelData();if(singleSelection||this.maxSelection<2){this.selectionType="radio";this.maxSelection=1;this.maxcount=1;}else{this.selectionType="checkbox";this.maxcount=this.maxSelection;}
this.singleSelection=(singleSelection==true);};FriendSuggestView.prototype.ajax_viewFriend=function(group)
{var obj=this;var suggesturl="/interface/suggestfriend.php";var starurl="/interface/starfriend.php";var url='';var pars='t='+Math.random();if(group=='机构')
{url=starurl;pars+="&st=0";}
else if(group=='名人')
{url=starurl;pars+="&st=1";}
else
{url=suggesturl;pars+='&type=all';if(group)
{pars+='&group='+group+'&pars=gf_me';}}
var data=this.retrieve_groupData(group);if(typeof(data)!="undefined")
{return this.ajax_viewFriend_cb(group,data);}
this.loadingData();var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onSuccess:this.ajax_viewFriend_cb.bind(this,group),onFailure:this.ajax_error_cb.bind(this,'访问服务器超时, 请稍候重试')});};FriendSuggestView.prototype.loadingData=function(){html='<div class="pt40 tac">\n';html+='<img src="http://'+this.imgHost+'/i2/diary/loading.gif" />\n';html+='</div>';this.setPanelContent(html);};FriendSuggestView.prototype.ajax_getGroupList=function(){var obj=this;var url="/interface/fgroup.php";var pars='t='+Math.random();;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onSuccess:this.ajax_getGroupList_cb.bind(this),onFailure:this.debug.bind(this,'取分组列表失败')});};FriendSuggestView.prototype.clearSuggestViewData=function(){if(this.frequentListDirty&&!confirm(this.locale.freqFriUnsave)){return false;}
this.clearPanelData();this.clearQueryTimestamps();this.changePanel(this.panel_allFriends);return true;};FriendSuggestView.prototype.getGroupList=function(){if(this.allgroupdata.length<1)
{this.ajax_getGroupList();}};FriendSuggestView.prototype.initSuggestViewData=function(){this.changePanel(this.panel_allFriends);if(this.currentGroup!='n/a'){this.changeGroup(this.currentGroup,true);}else{this.changeGroup('',true);}
this.hideFreqFriendSuggestion();this.frequentListDirty=false;};FriendSuggestView.prototype.showGroupFriends=function(group){this.hideElement($(this.container_groups));if(group){$(this.label_selectedGroupName).innerHTML=this.truncateString(group,5);$(this.label_selectedGroupName).up('a').writeAttribute('title',group);}else{$(this.label_selectedGroupName).innerHTML='全部好友';$(this.label_selectedGroupName).up('a').writeAttribute('title','全部好友');}
if(group=='名人'||group=='机构')$(this.label_selectedGroupName).className='title_flag';else $(this.label_selectedGroupName).className='';this.ajax_viewFriend(group);};FriendSuggestView.prototype.changeGroup=function(group,reload){this.hideElement($(this.container_groups));$('toogleArrowBtn').src='http://'+this.imgHost+'/i2/xiasanjiao.gif';if(!reload){if(this.currentGroup==group){return;}}
if(!this.checkPrevGroupSelection()){return;}
this.panelUpdated=false;this.showGroupFriends(group);this.currentGroup=group;};FriendSuggestView.prototype.checkPrevPanelSelection=function(confirmMessage){if(!this.panelUpdated){return true;}
var count=0;var data=this.getPanelData();var len=data.length;for(var i=0;i<len;i++)
{if($(this.btn_selection+i)&&$(this.btn_selection+i).checked)
{count++;}}
var confirmret=false;return(count==0||((count>0)&&(confirmret=confirm(confirmMessage))));};FriendSuggestView.prototype.checkPrevGroupSelection=function(){return this.checkPrevPanelSelection("切换分组后将清空你刚才勾选的好友，你确定要切换分组吗？");};FriendSuggestView.prototype.ajax_getGroupList_cb=function(req)
{this.allgroupdata.clear();var response=req.responseText;if(response==''||response==null){this.error('服务器超时, 如确认已经登录, 请稍候再试');this.hidePanelButtons();return;}
var arr=eval(response);var objStr='friendSuggestSuperViewRegistry.get(\''+this.id+'\')';var html='<a href="javascript:'+objStr+'.changeGroup(\'\', false)">全部好友</a>\n';if('undefined'!=typeof arr&&arr instanceof Array){this.allgroupdata=arr;var len=arr.length;for(var i=0;i<len;i++)
{html=html+' <a href="javascript:'+objStr+'.changeGroup(\''+arr[i]+'\', false)" title="'+arr[i]+'">'+this.truncateString(arr[i],6)+'</a>\n';}}
html+='<div id="extra_l"><a href="javascript:'+objStr+'.changeGroup(\'名人\', false);">名人</a><a href="javascript:'+objStr+'.changeGroup(\'机构\', false);">机构</a></div>';$(this.container_groups).innerHTML=html;};FriendSuggestView.prototype.retrieve_groupData=function(group)
{var groupData=$(this.div_friends).retrieve("allfriends");if(typeof(groupData)!="undefined"&&typeof(groupData[group])!="undefined")
{return groupData[group].clone();}
else
{return undefined;}};FriendSuggestView.prototype.store_groupData=function(group,data)
{var groupData=$(this.div_friends).retrieve("allfriends",{});groupData[group]=data.clone();$(this.div_friends).store("allfriends",groupData);};FriendSuggestView.prototype.ajax_viewFriend_cb=function(group,req)
{this.allfrienddata.clear();if(!Object.isArray(req))
{var response=req.responseText;if(response==''){this.error('服务器超时, 如确认已登录, 请稍候再试');this.queryTimestamps.set(this.panel_allFriends,0);this.hidePanelButtons();return;}
var arr=eval(response);this.store_groupData(group,arr);this.queryTimestamps.set(this.panel_allFriends,new Date().getTime());}
else
{var arr=req;}
this.showAllFriendPanel(arr,group);};FriendSuggestView.prototype.showAllFriendPanel=function(arr,group){if(arr!=null&&arr instanceof Array){this.allfrienddata=arr;}
if(this.currentPanel!=this.panel_allFriends){this.debug('ajax_allFriend called in another panel');return;}
if(arr==null||!arr instanceof Array){this.error('访问服务器超时, 请稍候重试');this.queryTimestamps.set(this.panel_allFriends,0);this.hidePanelButtons();return;}
var slistHeight=Math.ceil(arr.length/3)*25+'px';this.setPanelContent('<ul id="'+this.allFriendsListId+'" class="s_list" style="height:'+slistHeight+'"></ul>');var allFriList=$(this.allFriendsListId);var btn_id='';var fuid=0;var el_title='';var li_el=null;var lbl_el=null;var input_el=null;var span_el=null;var logo_el=null;for(var i=0;i<arr.length;i++)
{if(arr[i])
{el_title='开心ID: '+fuid;btn_id=this.btn_selection+i;fuid=arr[i].uid;li_el=new Element('li',{'title':el_title});lbl_el=new Element('label',{'for':btn_id});input_el=new Element('input',{'id':btn_id,'type':this.selectionType,'title':el_title,'name':this.btn_selection+'uid','value':fuid})
input_el.observe('click',this.countcheck.bind(this,input_el));span_el=new Element('span').update(this.truncateName(arr[i],this.maxNameLength))
logo_el=this.logoEl(arr[i])
lbl_el.appendChild(input_el);lbl_el.appendChild(span_el);if(logo_el)
{lbl_el.appendChild(logo_el);}
li_el.appendChild(lbl_el);allFriList.appendChild(li_el);}}
this.setPanelButtons(arr.length,this.maxcount);this.panelUpdated=true;this.countcheck(null);if(group==''){this.hideElement(this.btn_selall);}};FriendSuggestView.prototype.logo=function(obj)
{var logo20="";if(typeof obj.logo20!="undefined")
{logo20="<img src='"+obj.logo20+"'  align=absmiddle width=15  />";}
return logo20;};FriendSuggestView.prototype.logoEl=function(obj)
{if(typeof obj.logo20!="undefined")
{var el=new Element('img',{'src':obj.logo20,'align':'absmiddle','width':15})
return el;}
return null;};FriendSuggestView.prototype.getPanelData=function(){var arr=null;switch(this.currentPanel){case this.panel_allFriends:arr=this.allfrienddata;break;case this.panel_frequent:arr=this.frequentFriends;break;case this.panel_recent:arr=this.recentFriends;break;default:arr=[];}
return arr;};FriendSuggestView.prototype.countcheck=function(objBtn){if(!this.panelUpdated)return 0;var arr=this.getPanelData();var count=0;var len=arr.length;for(var i=0;i<len;i++)
{if($(this.btn_selection+i)&&$(this.btn_selection+i).checked)
{count++;if(count>this.maxcount)
{if(objBtn&&('checked'in objBtn)){objBtn.checked=false;}
alert("最多只能选择 "+this.maxcount+" 位好友！");break;}}}
if(!this.singleSelection)
{if(count>0)
{this.showElement(this.btn_unselall,'inline');this.hideElement(this.btn_selall);}
else if(this.currentPanel!=this.panel_allFriends||(this.currentGroup!=""&&this.currentFriendNum<=this.maxSelection))
{this.showElement(this.btn_selall,'inline');this.hideElement(this.btn_unselall);}
else
{this.hideElement(this.btn_selall);this.hideElement(this.btn_unselall);}}
else
{this.hideElement(this.btn_unselall);}
return count;};FriendSuggestView.prototype.getSelectedFriends=function()
{var friends=[];if(!this.panelUpdated)return friends;var arr=this.getPanelData();var len=arr.length;for(var i=0,j=0;i<len;i++)
{if($(this.btn_selection+i)&&$(this.btn_selection+i).checked)
{arr[i].type="static";friends[j++]=arr[i];}}
return friends;};FriendSuggestView.prototype.debug=function(message){};FriendSuggestView.prototype.clearAllChecked=function(){if(!this.panelUpdated)return;var count=0;var data=this.getPanelData();var len=data.length;for(var i=0;i<len;i++)
{if($(this.btn_selection+i)&&$(this.btn_selection+i).checked)
{count++;$(this.btn_selection+i).checked=false;}}};FriendSuggestView.prototype.selectAll=function()
{if(!$(this.btn_selall)||!this.panelUpdated)
{return;}
var checked=true;var data=this.getPanelData();len=data.length;var need_alert=false;if(len>this.maxcount)
{len=this.maxcount;need_alert=true;}
for(var i=0;i<len;i++)
{$(this.btn_selection+i).checked=checked;}
if(need_alert)
{alert("最多只能选择 "+this.maxcount+" 位好友！");}
this.countcheck(null);};FriendSuggestView.prototype.unselectAll=function(){this.clearAllChecked();this.countcheck(null);};FriendSuggestView.prototype.clearAll=function(){if(!confirm(this.locale.clearRecentContacts))
{return;}
if(this.currentPanel!=this.panel_recent)return;this.ajax_clearRecentFriends();};FriendSuggestView.prototype.ajax_clearRecentFriends_cb=function(req){var retValue=req.responseText.strip();if(retValue==''||parseInt(retValue)<0){alert('清空最近联系人时出错, 请稍后重试');}else{this.recentFriends.clear();this.updateRecentFriendsPanel();alert('最近联系人已清空');}};