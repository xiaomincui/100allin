
function showRepasteDlg(rtag,rtype,uid)
{if(rtag==0)
{if((navigator.userAgent.indexOf('MSIE 6')!=-1)||(navigator.userAgent.indexOf('MSIE 7')!=-1))openWindow('/!repaste/!repaste_tofriend_dialog.php?rtype='+rtype+'&uid='+uid+'&do=start&r='+Math.random(),410,357,'转帖');else openWindow('/!repaste/!repaste_tofriend_dialog.php?rtype='+rtype+'&uid='+uid+'&do=start&r='+Math.random(),410,347,'转帖');}
else
{if((navigator.userAgent.indexOf('MSIE 6')!=-1)||(navigator.userAgent.indexOf('MSIE 7')!=-1))openWindow('/!repaste/!repaste_tome_dialog.php?rtype='+rtype+'&uid='+uid+'&do=start',410,357,'转帖');else openWindow('/!repaste/!repaste_tome_dialog.php?rtype='+rtype+'&uid='+uid+'&do=start',410,347,'转帖');}}
function showRepasteEditViewpointDlg(vtype)
{openWindow('/!repaste/!edit_viewpoint_dialog.php?vtype='+vtype+'&do=votestart',410,360,'转帖');}