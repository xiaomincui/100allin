
var ChatGlobal=(function(){var global=function(){this.winWidth=$j(window).width();this.mainWidth=$j("#main").innerWidth();this.chatboxes_inited=false;this.sound=null;this.forbidsound=1;};global.prototype={_chatid:"",elements:{},chatid:function(chatid){if(chatid){this._chatid=chatid;}
return this._chatid;},checkSelector:function(selector){if(!this.elements[selector])
{this.elements[selector]=[];}},addEl:function(selector,el){this.checkSelector(selector);this.elements[selector].push(el);_.flatten(this.elements[selector]);},removeEl:function(selector,el){this.checkSelector(selector);var elements=this.elements;var length=elements.length;for(var i=0;i<length;i++){if(el==elements[i]){el.remove();delete elements[i];_.compact(elements);return;}}},getEl:function(selector){this.checkSelector(selector);return $j(this.elements[selector]);}};return new global();})();var ver_kxchat="0.01";var tipwords=new Array("设置","","我的状态","有空","忙呢","聊天隐身","添加好友",'<a href="/friend/search.php">查找好友</a>',"请先登录","在线好友","我","置为离线","正在加载...","关闭声音提醒",'你目前没有好友在线',"与在线好友聊天","暂时无法访问聊天服务器，请稍后再试","对方已下线，聊天内容下次登录时会看到。","对方为手机登录，可能暂时不方便回复。","选择在线好友，与好友进行实时聊天。","在线");var status_map={AVAILABLE:0,BUSY:1,INVISIBLE:2,OFFLINE:3,MAVAILABLE:4};var tips_map={TYPING:0,SENDFAIL:1,FOFFLINE:2,MONLINE:3};var blinkTimer=0;var blinkSwitch=0;var autopop=0;var minpooltime=600000;var maxpooltime=1200000;var myuid=0;var postvals={};var lockvalues={};var guid="";var offline=0;var windowFocus=true;var ie6=false;var pooltimer;var pooltime=minpooltime;var poolcount=1;var maxcmid=0;var onlineNum=0;var blinkMessages=new Array();var typingtimes=new Hash();var inputtimes=new Hash();var receivetimes=new Hash();var stnotice=0;var basetimer=0;var lastmid="";var openflag=0;function initChat()
{var basediv=document.createElement('div');basediv.setAttribute("id","kxchat_base");document.body.appendChild(basediv);initUI();}
function showOnlineNum(onlineNum)
{if(onlineNum>999)
{onlineNum=999;}
if((onlineNum>=100)&&$j("#kxchat_userstab .kxchat_news").css("display")=='block')
{$j("#kxchat_userstab_text").html(tipwords[9]+'(<span class="online_num">'+onlineNum+'</span>)');}
else
{$j("#kxchat_userstab_text").html(tipwords[9]+'(<span class="online_num">'+onlineNum+'</span>)');}}
function initChatUI(){$j("<div/>").attr("id","kxchat_appstab").addClass("kxchat_tab kxapp_tab").html("我的组件").appendTo($j("#kxchat_base")).click(function(){ChatAppList.getInstance().toggle();}).mouseover(function(){$j(this).addClass("kxchat_appstab_expand");}).mouseout(function(){var chatapplist=ChatAppList.getInstance();if(!chatapplist.app_popup||chatapplist.closed){$j(this).removeClass("kxchat_appstab_expand");}});$j("<div/>").attr("id","kxchat_userstab").addClass("chat_menu").html('<span id="kxchat_userstab_icon2"></span><span id="kxchat_userstab_text" style="float:left"></span><span class="kxchat_news" title="有新消息" style="display:none;"></span>').appendTo($j("#kxchat_base"));var numstr=getCookie("onlinenum");var hasnum=false;if(numstr)
{$j("#kxchat_userstab_icon2").addClass("kxchat_user_available2");var parts=numstr.split(":");if(parts.length==2)
{hasnum=true;showOnlineNum(parseInt(parts[1]));}}
if(!hasnum)
{$j("#kxchat_userstab_text").html('<span class="c9">'+tipwords[12]+'</span>');}
var cssobj={"width":"1004px","right":$j("#kxchat_base").css("right"),"bottom":"0px"};var jel_usertab_popup_base=$j("<div/>").attr("id","kxchat_userstab_popup_base").addClass("kxchat_popup_base").css(cssobj).appendTo($j("body"));ChatGlobal.addEl(".kxchat_popup_base",jel_usertab_popup_base[0]);ChatGlobal.addEl(".kxchat_userstab_popup_base",jel_usertab_popup_base[0]);$j("<div/>").attr("id","kxchat_userstab_popup").addClass("kxchat_tabpopup").css("display","none").html('<div class="kxchat_userstabtitle"><div class="l w120">'+tipwords[15]+'</div><div title="最小化" class="kxchat_minbox"></div><div class="kxchat_setbox" title="设置" style="display:block;"></div></div><div class="kxchat_tabsubtitle"><input id="kxchat_buddysearch" style="border:none ; padding:2px 0 0 0; height: 14px; line-height: 14px; width: 115px;" autocomplete="off" name="kxchat_buddysearch" ><img id="kxchat_buddysearch_clear" class="cp" src="http://img1.kaixin001.com.cn/i2/chat/sear_img.gif" align="absmiddle" /></div><div class="kxchat_tabcontent" style="height: 233px;"><div class="kxchat_userscontent"><div class="kxchat_userslist_available"></div><div class="kxchat_userslist_mavailable"></div><div class="kxchat_userslist_away"></div><div class="kxchat_userslist_offline"></div></div></div><div class="kxchat_usersbbg"></div>').appendTo($j("#kxchat_userstab_popup_base"));var jel_userstab=$j("#kxchat_userstab");var jel_usertab_popup=$j("#kxchat_userstab_popup");var jel_userstabtitle=$j("#kxchat_userstab_popup .kxchat_userstabtitle");jel_usertab_popup.click(function(e){hideUsersTabNotice();BuddyBox.show();});jel_usertab_popup.children(".kxchat_gooffline").click(function(){setChatOffline(1)});var minbox=jel_userstabtitle.children(".kxchat_minbox");minbox.bind("click",function(event){event.preventDefault();hideBuddyBox();return false;}).mouseover(function(){$j(this).addClass("kxchat_minboxhover");}).mouseout(function(){$j(this).removeClass("kxchat_minboxhover");});var setbox=jel_userstabtitle.children(".kxchat_setbox");setbox.bind("click",function(event){BuddyBox.show();createSetPanel();}).mouseover(function(){$j(this).addClass("kxchat_setboxhover");}).mouseout(function(){$j(this).removeClass("kxchat_setboxhover");});jel_userstabtitle.mouseenter(function(){$j(this).addClass("kxchat_chatboxtabtitlemouseover2")}).mouseleave(function(){$j(this).removeClass("kxchat_chatboxtabtitlemouseover2")});jel_userstab.mouseover(function(){if(!$j(this).hasClass("chat_menu_click")){$j(this).removeClass("chat_menu");$j(this).addClass("chat_menu_hover");}
if(offline)
{showChatTip("kxchat_userstab",tipwords[16]);}}).mouseout(function(){if(!$j(this).hasClass("chat_menu_click")){$j(this).removeClass("chat_menu_hover");$j(this).addClass("chat_menu");}
$j("#kxchat_tooltip").css("display","none")});var buddysearch=$j("#kxchat_buddysearch");var search_clear=$j("#kxchat_buddysearch_clear");buddysearch.keyup(function(event){var search_clear=$j("#kxchat_buddysearch_clear");var keycode=event.keyCode;if(keycode!=13&&keycode!=38&&keycode!=40)
{var str=$j(this).val();if(str.length>0){ChatBuddySearch.search($j(this).val());search_clear.show();}else{ChatBuddySearch.resumeBuddyList();search_clear.hide();}}}).bind("click",function(event){event.stopPropagation();});$j("#kxchat_buddysearch_clear").click(function(){$j("#kxchat_buddysearch").val("");ChatBuddySearch.resumeBuddyList();}).hide();jel_userstab.click(function(){if(!offline)
{if($j(this).hasClass("chat_menu_click"))
{hideBuddyBox();}
else
{hideUsersTabNotice();BuddyBox.show();}}})}
function initBar(){ChatGlobal.mainWidth=$j("#main").innerWidth();ChatGlobal.winWidth=$j(window).width();var mainWidth=ChatGlobal.mainWidth;var winWidth=ChatGlobal.winWidth;if(winWidth<320){winWidth=320}
var mval=(winWidth-mainWidth);var marginbt=-1;if(mval%2==1)
{if(!ie6)
{mval--;marginbt=0;}}
else
{if(ie6)
{mval--;marginbt=1;}}
var baseright=mval/2;var chatbase=$j("#kxchat_base");chatbase.css("right",winWidth<=mainWidth?0:baseright+marginbt);ChatGlobal.getEl(".kxchat_popup_base").css("right",$j("#kxchat_base").css("right"));var marginbt2=-1;var right=(parseInt(chatbase.css("right"),10)+marginbt2)+"px";$j("#kxchat_userstab_popup").css("right",right);if(ie6)
{initUIForIE6()}
else
{if(typeof(ChatBoxList)!="undefined")
{ChatBoxList.adjust();}}}
function initUI(){initChatUI();$j("<div/>").attr("id","kxchat_chatboxes").appendTo($j("#kxchat_base"));$j("<div/>").attr("id","kxchat_chatboxes_wide").appendTo($j("#kxchat_chatboxes"));initBar();$j(window).bind("resize",initBar);if(typeof document.body.style.maxHeight==="undefined"){ie6=true;$j("#kxchat_base").css("position","absolute");$j("#kxchat_tooltip").css("position","absolute");$j("#kxchat_supertip").css("position","absolute");$j("#kxchat_userstab_popup").css("position","absolute");$j(window).bind("scroll",function(){switchBaseForIE6();})}
KxRequire('js/kxchat.js',function(){setPostValue("buddy","1");setPostValue("init","1");setPostValue("getmsg","1");Event.observe(window,"blur",winOnBlur);Event.observe(window,"focus",winOnFocus);Event.observe(document,"blur",winOnBlur);Event.observe(document,"focus",winOnFocus);poolchatmsg();});}
function switchBaseForIE6()
{var chatbase=$j("#kxchat_base");var popupbase=ChatGlobal.getEl(".kxchat_popup_base");var tabpopbase=ChatGlobal.getEl(".kxchat_userstab_popup_base");var appspopup=$j("#kxchat_appstab_popup");if(chatbase.css("display")=='block')
{chatbase.css("display","none");tabpopbase.css("display","none");popupbase.css("display","none");appspopup.css("display","none");}
clearTimeout(basetimer);basetimer=setTimeout(function(){chatbase.css("display","block");tabpopbase.css("display","block");popupbase.css("display","block");if(!ChatAppList.getInstance().closed)
{appspopup.css("display","block");}
initUIForIE6();},500);}
function winOnBlur()
{if(!windowFocus)
{return;}
windowFocus=false;blinkWinNotice();}
function winOnFocus()
{if(windowFocus)
{return;}
windowFocus=true;blinkWinNotice();}
function initUIForIE6(){var chatbase=$j("#kxchat_base");ChatGlobal.getEl(".kxchat_popup_base").add(chatbase).css("top",($j(window).scrollTop()+$j(window).height()-27)+"px");var popup=$j("#kxchat_userstab_popup");if(popup.hasClass('kxchat_tabopen'))
{var top=parseInt($j(window).height())-parseInt($j("#kxchat_userstab_popup").css("bottom"))-parseInt($j("#kxchat_userstab_popup").height())+$j(window).scrollTop()+1;ChatGlobal.getEl(".kxchat_popup_base").children(".kxchat_tabpopup").add($j("#kxchat_userstab_popup")).css("top",top+"px");var marginbt=-1;popup.css("right",parseInt($j("#kxchat_base").css("right"),10)+marginbt);}
if(typeof(ChatAppList)!="undefined")
{ChatAppList.getInstance().adjust();}
if(typeof(ChatBoxList)!="undefined")
{ChatBoxList.adjust();}
var tooltip=$j("#kxchat_tooltip");if(tooltip.length>0){tooltip.css("top",parseInt($j(window).height())-parseInt(tooltip.css("bottom"))-parseInt(tooltip.height())+$j(window).scrollTop()+"px")}
var supertip=$j("#kxchat_supertip");if(supertip.length>0&&(supertip.css("display")=="block"))
{supertip.css("top",parseInt($j(window).height())-parseInt(supertip.css("bottom"))-parseInt(supertip.height())+$j(window).scrollTop()+"px")}}
function g_chatwith(uid)
{if('function'==typeof(chatWith))
{openflag=1;chatWith(uid);}}
jQuery(document).ready(function(){var href=window.location.href;if(href.indexOf("/set/")==-1&&href.indexOf("/pay/")==-1&&href.indexOf("upload")==-1)
{initChat();}});