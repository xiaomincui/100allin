
var buddylist=new ChatBuddyList();var failpoolcount=0;function getzhstatusstr(status)
{var statusstr="";status=parseInt(status,10);switch(status)
{case status_map.AVAILABLE:statusstr="在线有空";break;case status_map.BUSY:statusstr="忙";break;case status_map.INVISIBLE:statusstr="隐身";break;case status_map.OFFLINE:statusstr="联机失败";break;case status_map.MAVAILABLE:statusstr="手机在线";break;default:statusstr="有空";break;}
return statusstr;}
function getenstatusstr(status)
{var statusstr="";status=parseInt(status,10);switch(status)
{case status_map.AVAILABLE:statusstr="available";break;case status_map.BUSY:statusstr="busy";break;case status_map.INVISIBLE:statusstr="invisible";break;case status_map.OFFLINE:statusstr="offline";break;case status_map.MAVAILABLE:statusstr="mavailable";break;default:statusstr="available";break;}
return statusstr;}
function getInnerStatus(chatbuddy)
{return getInnerOnline(chatbuddy.online);}
function getInnerOnline(online)
{var innerstatus=0;if(online==ChatBuddyStatus.OnlineStatus.USER_ONLINE_WEB)
{innerstatus=status_map.AVAILABLE;}
else if(online==ChatBuddyStatus.OnlineStatus.USER_ONLINE_WAP)
{innerstatus=status_map.MAVAILABLE;}
else
{innerstatus=status_map.OFFLINE;}
return innerstatus;}
function blinkWinNotice()
{if(windowFocus==false)
{if(blinkMessages.length>0&&(blinkTimer==0))
{blinkTimer=setInterval(blinkNewChatMsg,1000);}}
else
{clearAllBlink();}}
function changeUserStatus(uid,status)
{var botstatus=$j("#kxchat_user_"+uid+" .kxchat_closebox_bottom_status");botstatus.removeClass("kxchat_offline kxchat_available kxchat_mavailable");botstatus.addClass("kxchat_"+getenstatusstr(status));}
function blinkNewChatMsg()
{if(windowFocus)
{return;}
var now=new Date();var nowtime=now.getTime();if(nowtime-g_inputtime>5000)
{var len=blinkMessages.length;if(len>0)
{var idx=blinkSwitch%len;var usermsg=blinkMessages[idx].split(",");if(usermsg[1].length>0)
{var msg=usermsg[1]+'说...';document.title=blinkSwitch%2?"【　　　】 - "+g_blinktitle:"【"+msg+"】 - "+g_blinktitle;}}
else
{stopBlinkNewChatMsg();}}
blinkSwitch++;}
function stopBlinkNewChatMsg()
{if(blinkTimer)
{clearInterval(blinkTimer);blinkTimer=0;document.title=g_blinktitle;}}
function showSuperTip(elem,html)
{if($("kxchat_supertip")){$$("#kxchat_supertip .kxchat_supertip_content")[0].update(html);}else{var ptip=document.createElement('div');ptip.setAttribute("id","kxchat_supertip");ptip.innerHTML='<div class="kxchat_supertip_content">'+html+'</div><div class="r"><a href="javascript:h(\'kxchat_supertip\');" title="关闭"><img src="http://img1.kaixin001.com.cn/i2/chat/tip_close.gif" /></a></div>';ptip.style.display="none";document.body.appendChild(ptip);}
var elem_width=parseInt($j("#"+elem).css("width"),10);var elem_offset_left=parseInt($j("#"+elem).offset().left,10);var supertip=$j("#kxchat_supertip");var tipwidth=parseInt(supertip.css("width"),10);supertip.css({'bottom':'29px','left':((elem_offset_left+elem_width)-tipwidth-8)+'px','display':"block"}).removeClass("kxchat_supertip_left");if(ie6){supertip.css("position","absolute");supertip.css("top",parseInt($j(window).height())-parseInt(supertip.css("bottom"))-parseInt(supertip.height())+$j(window).scrollTop()+"px")}}
function showChatTip(elem,html)
{if($("kxchat_tooltip")){$$("#kxchat_tooltip .kxchat_tooltip_content")[0].update(html);}else{var ptip=document.createElement('div');ptip.setAttribute("id","kxchat_tooltip");ptip.innerHTML='<div class="kxchat_tooltip_content">'+html+"</div>";document.body.appendChild(ptip);}
var elem_width=parseInt($j("#"+elem).width(),10);var elem_offset_left=parseInt($j("#"+elem).offset().left,10);var tooltip=$j("#kxchat_tooltip");var tipwidth=parseInt(tooltip.width(),10);$("kxchat_tooltip").setStyle({'bottom':'29px','left':((elem_offset_left+elem_width)-tipwidth-8)+'px','display':"block"}).removeClassName("kxchat_tooltip_left");if(ie6){tooltip.css("position","absolute");tooltip.css("top",parseInt($j(window).height())-parseInt(tooltip.css("bottom"))-parseInt(tooltip.height())+$j(window).scrollTop()+"px")}}
function checkChatBoxInputKey(event,uid)
{var now=new Date();var lastinput=typingtimes.get(uid);var typing=false;if(lastinput&&(now.getTime()-lastinput)>30000)
{typing=true;}
else if(!lastinput)
{typing=true;}
inputtimes.set(uid,now.getTime());g_inputtime=now.getTime();if(typing)
{typingtimes.set(uid,now.getTime());var url="/chat/typing.php";var pars="otheruid="+uid;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onSuccess:function(req)
{},onFailure:function(req)
{}});}
if($j("#kxchat_user_"+uid+"_popup .kxchat_tabtitle").hasClass("kxchat_tabtitle_newmsg"))
{ChatBoxList.get(uid).removeNotification();}
var textarea=$j("#kxchat_user_"+uid+"_popup .kxchat_textarea");var message=textarea.val();if(message.length>2000)
{textarea.val(message.substr(0,2000));}
if(event.keyCode==13&&(!event.shiftKey)){return sendchatmsg(uid);}}
function sendchatmsg(uid)
{var textarea=$j("#kxchat_user_"+uid+"_popup .kxchat_textarea");var message=textarea.val();var chatbuddy=buddylist.get(uid);if(offline)
{if(chatbuddy)
{hideContentTip(uid);showContentTip(uid,tips_map.SENDFAIL);}
return false;}
message=message.replace(/^\s+|\s+$/g,"");textarea.val("");textarea.focus();if(message==""){return false;}
var cmitem=new Object();var date=new Date();cmitem.ctime=getDateFormat(date);cmitem.cmid=date.getTime()+""+Math.ceil(Math.random()*10000);var showmessage=message.replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br>").replace(/\"/g,"&quot;")
showmessage=kxface_parseFaces(showmessage);showOneMsg(uid,showmessage,1,cmitem);setTimeout("historyScroll("+uid+")",10);$j.ajax({url:"/chat/send.php",data:{otheruid:uid,content:message,chatid:ChatGlobal.chatid()},type:"post",cache:false,error:function()
{if(chatbuddy)
{hideContentTip(uid);showContentTip(uid,tips_map.SENDFAIL);}},success:function(req)
{poolcount=1;if(pooltime>minpooltime){pooltime=minpooltime;clearTimeout(pooltimer);pooltimer=setTimeout(function(){poolchatmsg()},minpooltime)}}});return false;}
function resetStatus(){var icon2=$j("#kxchat_userstab_icon2");icon2.removeClass("kxchat_user_offline kxchat_user_available2 kxchat_user_busy2 kxchat_user_invisible2")}
function changeSetting()
{stnotice=$("chkstnotice").checked?1:0;createSetPanel();var url="/chat/updatenotice.php";var pars="action=setstnotice&stnotice="+stnotice;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onSuccess:function(req)
{changeSettingFinished(req);},onFailure:function(req)
{}});}
function changeSettingFinished(req)
{if(req.responseText=="0")
{alert("更新失败");}}
function switchChatOffline(off)
{resetStatus();offline=off;var icon2=$j("#kxchat_userstab_icon2");if(off)
{icon2.addClass("kxchat_user_offline");}
else
{icon2.addClass("kxchat_user_available2");}}
function setChatOffline(skipupdate){setTimeout(_setChatOffline,5000);}
function _setChatOffline()
{switchChatOffline(1);$j("#kxchat_userstab_popup").removeClass("kxchat_tabopen");$j("#kxchat_userstab").removeClass("kxchat_userstabclick kxchat_tabclick");$j("#kxchat_userstab_text").html(getzhstatusstr(status_map.OFFLINE));setOpenBoxesOffline();}
function setChatBuddyOnline(uid,online)
{var chatbuddy=buddylist.get(uid);if(!chatbuddy&&online)
{var url="/chat/getinfo.php";var pars="otheruid="+uid;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onSuccess:function(req)
{var user=null;eval("user ="+req.responseText);if(user<0)
{return;}
var chatbuddy=new ChatBuddy(user.uid,user.real_name,user.logo20,user.online);buddylist.add(chatbuddy);BuddyBox.addBuddy(user.uid);},onFailure:function(req)
{}});}
else
{var oldonline=false;if(chatbuddy)
{oldonline=chatbuddy.online;chatbuddy.setOnline(online);buddylist.add(chatbuddy);}
if(chatbuddy&&chatbuddy.real_name!="")
{if(!oldonline&&online&&ChatBoxList.exists(uid))
{hideContentTip(uid);}
if(oldonline!=online)
{var innerstatus=getInnerOnline(online);changeUserStatus(uid,innerstatus);BuddyBox.removeBuddy(uid);BuddyBox.addBuddy(uid);if(!online)
{onlineNum--;if(ChatBoxList.exists(uid))
{showContentTip(uid,tips_map.FOFFLINE);}}
if(onlineNum>=0)
{showOnlineNum(onlineNum);}
else
{onlineNum=0;}}}}}
function closeChatBox(uid)
{if($("chatbox_"+uid+"_face"))
{new KxFace(uid).removePanel();}
$j("#kxchat_user_"+uid+"_popup").parent().remove();var chatbox=$j("#kxchat_user_"+uid);chatbox.data("uploader").remove();chatbox.remove();ChatBoxList.remove(uid);if(guid==uid){guid="";}
initBar();setActiveBoxes();}
function setOpenBoxesOffline()
{$j("#kxchat_chatboxes_wide div").each(function()
{if($j(this).attr("id").substr(0,11)=="kxchat_user")
{uid=$j(this).attr("id").substr(12);changeUserStatus(uid,status_map.OFFLINE);}});}
function controlActiveBoxes(time)
{var chatcount=0;var firstuid=0;var time=0;var utime=0;var uid=0;var minuid=0;$j("#kxchat_chatboxes_wide div").each(function(){if($j(this).attr("id").substr(0,11)=="kxchat_user")
{uid=$j(this).attr("id").substr(12);utime=receivetimes.get(uid);if(firstuid==0)
{firstuid=uid;minuid=uid;time=utime;}
else
{if(utime<time)
{time=utime;minuid=uid;}}
chatcount++;}});if(chatcount==ChatBoxList.MAX_NUM)
{if(time)
{chatCloseNotify(minuid);}
else
{chatCloseNotify(firstuid);}}}
function getFirstActiveBoxUid()
{var firstuid=0;$j("#kxchat_chatboxes_wide div").each(function(){if($j(this).attr("id").substr(0,11)=="kxchat_user")
{if(firstuid==0)
{firstuid=$j(this).attr("id").substr(12);}}});return firstuid;}
function setOpenBoxes(){var openboxstr="";var uid="";$j("#kxchat_chatboxes_wide div").each(function(){if($j(this).attr("id").substr(0,11)=="kxchat_user")
{uid=$j(this).attr("id").substr(12);if($j("#kxchat_user_"+uid+"_popup").hasClass("kxchat_tabopen"))
{openboxstr+=uid+",";}}});openboxstr=openboxstr.slice(0,-1);setCookie("ocb",openboxstr,null,'/');}
function setActiveBoxes(){var boxstr="";var openboxstr="";var uid="";var ncount=0;var tabalert=null;$j("#kxchat_chatboxes_wide div").each(function(){if($j(this).attr("id").substr(0,11)=="kxchat_user")
{uid=$j(this).attr("id").substr(12);ncount=0;tabalert=$j("#kxchat_user_"+uid+" .kxchat_tabalert");if(tabalert.length>0){ncount=parseInt(tabalert.html())}
boxstr+=uid+"|"+ncount+","
if($j("#kxchat_user_"+uid+"_popup").hasClass("kxchat_tabopen"))
{openboxstr+=uid+",";}}});boxstr=boxstr.slice(0,-1);openboxstr=openboxstr.slice(0,-1);setCookie("acb",boxstr,null,'/');setCookie("ocb",openboxstr,null,'/');}
function switchChatTab(uid,open)
{if(open)
{var cssobj={'z-index':'-1','display':'none'};$j("#kxchat_"+uid+"_closebar").css(cssobj);cssobj={"z-index":"1","width":"","height":"","position":"static"};if(ie6)
{cssobj["display"]="block";}
$j("#chatbox_"+uid+"_record").css(cssobj);}
else
{var cssobj={'z-index':'1','display':'block'};$j("#kxchat_"+uid+"_closebar").css(cssobj);cssobj={"z-index":"-1","width":"0","height":"0","position":"relative"};if(ie6)
{cssobj["display"]="none";}
$j("#chatbox_"+uid+"_record").css(cssobj);}}
function switchFacePanel(uid)
{if($("chatbox_"+uid+"_face"))
{$("divbtnface_"+uid).removeClassName("face_down");}
else
{$("divbtnface_"+uid).addClassName("face_down");}
new KxFace(uid).facePanel();}
function receiveChat(uid){$j.ajax({url:"/chat/start.php",data:{otheruid:uid,oflag:openflag,chatid:ChatGlobal.chatid()},type:"get",cache:false,dataType:"json",success:function(retval){if(retval){var skip=false;switch(retval)
{case-2:alert("不是好友，不能在线聊天");skip=true;break;case-3:alert("对方暂时没有聊天功能，不能聊天");skip=true;break;case-4:alert("不能跟自己聊天");skip=true;break;case-5:alert("暂不提供与名人/机构用户的聊天功能");skip=true;break;}
if(skip)
{justCloseChatbox(uid);return;}
var chatbuddy=buddylist.get(uid);if(!chatbuddy||chatbuddy.real_name=="")
{alert("对不起获取用户信息失败！");return;}
setChatBuddyOnline(uid,retval.online);chatbuddy.online=retval.online;buddylist.add(chatbuddy);var tabcontenttext=$j("#kxchat_user_"+uid+"_popup .kxchat_tabcontenttext");tabcontenttext.html("");var html="";var username=chatbuddy.real_name;var msgs=retval.msgs;msgs.each(function(msgitem){msgitem.content=kxface_parseFaces(msgitem.content);var msgclass="kxchat_chatboxmessageother";if(msgitem.direction=='send')
{msgclass="kxchat_chatboxmessageme";fromname=tipwords[10];}
else
{fromname='<a href="/home/?uid='+uid+'">'+username+'</a>';}
html=('<div class="kxchat_chatboxmessage" id="kxchat_message_'+msgitem.cmid+'"><span class="'+msgclass+'">'+fromname+' '+msgitem.ctime+'</span><br /> <span class="kxchat_chatboxmessagecontent">'+msgitem.content+"</span></div>")+html;});tabcontenttext.append(html);setTimeout("historyScroll("+uid+")",500);}}})
openflag=0;}
function openFaceBox(uid)
{ChatBoxList.get(uid).active();switchFacePanel(uid);}
function openHistory(uid)
{ChatBoxList.get(uid).active();clickDirect('/msg/history.php?type=chat&touid='+uid+'&t='+Math.random());}
function showUsersTabNotice()
{if(!$j("#kxchat_userstab_popup").hasClass("kxchat_tabopen"))
{$j("#kxchat_userstab .kxchat_news").css("display","block");showOnlineNum(onlineNum);}}
function hideUsersTabNotice()
{$j("#kxchat_userstab .kxchat_news").css("display","none");showOnlineNum(onlineNum);}
function showAlert(uid,newcount,hadnew){if(ChatBoxList.exists(uid)){ChatBoxList.get(uid).gotNewMsg();}else if(ChatBoxList.count()>=ChatBoxList.MAX_NUM){BuddyBox.notifyNewMsgFrom(uid);showUsersTabNotice();}else{openChatBoxByUid(uid);var chatbox=ChatBoxList.get(uid);if(chatbox)
{chatbox.gotNewMsg();}}}
function hideBuddyBox()
{BuddyBox.hide();BuddyBox.checkTabNotice();}
function createSetPanel()
{var setpanel=$j("#kxchat_setpanel");if(setpanel.length>0&&setpanel.css("display")=='none')
{setpanel.css("display","block");}
else if(setpanel.length>0&&setpanel.css("display")=='block')
{setpanel.css("display","none");}
else
{$j("<div/>").attr("id","kxchat_setpanel").html('<div class="mt5 ml12"><div class=l style="margin-top: 3px; *margin-top:0px;"><input type=checkbox id=chkstnotice /></div><div class="l ml5">来新消息时只提示，<br/>不弹出对话框</div><div class="c" style="height:1px; line-height:1px;"></div></div><div style="padding:5px 0 0 20px;"> <div class="rbs1"><input type="submit" id="btn_sc" value="保存"  class="rb1-12" onmouseover="this.className=\'rb2-12\';" onmouseout="this.className=\'rb1-12\';" onclick="changeSetting();" /></div><div class="l p5">&nbsp;</div><div class="gbs1"><input type="button" id="btn_qx" value="取消"  class="gb1-12" onmouseover="this.className=\'gb2-12\';" onmouseout="this.className=\'gb1-12\';" onclick="h(\'kxchat_setpanel\');" /></div></div>').css("display","none").appendTo($j("#kxchat_userstab_popup"));setpanel.css("display","block");}
$("chkstnotice").checked=(stnotice==1);}
function setPostValue(key,val){postvals[key]=val;}
function getPostValue(ar){if(postvals[ar]){return postvals[ar]}else{return""}}
function setLockValue(key,val){lockvalues[key]=val}
function getLockValue(key){if(lockvalues[key]){return lockvalues[key]}else{return""}}
function chatWith(uid)
{if(uid==myuid)
{alert("不能跟自己聊天");return;}
var chatbuddy=buddylist.get(uid);if(chatbuddy&&chatbuddy.real_name!="")
{_openChatBoxByUid(uid,0);}
else
{var url="/chat/getinfo.php";var pars="otheruid="+uid;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onSuccess:function(req)
{var user=null;eval("user ="+req.responseText);if(user==-2)
{alert("不是好友，不能在线聊天");return;}
else if(user==-5)
{alert("暂不提供与名人/机构用户的聊天功能");return;}
var chatbuddy=new ChatBuddy(user.uid,user.real_name,user.logo20,user.online);buddylist.add(chatbuddy);BuddyBox.addBuddy(user.uid);_openChatBoxByUid(user.uid,0);},onFailure:function(req)
{}});}}
function openChatBoxFromBuddy(at){openflag=2;var uid=$j(at).attr("id").substr(16);var chatbox=_openChatBoxByUid(uid,0);if(chatbox){chatbox.show();}
hideBuddyBox();}
function _openChatBoxByUid(uid,min)
{uid=parseInt(uid,10);if(uid>0)
{var chatbuddy=buddylist.get(uid);if(chatbuddy)
{openChatBox(uid,chatbuddy.real_name,chatbuddy.status,min);}}}
function openChatBoxByUid(uid){_openChatBoxByUid(uid,1);}
function showOneMsg(uid,content,self,cmitem,notice){var chatbuddy=buddylist.get(uid);if(!chatbuddy)
{return;}
if(!self)
{var chatbox=openChatBox(uid,chatbuddy.real_name,chatbuddy.status,!autopop,notice);chatbuddy=buddylist.get(uid);if(chatbuddy&&chatbuddy.hasbox==0)
{return;}}
var msgclass="kxchat_chatboxmessageother";if(self==1){msgclass="kxchat_chatboxmessageme";fromname=tipwords[10];}else{fromname='<a href="/home/?uid='+uid+'">'+chatbuddy.real_name+'</a>';}
if(parseInt(cmitem.cmid,10)>parseInt(maxcmid,10))
{maxcmid=cmitem.cmid;}
if(chatbox)chatbox.addCmid(cmitem.cmid);if($j("#kxchat_message_"+cmitem.cmid).length>0)
{$j("#kxchat_message_"+cmitem.cmid+" .kxchat_chatboxmessagecontent").html(content);}
else
{$j("#kxchat_user_"+uid+"_popup .kxchat_tabcontenttext").append('<div class="kxchat_chatboxmessage" id="kxchat_message_'+cmitem.cmid+'"><span class="'+msgclass+'">'+fromname+' '+cmitem.ctime+'</span><br /><span class="kxchat_chatboxmessagecontent">'+content+"</span></div>");}
if(!self){showAlert(uid,1,1)}}
function historyScroll(uid)
{var tabcontenttext=$j("#kxchat_user_"+uid+"_popup .kxchat_tabcontenttext");if(tabcontenttext[0])
{tabcontenttext[0].scrollTop=tabcontenttext[0].scrollHeight;}}
function showTypingTip(tip)
{var uid=parseInt(tip.uid,10);if($j("#kxchat_user_"+uid+"_popup").length>0)
{showContentTip(uid,tips_map.TYPING);setTimeout("hideTypingTip("+uid+")",30000);}}
function showContentTip(uid,type)
{if($j("#kxchat_user_"+uid+"_popup").length>0)
{var html="";var chatbuddy=null;var aclass="";switch(type)
{case tips_map.TYPING:aclass="typing";chatbuddy=buddylist.get(uid)
html=chatbuddy.real_name+"正在输入...";break;case tips_map.SENDFAIL:aclass="sendfail";chatbuddy=buddylist.get(uid)
html="给"+chatbuddy.real_name+"发送消息失败";break;case tips_map.FOFFLINE:aclass="foffline";html=tipwords[17];break;case tips_map.MONLINE:aclass="foffline";html=tipwords[18];break;default:html="";break;}
if(aclass=="foffline")
{if(last_chat_msg[uid]&&(new Date()).getTime()-last_chat_msg[uid]<60000)
{return;}}
if(html)
{var tabcontenttip=$j("#kxchat_user_"+uid+"_popup .kxchat_tabcontenttip");tabcontenttip.removeClass("typing sendfail foffline");$j("#kxchat_user_"+uid+"_popup .kxchat_tabcontenttext").css("height",170+"px");tabcontenttip.addClass(aclass);tabcontenttip.css("display","block");tabcontenttip.html(html);setTimeout("historyScroll("+uid+")",10);}}}
function hideContentTip(uid)
{if($j("#kxchat_user_"+uid+"_popup").length>0)
{var tabcontenttip=$j("#kxchat_user_"+uid+"_popup .kxchat_tabcontenttip");$j("#kxchat_user_"+uid+"_popup .kxchat_tabcontenttext").css("height",189+"px");tabcontenttip.css("display","none");tabcontenttip.html("");setTimeout("historyScroll("+uid+")",10);}}
function hideTypingTip(uid)
{hideContentTip(uid);}
function chatMsgSound()
{if(ChatGlobal.forbidsound=="1")return;if(ChatGlobal.sound==null)
{ChatGlobal.sound=new SWFObject("http://img1.kaixin001.com.cn/i2/newmsg_sound.1.0.swf","newmsg_sound_swf","1","1","8","#ffffff",true);ChatGlobal.sound.addParam("allowscriptaccess","always");ChatGlobal.sound.addParam("wmode","opaque");ChatGlobal.sound.addParam("menu","false");ChatGlobal.sound.addVariable("autoplay","0");}
ChatGlobal.sound.write("head_msgsound_div");}
var last_chat_msg={};function _showImMessage(msg)
{if(msg.uid==myuid&&msg.chatid==ChatGlobal.chatid())
{return;}
var html="";var uid=parseInt(msg.uid,10);msg.content=kxface_parseFaces(msg.content);if((guid)==(uid))
{showOneMsg(uid,msg.content,uid==myuid,msg,1);setTimeout("historyScroll("+guid+")",500);if((windowFocus==false))
{if(uid!=myuid)
{var chatbuddy=buddylist.get(uid);var fromname=chatbuddy.real_name;blinkMessages.push(uid+","+fromname);}}}
else
{var nobox=1;var self=0;var msguid=msg.uid;if(msg.uid==myuid)
{msguid=msg.otheruid;self=1;}
else
{if((windowFocus==false))
{var chatbuddy=buddylist.get(uid);var fromname=chatbuddy.real_name;blinkMessages.push(uid+","+fromname);}
nobox=!(ChatBoxList.exists(uid));}
if(stnotice&&!self)
{BuddyBox.notifyNewMsgFrom(msguid);showUsersTabNotice();}
else
{if((!ChatBoxList.exists(msguid))&&ChatBoxList.count()>=ChatBoxList.MAX_NUM&&nobox&&!self)
{BuddyBox.notifyNewMsgFrom(msguid);showUsersTabNotice();}
else
{showOneMsg(msguid,msg.content,self,msg,1);}}
if(guid==""&&autopop==1&&nobox==1){$j("#kxchat_user_"+msguid).click()}
setTimeout("historyScroll("+msguid+")",500);}
if(msg.uid!=myuid)
{chatMsgSound();}}
function showImMessage(msg)
{var uid=parseInt(msg.uid,10);var chatbuddy=buddylist.get(uid);if(chatbuddy||uid==myuid)
{_showImMessage(msg);}
else
{var url="/chat/getinfo.php";var pars="otheruid="+msg.uid;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onSuccess:function(req)
{var user=null;eval("user ="+req.responseText);if(user<0)
{return;}
var chatbuddy=new ChatBuddy(user.uid,user.real_name,user.logo20,user.online);buddylist.add(chatbuddy);BuddyBox.addBuddy(chatbuddy.uid);_showImMessage(msg);},onFailure:function(req)
{}});}
if(uid!=myuid)
{blinkWinNotice();last_chat_msg[uid]=(new Date()).getTime();}}
function addToBuddyList(buddyitem)
{var chatbuddy=buddylist.get(buddyitem.uid);var innerstatus=0;if(!chatbuddy)
{chatbuddy=new ChatBuddy(buddyitem.uid,buddyitem.real_name,buddyitem.logo20,buddyitem.online);}
else
{chatbuddy.setUserProfile(buddyitem.real_name,buddyitem.logo20);}
buddylist.add(chatbuddy);return chatbuddy;}
function poolchatmsg(){postvals.cmid=maxcmid;var html="";var buddylistshtml={};buddylistshtml[status_map.AVAILABLE]="";buddylistshtml[status_map.BUSY]="";buddylistshtml[status_map.INVISIBLE]="";buddylistshtml[status_map.MAVAILABLE]="";buddylistshtml[status_map.OFFLINE]="";buddylistreceived=0;var chatbuddy=null;onlineNumber=0;$j.ajax({url:"/chat/startchat.php",data:postvals,type:"post",cache:false,timeout:10000,dataType:"json",error:function(req,textStatus,errorThrown){if(req.responseText.indexOf("DOCTYPE")!=-1)
{return;}
if(failpoolcount>2)
{setChatOffline(1);setPostValue("buddy","1");setPostValue("init","1");setPostValue("getmsg","1");}
clearTimeout(pooltimer);pooltimer=setTimeout(function(){poolchatmsg()},pooltime*0.1);failpoolcount++;return;},success:function(initret)
{setPostValue("buddy","1");if(initret)
{switchChatOffline(0);var au=0;var isinit=getPostValue("init");$j.each(initret,function(inittype,inititems)
{if(inittype=="buddylist")
{var nowboxes=new Array();buddylistreceived=1;onlineNumber=0;totalFriendsNumber=0;$j.each(inititems,function(buddyidx,buddyitem){var chatbuddy=addToBuddyList(buddyitem);var innerstatus=chatbuddy.status;if(isinit)
{if($j("#kxchat_user_"+buddyitem.uid).length>0)
{changeUserStatus(buddyitem.uid,innerstatus);}}
if(chatbuddy.online)
{onlineNumber++}
totalFriendsNumber++;var dispnewmsg=chatbuddy.newcount>0?"block":"none";buddylistshtml[innerstatus]+='<div id="kxchat_userlist_'+buddyitem.uid+'" class="kxchat_userlist" onmouseover="jQuery(this).addClass(\'kxchat_userlist_hover\');" onmouseout="jQuery(this).removeClass(\'kxchat_userlist_hover\');"><span class="l"><img src="'+buddyitem.logo20+'" /></span><span class="kxchat_userscontentname l">'+chatbuddy.short_name+'</span><span class="kxchat_list_newmsg l"  title="有新消息"  style="display:'+dispnewmsg+';">'+chatbuddy.newcount+'</span><span class="kxchat_userscontentdot kxchat_'+getenstatusstr(innerstatus)+' l"></span></div>';nowboxes.push(parseInt(buddyitem.uid,10));});}
if(buddylistreceived==1)
{var boxstr=getCookie("acb");var chatboxes="";var count=0;if(boxstr)
{chatboxes=boxstr.split(/,/);count=chatboxes.length;for(i=0;i<count;i++)
{var chatbox_status=chatboxes[i].split(/\|/);openChatBoxByUid(chatbox_status[0]);if(parseInt(chatbox_status[1])>0)
{showAlert(chatbox_status[0],chatbox_status[1],0)}}}
if(ChatGlobal.chatboxes_inited==false)
{var openboxstr=getCookie("ocb");if(openboxstr)
{chatboxes=openboxstr.split(/,/);count=chatboxes.length;for(i=0;i<count;i++)
{$j("#kxchat_user_"+parseInt(chatboxes[i],10)).click();}}
ChatGlobal.chatboxes_inited=true;}
if(boxstr)
{var boxarray=boxstr.split(",");boxarray.each(function(item)
{var bparts=item.split("|");var buid=parseInt(bparts[0],10);if(buid>0&&nowboxes.indexOf(buid)==-1)
{chatbuddy=buddylist.get(buid);if(chatbuddy)
{var dispnewmsg=chatbuddy.newcount>0?"block":"none";var innerstatus=chatbuddy.status;buddylistshtml[innerstatus]+='<div id="kxchat_userlist_'+buid+'" class="kxchat_userlist" onmouseover="jQuery(this).addClass(\'kxchat_userlist_hover\');" onmouseout="jQuery(this).removeClass(\'kxchat_userlist_hover\');"><span class="l"><img src="'+chatbuddy.logo20+'" /></span><span class="kxchat_userscontentname l">'+chatbuddy.short_name+'</span><span class="kxchat_list_newmsg l"  title="有新消息"  style="display:'+dispnewmsg+';">'+chatbuddy.newcount+'</span><span class="kxchat_userscontentdot kxchat_'+getenstatusstr(innerstatus)+' l"></span></div>';}}});}
var userlist=null;for(buddystatus in buddylistshtml)
{userlist=$j("#kxchat_userstab_popup .kxchat_tabcontent .kxchat_userscontent .kxchat_userslist_"+getenstatusstr(buddystatus));if(buddylistshtml[buddystatus].length==0)
{userlist.hide();}
else
{userlist.html(buddylistshtml[buddystatus]).show();userlist.children().click(function(e){e.stopPropagation();openChatBoxFromBuddy(this)});}}
if(onlineNum!=onlineNumber)
{pooltime=minpooltime;poolcount=1;}
onlineNum=onlineNumber;showOnlineNum(onlineNum);if(totalFriendsNumber==0)
{$j("#kxchat_userstab_popup .kxchat_tabcontent .kxchat_userscontent .kxchat_userslist_available").html('<div class="kxchat_nofriends">'+tipwords[14]+"</div>")}
buddylistreceived=0;initBar();}
if(inittype=="mystatus")
{stnotice=inititems.stnotice;myuid=inititems.uid;var status=inititems.status;if(status==status_map.OFFLINE)
{setChatOffline(1)}
else
{resetStatus();$j("#kxchat_userstab_icon2").addClass("kxchat_user_"+getenstatusstr(status)+"2");}
var init=inititems.init;if(init==1)
{setTimeout("showSuperTip(\"kxchat_userstab\", \""+tipwords[19]+"\")",2000);}}
if(inittype=="messages")
{var fusers=inititems['fusers'];var fmsgs=inititems['fmsgs'];maxcmid=inititems['maxcmid'];var msgs=null;var now=0;fusers.each(function(uid){now=new Date();receivetimes.set(uid,now.getTime());msgs=fmsgs[uid].msgs;var msglen=msgs.length;var needshow=false;var chatbox=ChatBoxList.get(uid);for(var i=msglen-1;i>=0;i--)
{msg=msgs[i];msg.content=kxface_parseFaces(msg.content);if(!needshow&&msg.direction=='receive')
{needshow=true;}
if((guid)==(fmsgs[uid].otheruid))
{++au;var name=fmsgs[uid].real_name;var msgclass="kxchat_chatboxmessageother";if(msg.direction=='send')
{msgclass="kxchat_chatboxmessageme";fromname=tipwords[10]}
else
{fromname='<a href="/home/?uid='+uid+'">'+name+'</a>';}
if($j("#kxchat_message_"+msg.cmid).length>0)
{$j("#kxchat_message_"+msg.cmid+" .kxchat_chatboxmessagecontent").html(msg.content)}
else
{html+=('<div class="kxchat_chatboxmessage" id="kxchat_message_'+msg.cmid+'"><span class="'+msgclass+'">'+fromname+' '+msg.ctime+'</span><br /><span class="kxchat_chatboxmessagecontent">'+msg.content+"</span></div>");}
if(chatbox&&msg.cmid)
{chatbox.addCmid(msg.cmid);}}
else
{var nobox=0;if($j("#kxchat_user_"+fmsgs[uid].otheruid).length<=0)
{nobox=1}
var self=0;if(msg.direction=='send')
{self=1;}
showOneMsg(fmsgs[uid].otheruid,msg.content,self,msg);if(guid==""&&autopop==1&&nobox==1)
{$j("#kxchat_user_"+fmsgs[uid].otheruid).click()}}};if(needshow&&(windowFocus==false))
{blinkMessages.push(uid+","+fmsgs[uid].real_name);}});poolcount=1;pooltime=minpooltime;blinkWinNotice();}
if(inittype=="upload")
{ChatUploaderConfig.set(inititems);}
if(inittype=="chatid")
{ChatGlobal.chatid(inititems);}
if(inittype=="forbidsound")
{ChatGlobal.forbidsound=inititems;}});if(guid!=""&&au>0)
{$j("#kxchat_user_"+guid+"_popup .kxchat_tabcontenttext").append(html);setTimeout("historyScroll("+guid+")",500);}}
else
{if(failpoolcount>2)
{setChatOffline(1);setPostValue("buddy","1");setPostValue("init","1");setPostValue("getmsg","1");}
clearTimeout(pooltimer);failpoolcount++;pooltimer=setTimeout(function(){poolchatmsg();},pooltime*0.1);return;}
setPostValue("getmsg","0");setPostValue("init","0");if(offline!=1)
{poolcount++;if(poolcount>4)
{pooltime*=2;poolcount=1;}
if(pooltime>maxpooltime)
{pooltime=maxpooltime;}
clearTimeout(pooltimer);pooltimer=setTimeout(function(){poolchatmsg()},pooltime);}}});}
function relocateFacePanel(uid)
{var tdiv=$("chatbox_"+uid+"_face");if(tdiv)
{var btn=$("chatbox_"+uid+"_face_icon");var popup=$j("#kxchat_user_"+uid+"_popup");var btn_pos=getpos(btn);if(ie6)
{tdiv.style.top=(parseInt(popup.css("top"))+65)+"px";tdiv.style.left=(parseInt(popup.css("left"))+7)+"px";}
else
{tdiv.style.bottom="30px";tdiv.style.left=(btn_pos.left-1)+"px";}}}
function ChatBuddy(uid,real_name,logo20,online)
{this.uid=uid;this.real_name=real_name;this.short_name=getShortName(real_name);this.logo20=logo20;this.newcount=0;this.hasbox=0;this.status=getInnerOnline(online);this.online=online;this.addNewCount=_addNewCount;this.rmNewCount=_rmNewCount;this.setOnline=_setOnline;this.setRealname=_setRealname;this.setUserVals=_setUserVals;this.setHasBox=_setHasBox;this.setUserProfile=_setUserProfile;function _setUserVals(real_name,logo20,online)
{this.real_name=real_name;this.logo20=logo20;this.online=online;this.status=getInnerOnline(online);this.short_name=getShortName(real_name);}
function _setUserProfile(real_name,logo20)
{this.real_name=real_name;this.short_name=getShortName(real_name);this.logo20=logo20;}
function _setRealname(real_name)
{this.real_name=real_name;this.short_name=getShortName(real_name);}
function _setOnline(online)
{this.online=online;this.status=getInnerOnline(online)}
function _addNewCount(count)
{this.newcount+=count;}
function _rmNewCount()
{this.newcount=0;}
function _setHasBox(hasbox)
{this.hasbox=hasbox;}}
function ChatBuddyStatus()
{}
ChatBuddyStatus.OnlineStatus={USER_OFFLINE:0,USER_ONLINE_WEB:1,USER_ONLINE_WAP:2};function getOnlineImg(online)
{var oimg="http://img1.kaixin001.com.cn/i2/chat/user_online.gif";switch(online)
{case ChatBuddyStatus.OnlineStatus.USER_OFFLINE:oimg="http://img1.kaixin001.com.cn/i2/chat/user.gif";break;case ChatBuddyStatus.OnlineStatus.USER_ONLINE_WEB:oimg="http://img1.kaixin001.com.cn/i2/chat/user_online.gif";break;case ChatBuddyStatus.onlineStatus.USER_ONLINE_WAP:oimg="http://img1.kaixin001.com.cn/i2/chat/Mobile.gif";break;}
return oimg;}
function ChatBuddyList()
{this.list=new Hash();this.add=_addChatBuddy;this.get=_getChatBuddy;this.remove=_removeChatBuddy;this.count=_getBuddyCount;this.uids=_getUids;this.hasNotShowNew=_hasNotShowNew;function _addChatBuddy(user)
{this.list.set(user.uid,user);}
function _getChatBuddy(uid)
{var user=this.list.get(uid);return user;}
function _getUids()
{return this.list.keys();}
function _getBuddyCount()
{var count=0;this.list.each(function()
{count++});return count;}
function _removeChatBuddy(uid)
{this.list.unset(uid);}
function _hasNotShowNew()
{var hasnotshownew=false;this.list.each(function(item){var chatbuddy=item.value;if((chatbuddy.newcount>0)&&(chatbuddy.hasbox==0))
{hasnotshownew=true;throw $break;}});return hasnotshownew;}}
var ChatBuddySearch={found_offline_uids:[],search_string:"",search:function(str){ChatBuddySearch.search_string=str;$j.post("/interface/suggestfriend.php",{pars:"f1_f2_rs",text:str,from:"im"},function(data){setTimeout(function(){ChatBuddySearch.removeOfflines();ChatBuddySearch.render(str,data);},300);},"json");},render:function(str,arr){if(ChatBuddySearch.search_string!=str)return;$j("#kxchat_userstab_popup .kxchat_tabcontent .kxchat_userscontent").children().hide();if(arr.length==0){ChatBuddySearch.renderNotFound(str);}else{var match_num=0;$j("#kxchat_userstab_popup .kxchat_userlist").map(function(){var uid=this.id.substr(16);var flag=0;for(var j=0;j<arr.length;j++){if(arr[j].uid==uid){flag=1;break;}}
if(flag==1){$j(this).show().parent().show();match_num++;}else{$j(this).hide();}});for(var i=0;i<arr.length;i++){if(!$j("#kxchat_userlist_"+arr[i].uid).length){var user=_.clone(arr[i]);if(!user.online)
{ChatBuddySearch.found_offline_uids.push(user.uid);}
user.logo20=user.icon20;var chatbuddy=new ChatBuddy(user.uid,user.real_name,user.logo20,user.online);buddylist.add(chatbuddy);BuddyBox.addBuddy(chatbuddy.uid);chatbuddy.setOnline(user.online);match_num++;}
else
{setChatBuddyOnline(arr[i].uid,arr[i].online);}}
if(match_num<=0)
{ChatBuddySearch.renderNotFound(str)}
else
{if(ChatBuddySearch.found_offline_uids.length>0)
{ChatBuddySearch.renderFound();}}}},renderNotFound:function(str){$j("#kxchat_userstab_popup .kxchat_userlist").hide();var html='没有找到'+str+'，或对方不在线';if($j("#kxchat_userslist_notfound").length>0){$j("#kxchat_userslist_notfound").html(html);}else{$j("#kxchat_userstab_popup .kxchat_userslist_offline").after('<div id="kxchat_userslist_notfound">'+html+'</div>');}},renderFound:function(){$j("#kxchat_userslist_notfound").remove();},removeOfflines:function(){_.each(ChatBuddySearch.found_offline_uids,function(uid){BuddyBox.removeBuddy(uid);});ChatBuddySearch.found_offline_uids=[];},resumeBuddyList:function(){ChatBuddySearch.search_string="";ChatBuddySearch.renderFound();ChatBuddySearch.removeOfflines();$j("#kxchat_userstab_popup .kxchat_userlist").map(function(){$j(this).show();});$j("#kxchat_userstab_popup .kxchat_tabcontent .kxchat_userscontent").children().show();}};function str_replace(search,replace,subject,count){var i=0,j=0,temp='',repl='',sl=0,fl=0,f=[].concat(search),r=[].concat(replace),s=subject,ra=r instanceof Array,sa=s instanceof Array;s=[].concat(s);if(count){this.window[count]=0;}
for(i=0,sl=s.length;i<sl;i++){if(s[i]===''){continue;}
for(j=0,fl=f.length;j<fl;j++){temp=s[i]+'';repl=ra?(r[j]!==undefined?r[j]:''):r[0];s[i]=(temp).split(f[j]).join(repl);if(count&&s[i]!==temp){this.window[count]+=(temp.length-s[i].length)/f[j].length;}}}
return sa?s:s[0];}
function getDateFormat(date)
{var day=date.getDate();day=String(day).length==1?'0'+String(day):day;var month=date.getMonth()+1;month=String(month).length==1?'0'+String(month):month;var hour=date.getHours();hour=String(hour).length==1?'0'+String(hour):hour;var minute=date.getMinutes();minute=String(minute).length==1?'0'+String(minute):minute;var second=date.getSeconds();second=String(second).length==1?'0'+String(second):second;return month+"-"+day+" "+hour+":"+minute+":"+second;};function getShortName(name)
{if(name.length>5)
{return name.substr(0,5)+"...";}
return name;}
function isUrlChar(chr)
{var seps=new Array(".","_","-",",",'@','/','?','=','#',';','%','!','~');if((chr>='a'&&chr<='z')||chr>='A'&&chr<='Z'||chr>='0'&&chr<='9'||(seps.indexOf(chr)!=-1))
{return true;}
return false;}
function parseLinks(content)
{var len=content.length;var start=undefined;var urls=new Array();var htmls=new Array();var url="";var i=0;var end=true;for(i=0;i<len;i++)
{if(i<len-7&&typeof(start)=='undefined')
{if(content.substr(i,7).toLowerCase()=="http://")
{start=i;i=i+7;}}
else if(typeof(start)!='undefined'&&(!isUrlChar(content.charAt(i))))
{end=true;if(content.charAt(i)=='&'&&(content.substr(i,4)=="&gt;"||(content.substr(i,4)=="&lt;")||(content.substr(i,6)=="&quot;")))
{end=true;}
else if(content.charAt(i)=='&')
{end=false;}
if(end)
{url=content.substr(start,i-start);urls.push(url);htmls.push('<a href="'+url+'" target="_blank">'+url+'</a>');start=undefined;}}}
if(typeof(start)!='undefined')
{url=content.substr(start,i-start);urls.push(url);htmls.push('<a href="'+url+'" target="_blank">'+url+'</a>');}
if((urls.length>0)&&(htmls.length==urls.length))
{return str_replace(urls,htmls,content);}
return content;}
var kxchat_faceTitle=["大笑","微笑","亲亲","抱抱","色色","好失望哟","好困哦","害羞","酷呆了","晕倒","眨眼","鬼脸","小声点","吃惊","翻白眼","干杯","困惑","啥？","睡觉","再见了","眼泪哗哗地","你好讨厌","我吐","怒骂","闭嘴","打你","真的生气了","超级棒","不咋地","魅力四射","心都碎了","爱","吻","玫瑰凋谢了","玫瑰盛开了","生日蛋糕","礼物","苹果","西瓜","咖啡","足球","握手","星星","精灵","小丑","大怒","生病了","小可爱","小心非典","嘴馋了","警察","抓狂了","不爽","汗","思考中","见钱眼开","呲牙","晕头转向","好好爱你哦","猪头","便便","月亮","音乐","饭","真衰","偷笑","下雨","猫猫","狗狗","骷髅","书呆子","太阳","邮件","帅帅男孩","妩媚女孩","药丸","鄙视","烧香","呲牙咧嘴","拜拜","奋斗","嗯","胜利","作揖","OK","地雷","菜刀","鼓掌","哼哼","可怜","委屈","糗大了","阴险","傲慢","快哭了","泪流满面","示爱","坏笑"];var kxchat_faceBase="http://img1.kaixin001.com.cn/i/face/";var KxFace=(function(){var showing="";return function(uid){this.uid=uid;this.id="chatbox_"+uid+"_face";this.autoClose=function(){setTimeout(function(){new KxFace(uid).hide();},1000);};this.hide=function(){$j("#chatbox_"+uid+"_face").hide();showing="";};this.removePanel=function(){$j("#chatbox_"+uid+"_face").remove();};this.drawPanel=function(html){var tdiv=document.createElement("div");tdiv.id="chatbox_"+uid+"_face";tdiv.innerHTML=html;tdiv.style.display="block";if(ie6)
{tdiv.style.position="absolute";}
else
{tdiv.style.position="fixed";}
popup=$j("#kxchat_user_"+uid+"_popup");tdiv.style.zIndex=popup.css("z-index")+1;var btn=$("chatbox_"+uid+"_face_icon");var btn_pos=getpos(btn);if(ie6)
{tdiv.style.top=(parseInt(popup.css("top"))+65)+"px";tdiv.style.left=(parseInt(popup.css("left"))+7)+"px";}
else
{tdiv.style.bottom="30px";tdiv.style.left=(btn_pos.left-1)+"px";}
document.body.appendChild(tdiv);tdiv.focus();$j("#chatbox_"+uid+"_face").mouseleave(function(){new KxFace(uid).autoClose();});};this.facePanel=function(){if(showing!=""&&showing!=uid){new KxFace(showing).hide();}
showing=uid;var face=$j("#chatbox_"+uid+"_face");if(face.length>0){face.css("z-index",$j("#kxchat_user_"+uid+"_popup").css("z-index"));face.toggle();return;}
var pContent='';pContent+='<div>';pContent+='<div class="chat_face">';pContent+='<table class="f_list BQcon0" style="display:block;">';for(i=0;i<7;i++)
{pContent+='<tr>';for(j=1;j<=9;j++)
{var tt=(i*9+j).toString();var t=kxchat_faceBase+tt+'.gif';pContent+='<td onmouseover="this.className=\'chat_emo\';" onmouseout="this.className=\'\';" onclick="javascript:new KxFace('+uid+').insFace(\''+tt+'\');"><img src="'+t+'" title="'+kxchat_faceTitle[i*9+j-1]+'"></td>';}
pContent+='</tr>';}
pContent+='</table>';pContent+='<table  class="f_list BQcon1" style="display:none;">';for(i=0;i<7;i++)
{pContent+='<tr>';for(j=1;j<=9;j++)
{if(i*9+j+63>kxchat_faceTitle.length)
{pContent+='<td>&nbsp;</td>';}
else
{var tt=(i*9+j+63).toString();var t=kxchat_faceBase+tt+'.gif';var sizestr="height=\"19\" width=\"19\"";if((i*9+j+63)>78)
{sizestr="height=\"23\" width=\"23\"";}
pContent+='<td onclick="javascript:new KxFace('+uid+').insFace(\''+tt+'\');" onmouseout="this.className=\'\';" onmouseover="this.className=\'chat_emo\';"><img  '+sizestr+' title="'+kxchat_faceTitle[i*9+j+63-1]+'" src="'+t+'" /></td>';}}
pContent+='</tr>';}
pContent+='</table>';pContent+='<div class="l w120" id="'+this.id+'_fp_btn">';pContent+='1&nbsp;<a class="sl" href="javascript:new KxFace('+uid+').facePanelSwitch(1);">2</a>';pContent+='</div>';pContent+='<div class="r mt2"><img src="http://img1.kaixin001.com.cn/i/close.gif" alt="关闭" width="13" height="12" class="cp" onclick="javascript:new KxFace('+uid+').facePanel();" /></div>';pContent+='<div class="c"></div>';pContent+='</div>';pContent+='</div>';this.drawPanel(pContent);};this.facePanelSwitch=function(index)
{if(index==1)
{$j("#chatbox_"+uid+"_face .chat_face .BQcon0").hide();$j("#chatbox_"+uid+"_face .chat_face .BQcon1").show();$(this.id+'_fp_btn').innerHTML='<a href="javascript:new KxFace('+uid+').facePanelSwitch(0);" class="sl">1</a>&nbsp;2';}
else
{$j("#chatbox_"+uid+"_face .chat_face .BQcon1").hide();$j("#chatbox_"+uid+"_face .chat_face .BQcon0").show();$(this.id+'_fp_btn').innerHTML='1&nbsp;<a class="sl" href="javascript:new KxFace('+uid+').facePanelSwitch(1);">2</a>';}};this.insFace=function(idx)
{$("chatbox_"+uid+"_text").value=$("chatbox_"+uid+"_text").value+'//'+kxchat_faceTitle[idx-1]+' ';$("chatbox_"+uid+"_text").focus();this.removePanel();};}})();function kxface_parseFaces(content)
{var tips=new Array();var len=content.length;var start=-1;for(var i=0;i<len;i++)
{if(i<len-1)
{if(content.charAt(i)=='/'&&content.charAt(i+1)=='/')
{start=i;i++;}}
if(content.charAt(i)==' '&&start>=0)
{var word=content.substr(start,i-start);var realword=word.substr(2);if(kxchat_faceTitle.indexOf(realword)!=-1)
{tips.push(word);start=-1;}}}
if(start>=0)
{var word=content.substr(start);var realword=word.substr(2);if(kxchat_faceTitle.indexOf(realword)!=-1)
{tips.push(word);}}
icons=kxface_getFaceIcons(tips);tips.push("\n");icons.push("<br />");content=parseLinks(content);return str_replace(tips,icons,content);};function kxface_getFaceIcons(tips)
{var len=tips.length;var tip='';var idx=-1;var icons=new Array();for(var i=0;i<len;i++)
{tip=tips[i].substr(2);idx=kxchat_faceTitle.indexOf(tip);if(idx!=-1)
{idx=parseInt(idx,10)+1;icons.push('<img title='+tip+' src="'+kxchat_faceBase+idx+'.gif" />');}}
return icons;};function templog(msg){return;console.log(msg);}
function openChatBox(uid,buddyName,buddyStatus,min,notice){if(buddyName==null||uid==null||uid==""||buddyName==""){return;}
if(!ChatBoxList.exists(uid)){if(ChatBoxList.count()>=ChatBoxList.MAX_NUM)
{if(!notice)
{controlActiveBoxes();chatbuddy=buddylist.get(uid);if(chatbuddy)
{chatbuddy.setHasBox(1);buddylist.add(chatbuddy);}
var chatbox=new ChatBox(uid);chatbox.build(buddyName,buddyStatus);}
else
{showUsersTabNotice();}}
else
{chatbuddy=buddylist.get(uid);if(chatbuddy)
{chatbuddy.setHasBox(1);buddylist.add(chatbuddy);}
controlActiveBoxes();var chatbox=new ChatBox(uid);chatbox.build(buddyName,buddyStatus);}}
else
{var chatbox=ChatBoxList.get(uid);}
if((typeof(min)=="undefined")||(parseInt(min,10)==0))
{chatbox.show(true);}
return chatbox;}
var ChatBoxList={list:[],active:"",MAX_NUM:3,map:{},get:function(uid){if(ChatBoxList.map[uid])
{return ChatBoxList.map[uid];}
else
{return false;}},add:function(uid,chatbox){if($j.inArray(uid,ChatBoxList.list)==-1){ChatBoxList.list.push(uid);ChatBoxList.active=uid;ChatBoxList.map[uid]=chatbox;}},remove:function(uid){var index=$j.inArray(uid,ChatBoxList.list);if(index!=-1){ChatBoxList.list[index]=null;delete ChatBoxList.map[uid];_.compact(ChatBoxList.list);}},exists:function(uid){if(ChatBoxList.map[uid]){templog("ChatBoxList exists: "+uid);return true;}
templog("ChatBoxList not exists: "+uid);return false;},count:function(){var count=0;for(var i=0;i<ChatBoxList.list.length;i++){if(ChatBoxList.list[i]){count++;}}
return count;},adjust:function(){$j.map(ChatBoxList.list,function(uid){templog("ChatBoxList addjust "+uid);if(!uid)return;var userbox=$j("#kxchat_user_"+uid);if(!userbox.length)return;var winWidth=ChatGlobal.winWidth;var mainWidth=ChatGlobal.mainWidth;if(winWidth<320){winWidth=320}
var left=0;if(winWidth>=mainWidth)
{left=(parseInt(userbox.position().left)+parseInt($j("#kxchat_base").css("right"),10))+1;if((winWidth-mainWidth)%2==0)
{if(!ie6)
{left+=1;}
else
{left-=1;}}
else if(ie6)
{left+=1;}}
else
{left=(parseInt(userbox.position().left)-(mainWidth-winWidth));}
var newleft=left+"px";templog("adjust:"+newleft+" "+winWidth+" "+mainWidth);var popup=$j("#kxchat_user_"+uid+"_popup");popup.css("left",newleft).css("bottom","24px");if(ie6){popup.css("position","absolute");var top=parseInt($j(window).height())-parseInt(popup.css("bottom"))-parseInt(popup.height())+$j(window).scrollTop()+1;popup.css("top",top+"px")}
relocateFacePanel(uid);});}};function justRemoveNotify(uid,chatid)
{if(chatid==ChatGlobal.chatid())return;var chatbuddy=buddylist.get(uid);if(chatbuddy.newcount)
{chatbuddy.rmNewCount();buddylist.add(chatbuddy);BuddyBox.rmNewMsgNotify(uid);$j("#kxchat_user_"+uid+" .kxchat_tabalert").remove();$j("#kxchat_user_"+uid+"_popup .kxchat_tabtitle").removeClass("kxchat_tabtitle_newmsg");$j("#kxchat_user_"+uid).removeClass("kxchat_tab_newmsg");clearUserBlink(uid);return true;}
return false;}
function justMinChatbox(uid,chatid)
{if(chatid==ChatGlobal.chatid())return;var chatbox=ChatBoxList.get(uid);if(chatbox)
{chatbox.hide(true);}}
function justMaxChatbox(uid,chatid)
{if(chatid==ChatGlobal.chatid())return;var chatbox=ChatBoxList.get(uid);if(chatbox)
{chatbox.show(true);}
else
{var chatbox=_openChatBoxByUid(uid,0);if(chatbox)
{chatbox.show();}}}
function removeNotify(uid)
{var ret=justRemoveNotify(uid);if(ret)
{var chatbox=ChatBoxList.get(uid);if(chatbox){chatbox.syncClear();}}}
function clearAllBlink()
{var len=blinkMessages.length;for(var i=len-1;i>=0;i--)
{blinkMessages.splice(i,1);}
stopBlinkNewChatMsg();}
function clearUserBlink(uid)
{var parts="";var len=blinkMessages.length;for(var i=len-1;i>=0;i--)
{parts=blinkMessages[i].split(",");if(parseInt(parts[0],10)==uid)
{blinkMessages.splice(i,1);}}
if(blinkMessages.length==0)
{stopBlinkNewChatMsg();}}
function justCloseChatbox(uid,chatid)
{if(chatid==ChatGlobal.chatid())return;if(ChatBoxList.exists(uid))
{clearUserBlink(uid);var chatbox=ChatBoxList.get(uid);if(chatbox)chatbox.close();}}
function chatCloseNotify(uid)
{var chatbox=ChatBoxList.get(uid);if(chatbox)
{chatbox.syncClose();}
justCloseChatbox(uid,"");}
var BuddyBox={show:function(){if(offline==1){clearTimeout(pooltimer);pooltimer=setTimeout(function(){poolchatmsg()},minpooltime);}
$j("#kxchat_userstab").removeClass("chat_menu chat_menu_hover");var marginbt=-1;var right=(parseInt($j("#kxchat_base").css("right"),10)+marginbt)+"px";$j("#kxchat_userstab_popup").css("right",right).css("bottom","24px");$j("#kxchat_userstab").addClass("chat_menu_click");BuddyBox.active();$j("#kxchat_userstab_popup").addClass("kxchat_tabopen");if(ie6)
{BuddyBox.adjust();}},checkTabNotice:function(){if(buddylist.hasNotShowNew()&&stnotice)
{showUsersTabNotice();}
else if(buddylist.hasNotShowNew())
{showUsersTabNotice();}},existsBuddy:function(uid){return $j("#kxchat_userlist_"+uid).length>0},removeBuddy:function(uid){$j("#kxchat_userlist_"+uid).remove();},addBuddy:function(uid){if(BuddyBox.existsBuddy(uid))return;var buddy=buddylist.get(uid);var innerstatus=buddy.status;var dispnewmsg=(buddy.newcount>0)?"block":"none";var buddylistshtml='<div id="kxchat_userlist_'+buddy.uid+'" class="kxchat_userlist" onmouseover="$j(this).addClass(\'kxchat_userlist_hover\');" onmouseout="$j(this).removeClass(\'kxchat_userlist_hover\');"><span class="l"><img src="'+buddy.logo20+'" /></span><span class="kxchat_userscontentname l">'+buddy.short_name+'</span><span class="kxchat_list_newmsg l" title="有新消息" style="display:'+dispnewmsg+';">'+buddy.newcount+'</span><span class="kxchat_userscontentdot kxchat_'+getenstatusstr(innerstatus)+' l"></span></div>';var userlist=$j("#kxchat_userstab_popup .kxchat_tabcontent .kxchat_userscontent .kxchat_userslist_"+getenstatusstr(innerstatus));if(buddy.online)
{if(onlineNum==0)
{userlist.html("");}
onlineNum++;}
userlist.append(buddylistshtml).show();userlist.children().click(function(e){e.stopPropagation();openChatBoxFromBuddy(this)});showOnlineNum(onlineNum);},hide:function(){var userstab=$j("#kxchat_userstab");userstab.removeClass("chat_menu_click");userstab.addClass("chat_menu");var userstab_popup=$j("#kxchat_userstab_popup");$j("#kxchat_userstab_popup").removeClass("kxchat_tabopen");},active:function(){$j("#kxchat_userstab_popup").css("z-index",getMaxZIndex()+1);},adjust:function(){var tabpopup=$j("#kxchat_userstab_popup");if(tabpopup.hasClass('kxchat_tabopen')){$j("#kxchat_userstab_popup, .kxchat_popup_base .kxchat_tabpopup").css("top",parseInt($j(window).height())-parseInt(tabpopup.css("bottom"))-parseInt(tabpopup.height())+$j(window).scrollTop()+1+"px");var marginbt=-1;tabpopup.css("right",parseInt($j("#kxchat_base").css("right"),10)+marginbt);}},rmNewMsgNotify:function(uid)
{if($j("#kxchat_userlist_"+uid).length>0)
{var listnewmsg=$j("#kxchat_userlist_"+uid+" .kxchat_list_newmsg");listnewmsg.css("display","none");listnewmsg.html("");}
if(!buddylist.hasNotShowNew())
{hideUsersTabNotice();}},notifyNewMsgFrom:function(uid){templog("notifyNewMsgFrom: "+uid);var chatbuddy=buddylist.get(uid);if(chatbuddy)
{templog("before: addNewCount "+chatbuddy.newcount);if(!ChatBoxList.get(uid))
{chatbuddy.addNewCount(1);}
buddylist.add(chatbuddy);}
if($j("#kxchat_userlist_"+uid).length>0){var count=0;var listnewmsg=$j("#kxchat_userlist_"+uid+" .kxchat_list_newmsg");var countstr=listnewmsg.html();if(countstr.length>0)
{count=parseInt(countstr,10)+1;}
else
{count++;}
templog("notifyNewMsgFrom count: "+count+" chatbuddy.newcount: "+chatbuddy.newcount);count=chatbuddy?chatbuddy.newcount:count
listnewmsg.html(count);listnewmsg.css("display","block");}else{templog("notifyNewMsgFrom: "+uid+" error");}
BuddyBox.checkTabNotice();}};var ChatBoxSync=function(uid){this.queue=[];this.uid=uid;this.onsync=false;};ChatBoxSync.prototype={maps:{max:"/chat/max.php",min:"/chat/min.php",clear:"/chat/clear.php",close:"/chat/close.php"},sync:function(type,params){if(!params)params={};if(this.maps[type]){this.queue.push([type,params]);if(this.onsync==false)
{this.run();}}},doSync:function(type,params){params=$j.extend({otheruid:this.uid,chatid:ChatGlobal.chatid()},params);this.onsync=true;$j.ajax({url:this.maps[type],data:params,cache:false,context:this,complete:function(){if(this.queue.length>0){this.run();}
else
{this.onsync=false;}}});},run:function(){if(this.queue.length>0){var data=this.queue.shift();this.doSync(data[0],data[1]);}}};var ChatBox=function(uid){this.uid=uid;this.popup_container=null;this.popup=null;this.tab=null;this.closebar=null;this.record=null;this.closebox_bottom=null;this.maxbox_bottom=null;this.popup_title=null;this.tab_alert=null;this.textarea=null;this.cmids=[];this.buddy=null;this._sync=new ChatBoxSync(this.uid);ChatBoxList.add(uid,this);};ChatBox.prototype={exists:function(){if(this.tab)return true;else return false;},addCmid:function(cmid){this.cmids.push(cmid);},clearCmids:function(){this.cmids=[];},build:function(buddyName,buddyStatus){var that=this;this.buddy=buddylist.get(this.uid);initBar();if(buddyName.length>14){shortname=buddyName.substr(0,14)+"..."}else{shortname=buddyName}
if(buddyName.length>24){longname=buddyName.substr(0,24)+"..."}else{longname=buddyName}
this.tab=$j("<div/>").attr("id","kxchat_user_"+this.uid).addClass("kxchat_tab").css("width",210).appendTo($j("#kxchat_chatboxes_wide"));$j("<div/>").attr("id","kxchat_"+this.uid+"_closebar").appendTo(this.tab);$j("<div/>").attr("id","chatbox_"+this.uid+"_record").addClass("chat_record").css("width",0).css("height",0).appendTo(this.tab);this.closebar=$j("#kxchat_"+this.uid+"_closebar");this.record=$j("#chatbox_"+this.uid+"_record");if(ie6)
{this.closebar.css("display","block").css("z-index","1");this.record.css("display","none").css("z-index","-1");}
else
{this.closebar.css("z-index","1");this.record.css("z-index","-1");}
this.closebar.html('<div class="kxchat_closebox_bottom_status kxchat_'+getenstatusstr(buddyStatus)+'"></div><div style="float:left">'+shortname+'</div><div class="kxchat_closebox_bottom" title="关闭"></div><div title="显示聊天窗口" class="kxchat_maxbox_bottom"></div>');this.closebox_bottom=$j("#kxchat_user_"+this.uid+" .kxchat_closebox_bottom");this.maxbox_bottom=$j("#kxchat_user_"+this.uid+" .kxchat_maxbox_bottom");var title_newline=$j.browser.msie?"&#13;":" ";this.record.html('<div style="width:151px;" class="l pl8"><span id="divbtnface_'+this.uid+'"><a href="javascript:openFaceBox('+this.uid+');"><img id="chatbox_'+this.uid+'_face_icon" src="http://img1.kaixin001.com.cn/i2/chat/icon_face.gif" title="表情"/></a></span><span id="chatbox_'+this.uid+'_uploader"></span><span class="pl8"><a href="javascript:openHistory('+this.uid+');"><img src="http://img1.kaixin001.com.cn/i2/chat/chatlog.gif" title="聊天记录"/></a></span></div><div class="l"> <input type="button" class="chatsend" title="发送快捷键：Enter或Ctrl+Enter;'+title_newline+'换行：Shift+Enter" value="" onclick="javascript:sendchatmsg('+this.uid+');" /></div><div class="c"></div>');this.closebox_bottom.mouseenter(function(){$j(this).addClass("kxchat_closebox_bottomhover")}).mouseleave(function(){$j(this).removeClass("kxchat_closebox_bottomhover")}).click(function(){chatCloseNotify(that.uid);});this.maxbox_bottom.mouseenter(function(){$j(this).toggleClass("kxchat_maxbox_bottomhover");}).mouseleave(function(){$j(this).toggleClass("kxchat_maxbox_bottomhover");});var chatbuddy=buddylist.get(this.uid);this.popup_container=$j("<div/>").addClass("kxchat_popup_base").css("width","1004px").css("right",$j("#kxchat_base").css("right")).css("bottom","0px").appendTo($j("body"));ChatGlobal.addEl(".kxchat_popup_base",this.popup_container[0]);$j("<div/>").attr("id","kxchat_user_"+this.uid+"_popup").addClass("kxchat_tabpopup").css("display","none").html('<div class="kxchat_tabtitle"><div class="kxchat_logo"><a href="/home/?uid='+this.uid+'"><img src="'+chatbuddy.logo20+'" /></a></div><div class="kxchat_name"><a class="sl2" href="/home/?uid='+this.uid+'">'+longname+'</a></div></div><div class="kxchat_tabcontent"><div class="kxchat_tabcontenttext"></div><div class="kxchat_tabcontentinput"><div class="kxchat_tabcontenttip"></div><textarea class="kxchat_textarea" id="chatbox_'+this.uid+'_text" cols="30" rows="5"></textarea></div></div><div class="kxchat_tabcbot"></div>').appendTo(this.popup_container);this.textarea=$j("#chatbox_"+this.uid+"_text");var uploader=new ChatUploader("chatbox_"+this.uid+"_uploader",this.uid);uploader.init();this.tab.data("uploader",uploader);this.popup=$j("#kxchat_user_"+this.uid+"_popup");this.popup.click(function(){that.active();});this.textarea.keydown(function(event){return checkChatBoxInputKey(event,that.uid)});this.popup_title=this.popup.children(".kxchat_tabtitle").append('<div class="kxchat_closebox" title="关闭"></div><div title="最小化" class="kxchat_minbox"></div><br clear="all"/>');this.popup_title.children(".kxchat_closebox").mouseenter(function(){$j(this).addClass("kxchat_chatboxmouseoverclose");that.popup_title.removeClass("kxchat_chatboxtabtitlemouseover")}).mouseleave(function(){$j(this).removeClass("kxchat_chatboxmouseoverclose");that.popup_title.addClass("kxchat_chatboxtabtitlemouseover")}).click(function(){chatCloseNotify(that.uid);});this.popup_title.mouseenter(function(){$j(this).addClass("kxchat_chatboxtabtitlemouseover")}).mouseleave(function(){$j(this).removeClass("kxchat_chatboxtabtitlemouseover")});this.popup_title.children(".kxchat_minbox").mouseover(function(){$j(this).addClass("kxchat_minboxhover");}).mouseout(function(){$j(this).removeClass("kxchat_minboxhover");}).bind("click",function(event){event.preventDefault();that.hide();that.removeNotification();setOpenBoxes();return false;});this.tab.mouseenter(function(){if(that.record.css("z-index")=='-1')
{$j(this).addClass("kxchat_tabmouseover").children("div").addClass("kxchat_tabmouseovertext")}}).mouseleave(function(){if(that.record.css("z-index")=='-1')
{$j(this).removeClass("kxchat_tabmouseover").children("div").removeClass("kxchat_tabmouseovertext")}});this.tab.click(function(event){if(event)
{var obj=event.target;if(obj&&obj.tagName.toLowerCase()!="div"){return;}}
if(that.record.css("z-index")!='-1'){that.active();}else{that.show();}});if(this.popup.children(".kxchat_tabcontent").children(".kxchat_tabcontenttext").html()==""){receiveChat(this.uid)}},adjustPosition:function(){var left=0;var winWidth=ChatGlobal.winWidth;var mainWidth=ChatGlobal.mainWidth;if(winWidth>=mainWidth)
{left=(parseInt(this.tab.position().left)+parseInt($j("#kxchat_base").css("right"),10)+1);}
else
{left=(parseInt(this.tab.position().left)-(mainWidth-winWidth));}
var newleft=left+"px";this.popup.css("left",newleft).css("bottom","24px");},show:function(passive){var that=this;this.tab_alert=this.tab.children(".kxchat_tabalert");if(this.tab_alert.length>0){this.tab_alert.remove();}
this.tab_alert=null;this.adjustPosition();this.closebox_bottom.addClass("kxchat_closebox_bottom_click");guid=this.uid;if(ie6){this.popup.css("position","absolute");var winWidth=ChatGlobal.winWidth;var mainWidth=ChatGlobal.mainWidth;if(winWidth>=mainWidth)
{left=(parseInt(this.tab.position().left)+parseInt($j("#kxchat_base").css("right"),10));}
else
{left=(parseInt(this.tab.position().left)-(mainWidth-winWidth));}
var newleft=left+"px";this.popup.css("left",newleft).css("bottom","24px");this.popup.css("top",parseInt($j(window).height())-parseInt(this.popup.css("bottom"))-parseInt(this.popup.height())+$j(window).scrollTop()+4+"px")}
switchChatTab(this.uid,true);if(0&&!ie6)
{this.popup.css("height","auto");var height=this.popup.height();this.popup.css("height",0).addClass("kxchat_tabopen").css("display","block");this.popup.animate({height:height},function(){switchChatTab(that.uid,true);});}
else
{this.popup.addClass("kxchat_tabopen");}
if(this.buddy!=null)
{if(this.buddy.online==ChatBuddyStatus.OnlineStatus.USER_ONLINE_WAP)
{showContentTip(this.uid,tips_map.MONLINE);}
else if(this.buddy.online==ChatBuddyStatus.OnlineStatus.USER_OFFLINE)
{showContentTip(this.uid,tips_map.FOFFLINE);}}
setTimeout("historyScroll("+this.uid+")",500);this.textarea.focus(function(){setTimeout("historyScroll("+this.uid+")",500);that.removeNotification();}).focus();ChatBoxList.adjust()
this.active();setActiveBoxes();if(!passive)
{this.syncMax();}},serializeCmids:function(){var cmids="";if(this.cmids.length>0)
{cmids=this.cmids.join(",");}
return cmids;},syncMax:function(){this._sync.sync("max",{cmids:this.serializeCmids()});this.clearCmids();},syncClose:function(){this._sync.sync("close",{});},syncClear:function(){this._sync.sync("clear",{cmids:this.serializeCmids()});this.clearCmids();},syncMin:function(){this._sync.sync("min",{});},hide:function(passive){if(0&&!ie6)
{var that=this;var height=this.popup.css("height");this.popup.animate({height:0},function(){$j(this).removeClass("kxchat_tabopen").css("display","none").css("height",height);switchChatTab(that.uid,false);});}
else
{this.popup.removeClass("kxchat_tabopen");switchChatTab(this.uid,false);}
this.tab.removeClass("kxchat_tabmouseover");this.closebox_bottom.removeClass("kxchat_closebox_bottom_click");var chatbuddy=buddylist.get(this.uid);if(chatbuddy)
{var innerstatus=getInnerStatus(chatbuddy);changeUserStatus(this.uid,innerstatus);}
if(!passive)
{this.syncMin();}},close:function(){this.popup.parent().remove();this.tab.data("uploader").remove();this.tab.remove();if(guid==this.uid){guid="";}
ChatBoxList.remove(this.uid);chatbuddy=buddylist.get(this.uid);chatbuddy.setHasBox(0);buddylist.add(chatbuddy);initBar();setActiveBoxes();},active:function(){this.popup.css("z-index",getMaxZIndex()+1);this.removeNotification();ChatBoxList.active=this.uid;guid=this.uid;},gotNewMsg:function(){templog("gotNewMsg "+this.uid);var now=new Date();var lastinput=inputtimes.get(this.uid);var newtip=false;if(lastinput&&(now.getTime()-lastinput)>10000)
{newtip=true;}
else if(!lastinput)
{newtip=true;}
newtip=true;if(newtip)
{var chatbuddy=buddylist.get(this.uid);chatbuddy.addNewCount(1);this.popup_title.addClass("kxchat_tabtitle_newmsg");this.tab.addClass("kxchat_tab_newmsg");if(!this.popup.hasClass("kxchat_tabopen"))
{this.tab_alert=this.tab.children(".kxchat_tabalert");if(this.tab_alert&&this.tab_alert.length>0){if(chatbuddy)
{this.tab_alert.html(chatbuddy.newcount);}}else{this.tab_alert=$j("<div/>").css("top","0px").addClass("kxchat_tabalert").html("1").appendTo($j("#kxchat_user_"+this.uid));ChatGlobal.addEl(".kxchat_tabalert",this.tab_alert[0]);}}
BuddyBox.notifyNewMsgFrom(this.uid);}},removeNotification:function(){removeNotify(this.uid);},notifyNewMsgFrom:function(){this.popup_title.addClass("kxchat_tabtitle_newmsg");this.closebar.addClass("kxchat_tabtitle_newmsg");},showNewMsgNum:function(){templog("showAlert");showAlert(this.uid,1,1);}};var ChatUploaderConfig={verify:"",set:function(items){$j.each(items,function(key,value){if(typeof(ChatUploaderConfig[key])!="undefined"){ChatUploaderConfig[key]=value;}});}};var ChatDownloader=function(uid,fileid,expire,deleted){if(typeof(chatdownload_iframe)=="undefined")
{chatdownload_iframe=document.createElement('iframe');chatdownload_iframe.setAttribute("id","chatdownload_iframe");chatdownload_iframe.setAttribute("name","chatdownload_iframe");chatdownload_iframe.style.visibility="hidden";chatdownload_iframe.style.display="none";document.body.appendChild(chatdownload_iframe);var downform=document.createElement('form');downform.setAttribute("id","chatdownload_form");downform.setAttribute("name","chatdownload_form");downform.setAttribute("action","/file/file.php");downform.setAttribute("method","post");downform.target="chatdownload_iframe";document.body.appendChild(downform);downform.innerHTML='<input type="hidden" name="verify" value="'+ChatUploaderConfig.verify+'" /><input type="hidden" name="uid" value="" id="chatdownload_uid" /><input type="hidden" name="fileid" value="" id="chatdownload_fileid" />';}
$("chatdownload_uid").value=uid;$("chatdownload_fileid").value=fileid;$("chatdownload_form").submit();};var ChatUploader=(function(){function getVerify(){return ChatUploaderConfig.verify;};return function(container,uid){this.container=container;this.uid=uid;this.swfup=null;this.init=function(){var that=this;setTimeout(function(){that.initUploader.call(that);},50);};this.remove=function(){if(this.swfup&&typeof(this.swfup.destroy)!="undefined"){this.swfup.destroy();}};this.initUploader=function(){try
{this.swfup=new SWFUpload({upload_url:"/file/upload_submit.php",file_size_limit:"40 MB",file_queue_error_handler:this.event_fileQueueError,file_queued_handler:this.event_fileQueued,file_dialog_complete_handler:this.event_fileDialogComplete,upload_start_handler:this.event_uploadStart,upload_error_handler:this.event_uploadError,upload_success_handler:this.event_uploadSuccess,upload_progress_handler:this.event_uploadProgress,upload_complete_handler:this.event_uploadComplete,swfupload_loaded_handler:this.event_swfuploadLoaded,button_placeholder_id:this.container,button_image_url:"http://img1.kaixin001.com.cn/i2/chat/upload_f2.gif",button_text:'',button_text_style:'border: none;',button_action:SWFUpload.BUTTON_ACTION.SELECT_FILES,button_width:18,button_height:16,button_window_mode:SWFUpload.WINDOW_MODE.OPAQUE,button_cursor:SWFUpload.CURSOR.HAND,flash_url:"/swf/common/swfupload_f10.swf",custom_settings:{uploader:this},debug:false});}catch(ex){templog("swfupload init exception");};};this.startUpload=function(){if(typeof(this.swfup)!="undefined"){try{this.swfup.addPostParam("verify",getVerify());this.swfup.addPostParam("attachment_type","chat");if(this.swfup.getStats().files_queued>0){this.swfup.startUpload();}}catch(ex){this.swfup.debug(ex);}}};this.uploadFail=function(file,idx,code){var ret="";switch(code){case 2:ret="超过网盘容量";break;case 5:ret="当日上传文件数超限（200个）";break;case 6:ret="文件重复";break;default:ret="未知错误";}
$j("#kxchat_message_"+file.id+" .kxchat_chatboxmessagecontent").html("文件："+file.name+" 上传失败，"+ret);};this.uploadSuccess=function(file,fileid){templog("uploadSuccess");$j("#kxchat_message_"+file.id+" .kxchat_chatboxmessagecontent").html("文件："+file.name+" 上传成功");this.submitUpload(fileid,file);templog("after_uploadSuccess");};this.submitUpload=function(fileid,file){templog("submitUpload");templog("submitUpload fileid: "+fileid);var myAjaax=new Ajax.Request("/chat/send.php",{method:"post",parameters:"chatid="+encodeURIComponent(ChatGlobal.chatid())+"&otheruid="+encodeURIComponent(this.uid)+"&fileid="+encodeURIComponent(fileid),onSuccess:function(req){templog(req.responseText);$j("#kxchat_message_"+file.id+" .kxchat_chatboxmessagecontent").html("文件："+file.name+" 发送成功");},onFailure:function(req){templog(req.responseText);$j("#kxchat_message_"+file.id+" .kxchat_chatboxmessagecontent").html("文件："+file.name+" 发送失败");}});};this.event_fileQueueError=function(file,errorCode,message){templog("event_fileQueueError");try
{switch(errorCode)
{case SWFUpload.QUEUE_ERROR.FILE_EXCEEDS_SIZE_LIMIT:alert("单个文件大小不能超过40M！");break;case SWFUpload.QUEUE_ERROR.ZERO_BYTE_FILE:alert("空文件");break;case SWFUpload.QUEUE_ERROR.INVALID_FILETYPE:alert("文件类型不支持");break;default:alert("未知错误: "+errorCode);}}
catch(ex)
{this.debug(ex);}};this.event_fileQueued=function(){templog("event_fileQueued");};this.event_fileDialogComplete=function(numFilesSelected,numFilesQueued){templog("event_fileDialogComplete");if(numFilesQueued){templog("starting upload");this.customSettings.uploader.startUpload();}};this.event_uploadStart=function(file){templog("event_uploadStart, file.id: "+file.id);templog("typeof: "+typeof(this.event_fileDialogComplete));templog("uid: "+this.customSettings.uploader.uid);var html='<div id="kxchat_message_'+file.id+'" class="kxchat_chatboxmessage"><span class="kxchat_chatboxmessageme">我 '+getDateFormat(new Date())+'</span><br/><span class="kxchat_chatboxmessagecontent">正在上传：'+file.name+'</span></div>';var tabcontenttext=$j("#kxchat_user_"+this.customSettings.uploader.uid+"_popup .kxchat_tabcontenttext");tabcontenttext.append(html);templog(typeof(tabcontenttext));tabcontenttext.scrollTop(tabcontenttext[0].scrollHeight);};this.event_uploadError=function(){templog("event_uploadError");};this.event_uploadSuccess=function(file,serverData){templog("event_uploadSuccess");var re=/uploadNext\(\"(\d+):(\d+):(\d+)\"\)/;var arr=serverData.match(re);if(arr==null){re=/uploadNext\(\"(\d+):(\d+)\"\)/;arr=serverData.match(re);if(arr!=null){this.customSettings.uploader.uploadFail(file,arr[1],arr[2]);}else{this.customSettings.uploader.uploadFail(file,-1,-1);}}else{this.customSettings.uploader.uploadSuccess(file,arr[3]);}};this.event_uploadProgress=function(file,bytesLoaded,bytesTotal){templog("event_uploadProgress");var progress=parseInt(bytesLoaded/bytesTotal*100);$j("#kxchat_message_"+file.id+" .kxchat_chatboxmessagecontent").html("正在上传："+file.name+" "+progress+"%");};this.event_uploadComplete=function(file){templog("event_uploadComplete");};this.event_swfuploadLoaded=function(){templog("event_swfuploadLoaded");var instance=this.movieName;$j("#"+instance).attr("title","上传附件").bind("click",function(event){event.preventDefault();return false;});};}})();var ChatAppList=function(){this.load_data=function(callback){var that=this;var set_app_data=function(data){that.app_data=data;that.app_num=data.length;if(that.app_num>24)
{load_recent_app();}
else
{callback();}};var load_app_data=function(){if($("head_applist"))
{var data=$("head_applist").retrieve("app_data");if(data){return set_app_data(data);}}
var myAjax=new Ajax.Request("/app/left.php",{method:"get",parameters:"r="+Math.random(),onComplete:function(trans){var data=trans.responseText.evalJSON();set_app_data.call(that,data);}});};var load_recent_app=function(){var myAjax=new Ajax.Request("/app/recent.php",{method:"get",parameters:"r="+Math.random(),onComplete:function(trans){var data=trans.responseText.evalJSON();that.recent_app_data=data;that.recent_app_num=data.length;callback();}});};load_app_data();};this.init=function(){var that=this;if(this.loaded)return;this.loaded=true;this.apps_tab=$j("#kxchat_appstab");this.closed=true;this.app_data=null;this.app_num=0;this.recent_app_data=null;this.recent_app_num=0;this.apps_tab.html('<span class="c9">正在加载...</span>');this.load_data(function(){that.build();});};this.resize_event=function(){if(!this.app_popup)return;if(!this.closed)
{if($j(window).width()>$j("#main").innerWidth())
{this.adjust();this.app_popup.show();}
else
{this.app_popup.hide();}}};this.toggle=function(){if(!this.app_popup)
{return this.init();}
if(this.app_popup.css("display")=="block")
{this.closed=true;}
else
{this.closed=false;}
this.adjust();if(ie6)
{this.app_popup.toggle();this.toggle_tab_arrow();}
else
{var that=this;this.app_popup.animate({height:['toggle','swing']},function(){that.toggle_tab_arrow();});}};this.toggle_tab_arrow=function(){if(this.closed)
{this.apps_tab.attr("style","");}
else
{this.apps_tab.attr("style","background-position: 20px -1215px;");}};this.build=function(){var that=this;this.app_popup=$j("<div />").attr("id","kxchat_appstab_popup").addClass("kxchat_tabpopup").appendTo($j("body"));this.app_popup.hide();this.app_popup_title=$j('<div id="kxchat_appstab_popup_title">我的组件</div>').appendTo(this.app_popup);this.app_popup_minbox=$j('<div class="kxchat_minbox" title="最小化"></div>').appendTo(this.app_popup_title);this.app_popup.append('<div id="kxchat_appstab_popup_head"><a href="/app/list.php" class="sl kxchat_appstab_add">添加组件</a><a href="/set/appman.php" class="sl kxchat_appstab_management">组件设置</a></div>');this.build_app_list();this.app_popup_minbox.click(function(){that.toggle();that.apps_tab.removeClass("kxchat_appstab_expand");}).mouseover(function(){$j(this).addClass("kxchat_minboxhover");}).mouseout(function(){$j(this).removeClass("kxchat_minboxhover");});$j(window).bind("resize",function(){that.resize_event();});this.apps_tab.html("我的组件");this.toggle();};this.build_panel_container=function(){this.app_panel_outer=$j('<div class="kxchat_appstab_panel_outer"></div>');this.app_panel_inner=$j('<div class="kxchat_appstab_panel_inner"></div>');this.app_panel_outer.append(this.app_panel_inner);this.app_panel.append(this.app_panel_outer);};this.build_app_list=function(){this.app_panels=[];this.build_first_app_panel();this.page_idx=0;this.page_num=1;while(this.last_app_idx<this.app_num)
{this.page_num++;this.build_other_app_panel(this.last_app_idx);}
this.app_popup.append("<div class=\"c\"></div>");if(this.page_num>1)
{var that=this;setTimeout(function(){that.build_app_pagination();},100);}
else
{this.app_panel_inner.css("position","static").css("height","auto");this.app_panel_outer.css("height","auto");}
var that=this;this.app_panel.click(function(){that.active();});};this.build_first_app_panel=function(){this.app_panel=$j('<div class="kxchat_appstab_popup_panel" style="float:left;"></div>').appendTo(this.app_popup);this.build_panel_container();var app_panel_perslide_con=$j('<div class="l app_panel_perslide_con"></div>');this.app_panels.push(app_panel_perslide_con);app_panel_perslide_con.appendTo(this.app_panel_inner);if(this.recent_app_num>0)
{this.build_recent_app();}
app_panel_perslide_con.append("<h4 style=\"margin-top:-4px \\9;\">组件列表</h4>");var jel_ul=$j("<ul class='l'></ul>").appendTo(app_panel_perslide_con);var max=this.recent_app_num>0?20:24;for(var i=0;i<this.app_num&&i<max;i++)
{jel_ul.append('<li><a class="sl" href="'+this.app_data[i].link+'"><span class="app_'+this.app_data[i].path+'"></span>'+this.app_data[i].title+'</a></li>');}
this.last_app_idx=i;this.app_panel.append("<div class=\"c\"></div>");};this.build_recent_app=function(){var jel_firstslide=this.app_panel_inner.children(".app_panel_perslide_con").append('<h4>最近使用</h4>');var jel_ul=$j('<ul class="kxchat_appstab_recentapplist"></ul>').appendTo(jel_firstslide);var data=this.recent_app_data;for(var i=0;i<this.recent_app_num;i++)
{jel_ul.append('<li><a class="sl" href="'+data[i].link+'"><span class="app_'+data[i].path+'"></span>'+data[i].title+'</a></li>');}
jel_firstslide.append('<div class="c"></div>');};this.build_other_app_panel=function(start){var app_panel_perslide_con=$j('<div class="l app_panel_perslide_con"></div>').css("display","none");app_panel_perslide_con.appendTo(this.app_panel_inner);this.app_panels.push(app_panel_perslide_con);app_panel_perslide_con.append('<h4>组件列表</h4>');var jel_ul=$j("<ul></ul>").appendTo(app_panel_perslide_con);for(var i=start;i<this.app_num&&i-start<24;i++)
{jel_ul.append('<li><a class="sl" href="'+this.app_data[i].link+'"><span class="app_'+this.app_data[i].path+'"></span>'+this.app_data[i].title+'</a></li>');}
this.last_app_idx=i;};this.build_app_pagination=function()
{if(!this.pagination)
{this.pagination=$j('<p class="kxchat_appstab_pagination"></p>').appendTo(this.app_popup).hide();this.pagination_prev=$j('<span class="kxchat_appstab_pageprev" title="上一页"></span>').appendTo(this.pagination);this.pagination_next=$j('<span class="kxchat_appstab_pagenext" title="下一页"></span>').appendTo(this.pagination);var that=this;var width_str=this.app_panel_outer.css("width");this.pagination_prev.click(function(){if($j(this).hasClass("kxchat_appstab_pageprev_disable"))return;var curr_panel=that.app_panels[that.page_idx];var prev_panel=that.app_panels[that.page_idx-1];prev_panel.css("display","block");that.page_idx--;that.app_panel_inner.animate({left:"+="+width_str},function(){curr_panel.css("display","none");});that.build_app_pagination();});this.pagination_next.click(function(){if($j(this).hasClass("kxchat_appstab_pagenext_disable"))return;var next_panel=that.app_panels[that.page_idx+1];next_panel.css("display","block");that.page_idx++;that.app_panel_inner.animate({left:"-="+width_str},function(){});that.build_app_pagination();});}
if(this.page_idx==this.page_num-1)
{this.pagination_next.addClass("kxchat_appstab_pagenext_disable");}
else if(this.page_num>1)
{this.pagination_next.removeClass("kxchat_appstab_pagenext_disable");}
if(this.page_idx==0)
{this.pagination_prev.addClass("kxchat_appstab_pageprev_disable");}
else
{this.pagination_prev.removeClass("kxchat_appstab_pageprev_disable");}
this.pagination.show();};this.adjust=function(){if(this.app_popup)
{var base=$j("#kxchat_base");this.app_popup.css('left',base.position().left);this.active();}
if(ie6&&this.app_popup)
{this.app_popup.css("position","absolute");var height=this.app_popup.height();height=(height==449)?466:height;var top=parseInt($j(window).height())-parseInt(this.app_popup.css("bottom"))-height+$j(window).scrollTop()-2;this.app_popup.css("top",top+"px");}};this.active=function(){this.app_popup.css("z-index",getMaxZIndex()+1);};};ChatAppList.getInstance=function(){if(!ChatAppList.instance){ChatAppList.instance=new ChatAppList();}
return ChatAppList.instance;};var getMaxZIndex=function(){var max_zindex=910000;ChatGlobal.getEl(".kxchat_popup_base").children("div").add($j("#kxchat_userstab")).each(function(){var zindex=parseInt($j(this).css("z-index"),10);if(zindex&&zindex>max_zindex){max_zindex=zindex;}});var chatapplist=ChatAppList.getInstance();if(chatapplist.app_popup)
{var zindex=parseInt(chatapplist.app_popup.css("z-index"),10);if(zindex>max_zindex)
{max_zindex=zindex;}}
return max_zindex;};