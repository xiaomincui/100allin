
document.domain="http://localhost";var pr_user=null;var pr_web=null;var pr_seq=0;var online_Timers={};function presence_query()
{var url="http://localhost/k/"+Math.random()+"/"+pr_user+"/"+pr_seq;$j.ajax({type:"GET",url:url,cache:true,timeout:70000,success:function(data,textStatus,request){presence_show(request);},error:function(request,textStatus,errorThrown){if(request.status>0&&request.status!=200)
{parent.g_im_web="";parent.g_im_errcount++;setTimeout(pInitNewMsg,5000);}
else
{presence_query();}}});}
function presence_call(context,method)
{if(typeof(context[method])=="function")
{context[method].apply(context,Array.prototype.slice.call(arguments,2));}}
function presence_show(req)
{var again=false;r=req.responseText;if(r.length>0&&req.status==200)
{if(typeof(ver_kxchat)!="undefined"&&ver_kxchat)
{if(parent.offline)
{parent.switchChatOffline(0);parent.poolchatmsg();}}
var x=r.evalJSON();if(typeof x=='object')
{if(x.t=='refresh')
{if(x.seq>=0)
pr_seq=x.seq;again=true;}
else if(x.t=='inform')
{var infos=x.infos;pr_seq+=infos.length;for(var i=0;i<infos.length;++i)
{if(infos[i].c=='.ctx')
{var ret=null;eval("ret = "+infos[i].o.state);parent.checkNewMsgShow(ret);}
else
{if(infos[i].c=='chat.msg')
{presence_call(parent,"showImMessage",infos[i].o);presence_call(parent,"hideTypingTip",infos[i].o.uid);}
else if(infos[i].c=='chat.typing')
{presence_call(parent,"showTypingTip",infos[i].o);}
else if(infos[i].c=='chat.clear')
{presence_call(parent,"justRemoveNotify",infos[i].o.uid,infos[i].o.chatid);}
else if(infos[i].c=='chat.close')
{presence_call(parent,"justCloseChatbox",infos[i].o.uid,infos[i].o.chatid);}
else if(infos[i].c=='chat.max')
{presence_call(parent,"justMaxChatbox",infos[i].o.uid,infos[i].o.chatid);}
else if(infos[i].c=='chat.min')
{presence_call(parent,"justMinChatbox",infos[i].o.uid,infos[i].o.chatid);}
else if(infos[i].c=='.user.online')
{var uid=infos[i].o.uid;if(online_Timers[uid]>0)
{clearTimeout(online_Timers[uid]);online_Timers[uid]=0;}
online_Timers[uid]=setTimeout("_setBuddyChatOnline("+uid+", true)",5000);}
else if(infos[i].c=='.user.offline')
{var uid=infos[i].o.uid;if(online_Timers[uid]>0)
{clearTimeout(online_Timers[uid]);online_Timers[uid]=0;}
online_Timers[uid]=setTimeout("_setBuddyChatOnline("+uid+", false)",5000);}}}
again=true;}
else if(x.t=='error')
{parent.g_im_web="";parent.g_im_errcount++;setTimeout(pInitNewMsg,5000);}}}
else if(r.length>0&&req.status>0)
{}
else
{parent.g_im_web="";parent.g_im_errcount++;setTimeout(pInitNewMsg,5000);}
if(again)
presence_query();}
function presence_getseq(req)
{r=req.responseText;if(r.length>0&&(req.status==200))
{var x=r.evalJSON();if(typeof x=='object')
{if(x.t=='ctx')
{if(x.seq>=0)
{parent.g_im_errcount=0;pr_seq=x.seq;presence_query();}}
else if(x.t=='error')
{parent.g_im_web="";parent.g_im_errcount++;setTimeout(pInitNewMsg,5000);}}}
else if(r.length>0&&req.status>0)
{}
else
{parent.g_im_web="";parent.g_im_errcount++;setTimeout(pInitNewMsg,5000);}}
function presence_init()
{var v=parent.document.getElementById("presence_data").value.split(',',3);pr_user=v[0];pr_web=v[1];var url="http://localhost/g/"+Math.random()+"/"+pr_user+"/ctx";$j.ajax({type:"GET",url:url,cache:true,timeout:70000,success:function(data,textStatus,request){presence_getseq(request);},error:function(request,textStatus,errorThrown){parent.g_im_web="";parent.g_im_errcount++;setTimeout(pInitNewMsg,5000);}});}
function pInitNewMsg()
{if(typeof(parent.initNewMsg)=='function')
{parent.initNewMsg();}}
function _setBuddyChatOnline(uid,online)
{presence_call(parent,"setChatBuddyOnline",uid,online);online_Timers[uid]=0;}
presence_init();