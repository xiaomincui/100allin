
document.domain="localhost";var g_im_errcount=0;var piframe=null;function initNewMsg()
{if(g_im_errcount>5)
{setTimeout(initNewMsg,60000);g_im_errcount=0;return;}
if(g_im_errcount>2)
{if(typeof(ver_kxchat)!="undefined"&&ver_kxchat)
{setChatOffline(1);}}
if(!g_im_web||(g_im_web&&g_im_web==""))
{var url="/home/newmsg.php";var pars="im=1";$j.ajax({type:"post",url:url,data:{im:1},cache:false,timeout:10000,success:function(data,textStatus,request){postInitNewMsg(request);},error:function(request,textStatus,errorThrown){setTimeout(initNewMsg,5000);g_im_errcount++;}});}
else
{getIMNewsMsg();}}
function postInitNewMsg(req)
{var rtxt=req.responseText;if(req.status==200&&rtxt.length>0)
{r=rtxt.evalJSON();var pr_user="";var pr_web="";var pr_seq=0;if(r.t=='error')
{g_im_errcount++;setTimeout(initNewMsg,5000);return;}
else if(r.t=='init')
{document.getElementById("presence_data").value=r.vuid+","+r.imweb+","+r.imseq;g_im_web=r.imweb;}
if(g_im_web&&g_im_web!="")
{getIMNewsMsg();}
else
{g_im_errcount++;setTimeout(initNewMsg,5000);}}
else
{setTimeout(initNewMsg,5000);g_im_errcount++;g_im_web="";}}
function getIMNewsMsg()
{if(g_im_web&&g_im_web!="")
{if(piframe)
{piframe.src="http://localhost/ifr/js?r=http://localhost/kaixin/js/kxbase-3.js&r=http://localhost/kaixin/js/presence-17.js&rnd="+Math.random();}
else
{piframe=document.createElement('iframe');piframe.setAttribute('id','presence_iframe');piframe.setAttribute('src',"http://localhost/ifr/js?r=http://localhost/kaixin/js/kxbase-3.js&r=http://localhost/kaixin/js/presence-17.js&rnd="+Math.random());piframe.style.left="-100px";piframe.style.top="-100px";piframe.style.height="1px";piframe.style.width="1px";piframe.style.visibility="hidden";piframe.style.display="none";document.body.appendChild(piframe);}}}
function piframe_init()
{setTimeout(initNewMsg,3000);}