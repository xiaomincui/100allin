

var f_inputid="";var f_frienddata=[];var f_seluid=0;var f_word1="";var f_word2="";var f_pars="";var f_maxnum=0;function friendSuggest(inputid,word1,word2)
{if(!$(inputid))return;f_inputid=inputid;f_word1=word1;f_word2=word2;var obj=$(f_inputid);if($("f_suggest")!=null)
{if($("f_suggest").parentNode!=obj.parentNode)
{$("f_suggest").parentNode.removeChild($("f_suggest"));}
else
{return;}}
var pos=getpos($(f_inputid));var html='<div class="fsg_nl" id="f_suggest" style="display:none;z-index:1000;width:'+(pos.right-pos.left-5)+'px;"></div><div id="f_emptysuggest" class="fsg_nl" style="z-index:10000;display:none;font-size:12px;padding-left:7px;background:#eeeeee;color:#666666;width:'+(pos.right-pos.left-9)+'px;"></div>';new Insertion.After(f_inputid,html);f_adjustPos();}
function f_adjustPos()
{var pos=getpos($(f_inputid));try
{$("f_suggest").style.left=parseInt(pos.left)+"px";$("f_suggest").style.top=parseInt(pos.bottom+2)+"px";$("f_suggest").style.width=parseInt(pos.right-pos.left-5)+"px";$("f_emptysuggest").style.left=parseInt(pos.left)+"px";$("f_emptysuggest").style.top=parseInt(pos.bottom+2)+"px";$("f_emptysuggest").style.width=parseInt(pos.right-pos.left-9)+"px";}
catch(e)
{}}
function f_inputOnfocus(event,thisobj)
{if(thisobj.value=="")
{f_adjustPos();$("f_emptysuggest").innerHTML=f_word1;$("f_emptysuggest").style.display="block";}}
function f_inputOnkeydown(evnt,thisobj)
{if(evnt.keyCode==13)
{return false;}
var hotinfo=f_getHotNum();var hotnum=hotinfo.hotnum;var num=hotinfo.totalnum;if(evnt.keyCode==40)
{if($("f_suggest_0")!=null&&$("f_suggest").style.display=="block")
{if(hotnum==-1)
{$("f_suggest_0").className="sgt_on";}
else
{var nextnum=hotnum==num-1?0:hotnum+1;$("f_suggest_"+hotnum).className="sgt_of";$("f_suggest_"+nextnum).className="sgt_on";}
return false;}}
if(evnt.keyCode==38)
{if($("f_suggest_0")!=null&&$("f_suggest").style.display=="block")
{if(hotnum==-1)
{$("f_suggest_"+(num-1)).className="sgt_on";}
else
{var prevnum=hotnum==0?num-1:hotnum-1;$("f_suggest_"+hotnum).className="sgt_of";$("f_suggest_"+prevnum).className="sgt_on";}}}}
function f_inputOnkeyup(evnt,thisobj)
{var hasthisperson=false;for(var i=0;i<f_frienddata.length;i++)
{if(f_frienddata[i].real_name==$(f_inputid).value)
{hasthisperson=true;}}
if(hasthisperson==false)
{f_seluid=0;}
if(evnt.keyCode==13)
{var hotinfo=f_getHotNum();var hotnum=hotinfo.hotnum;var totalnum=hotinfo.totalnum;if($("f_suggest").style.display=="block"&&hotnum!=-1&&totalnum>0)
{$(f_inputid).value=f_frienddata[hotnum].real_name_unsafe;f_seluid=f_frienddata[hotnum].uid;if('function'==typeof(f_afterseluid))
{f_afterseluid(f_seluid);}
$("f_suggest").style.display="none";}}
else if(evnt.keyCode==38||evnt.keyCode==40)
{}
else
{f_ajax_submit();}}
function f_ajax_submit()
{var url="/interface/suggestfriend.php";var text=encodeURIComponent($(f_inputid).value);var pars="text="+text+"&pars="+f_pars+"&maxnum="+f_maxnum;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){f_ajax_show(req);}});}
function f_ajax_show(req)
{var arr=eval(req.responseText);f_frienddata=arr;if(arr.length==0)
{$("f_suggest").style.display="none";if($(f_inputid).value=="")
{$("f_emptysuggest").innerHTML=f_word1;$("f_emptysuggest").style.display="block";}
else
{if(f_word2=="")
{$("f_emptysuggest").style.display="none";}
else
{$("f_emptysuggest").innerHTML=f_word2;$("f_emptysuggest").style.display="block";}}
return;}
var html="";for(var i=0;i<arr.length;i++)
{html+='<div id=f_suggest_'+i+' class="sgt_of" style="font-size:12px;width:'+(parseInt($("f_suggest").style.width)-10)+'px;" onmouseover="f_suggestOnmouseover(this)" onmousedown="f_suggestOnmousedown(this);">'+arr[i].real_name+'&nbsp;&nbsp;'+f_logo20(arr[i])+'</div>';}
$("f_suggest").innerHTML=html;$("f_suggest").style.display="block";$("f_emptysuggest").style.display="none";f_adjustPos();if($("f_suggest_0")!=null&&$("f_suggest").style.display=="block")
{$("f_suggest_0").className="sgt_on";}}
function f_getHotNum()
{var obj;var num=0;var hotnum=-1;while((obj=$("f_suggest_"+num))!=null)
{if(obj.className=="sgt_on")
{hotnum=num;}
num++;}
return{"hotnum":hotnum,"totalnum":num};}
function f_suggestOnmouseover(thisobj)
{var arr=thisobj.id.split('_');var thisnum=arr[2];var obj;var num=0;while((obj=$("f_suggest_"+num))!=null)
{if(thisnum==num)
{obj.className="sgt_on";}
else
{obj.className="sgt_of";}
num++;}}
function f_suggestOnmousedown(thisobj)
{var arr=thisobj.id.split('_');var num=arr[2];$(f_inputid).value=f_frienddata[num].real_name_unsafe;f_seluid=f_frienddata[num].uid;if('function'==typeof(f_afterseluid))
{f_afterseluid(f_seluid);}
$("f_suggest").style.display="none";}
function f_inputOnblur()
{if($("f_suggest"))
{$("f_suggest").style.display="none";}
$("f_emptysuggest").style.display="none";}
function f_logo20(obj)
{var logo20="";if(typeof obj.logo20!="undefined")
{logo20="<img src='"+obj.logo20+"'  align=absmiddle width=15  />";}
return logo20;}
function starfriends_add(uid)
{var url="/friend/addverify.php";var pars="touid="+uid+"&quick=1";var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){ajax_show_starfriends_add_ok(req);}});var myAjax2=new Ajax.Request("/interface/c.php",{method:"post",parameters:"name=gardenstarad_click_"+uid,onComplete:function(trans){}});}
function ajax_show_starfriends_add_ok(req)
{var result;eval("result="+req.responseText);uid=result.uid;rand=result.rand;content=result.content;typeid=result.type;if(typeid==0)
{$("addfriend_"+uid).innerHTML='<div style="margin-right: 6px;" class="r"><span class="c9" >你已是好友</span></div>';}
else
{$("addfans_"+uid).innerHTML='<div style="margin-right: 6px;" class="r"><span class="c9" >你已是粉丝</span></div>';}
$("div_add_ok_"+uid).innerHTML='<img src="http://img1.kaixin001.com.cn/i/fzcg_dh.gif"class="l" /><div class="l ml10">'+content+'</div>';s("div_add_ok_"+uid);starfriend_fade("div_add_ok_"+uid);}
var starfriend_timer=null;var starfriend_ele_a=starfriend_ele_b=null;var starfriend_wait=0;function starfriend_fade(a)
{starfriend_ele_a=document.getElementById(a);if(!starfriend_ele_a){return;}
if(document.all)
{starfriend_ele_a.filters.alpha.opacity=100;}
else
{starfriend_ele_a.style.opacity=1;}
starfriend_ele_a.style.zIndex=1;starfriend_fade_opacity();}
function starfriend_fade_opacity()
{starfriend_wait=starfriend_wait+1;if(starfriend_wait>20)
{var ifstop=false;if(document.all)
{if(starfriend_ele_a.filters.alpha.opacity>0)
{starfriend_ele_a.filters.alpha.opacity-=5;}
else
{ifstop=true;}}
else
{if(starfriend_ele_a.style.opacity>0)
{starfriend_ele_a.style.opacity-=0.05;}
else
{ifstop=true;}}
if(ifstop==true)
{window.clearTimeout(starfriend_timer);}
else
{starfriend_timer=window.setTimeout('starfriend_fade_opacity()',100);}}
else
{starfriend_timer=window.setTimeout('starfriend_fade_opacity()',100);}}

var fs2_mode=0;var fs2_data=[];var fs2_dirty=false;var fs2_pars="";var fs2_maxnum=0;var fs2_inputname="";var fs2_fsgnrname="";var fs2_xxshname="";var fs2_allfriendname="";var fs2_withex="";function fs2_hasActive()
{for(var i=0;i<fs2_data.length;i++)
{if(fs2_data[i].type=="active")
{return i;}}
return-1;}
function fs2_superOnclick()
{if(fs2_fsgnrname=="")
{$('fsg_nr').style.display="none";}
else
{$(fs2_fsgnrname).style.display="none";}
if(fs2_hasActive()!=-1)
{if($("active").value!=""&&$("suggest").style.display=="none")
{$("active").value="";}
$("active").focus();}
else
{fs2_data[fs2_data.length]={type:"active"};fs2_superView();}
if(fs2_inputname=="")
{$("superinput").parentNode.className="it2";}
else
{$(fs2_inputname).parentNode.className="it1";}}
function fs2_activeFocus()
{for(var i=0;i<5;i++)
{if($("active"))
{$("active").focus();}}}
function fs2_superView()
{if(fs2_data.length>0&&fs2_data[0].type=="static")
{var f2_seluid=fs2_data[0].uid;if('function'==typeof(f2_afterseluid))
{f2_afterseluid(f2_seluid);}
fs2_refresh(fs2_data[0].uid);}
else
{if($("fs2_icon"))
{$("fs2_icon").style.display="none";}
if('function'==typeof(fs2_onclear))
{fs2_onclear();}}
var html="";for(var i=0;i<fs2_data.length;i++)
{if(fs2_data[i].type=="static")
{if(fs2_data[i].uid=="0"||fs2_data[i].uid==0)
{html+='<div style="float:left;background:#fff9d7;margin:1px 5px 1px 0; padding:0 5px;">'+fs2_data[i].real_name+'</div>';}
else
{var logo=fs2_logo20(fs2_data[i]);if(logo=="")
{html+='<div class="fsg_hy2">'+fs2_data[i].real_name+'&nbsp;<a style="cursor:pointer;" onclick="javascript:fs2_inputDelete('+"'"+i+"'"+');"><img border="0" align="absmiddle" alt="移除" src="http://img1.kaixin001.com.cn/i2/del.gif"/></a></div>';}
else
{html+='<div class="fsg_hy2">'+fs2_data[i].real_name+'&nbsp;&nbsp;'+logo+'&nbsp;<a style="cursor:pointer;" onclick="javascript:fs2_inputDelete('+"'"+i+"'"+');"><img border="0" align="absmiddle" alt="移除" src="http://img1.kaixin001.com.cn/i2/del.gif"/></a></div>';}}}
else
{html+='<div class="fsg_id" id="activediv" style="width:50px;"><input onkeydown="return fs2_inputOnkeydown(event)" onkeyup="fs2_inputOnkeyup(event)" onblur="fs2_inputOnblur(this);" onfocus="fs2_inputOnfocus(this);" id="active" name="active" type="text" value="" class="fsg_it" size="2" Autocomplete="off" maxlength=50/><div class="fsg_nl" id="suggest" style="display:none;width:210px;"></div><div id="emptysuggest" class="fsg_nl" style="padding-left:7px;background:#eeeeee;color:#666666;width:220px;">请输入好友的姓名(开心网上姓名)</div></div></div>';}}
if(fs2_inputname=="")
{$("superinput").innerHTML=html==""?"&nbsp;":html;}
else
{$(fs2_inputname).innerHTML=html==""?"&nbsp;":html;}
fs2_activeFocus();}
function fs2_inputDelete(index)
{var fs2_data2=[];var len=fs2_data.length;var j=0;for(var i=0;i<len;i++)
{if(i==index)
{continue;}
fs2_data2[j]=fs2_data[i];j++;}
fs2_data=fs2_data2;fs2_dirty=true;fs2_superView();return;}
function fs2_getHotNum()
{var obj;var num=0;var hotnum=-1;while((obj=$("suggest_"+num))!=null)
{if(obj.className=="sgt_on")
{hotnum=num;}
num++;}
return{"hotnum":hotnum,"totalnum":num};}
function fs2_inputOnblur(thisobj)
{$("suggest").style.display="none";$("emptysuggest").style.display="none";if($("active")&&$("active").value!="")
{$("active").value="";}
if(fs2_inputname=="")
{$("superinput").parentNode.className="it1";}
else
{$(fs2_inputname).parentNode.className="it1";}}
function fs2_inputOnfocus(thisobj)
{if(fs2_data.length>1)
{$("emptysuggest").style.display="none";return false;}
if(thisobj.value=="")
{$("emptysuggest").style.display="block";$("emptysuggest").innerHTML="请输入好友的姓名(支持拼音首字母输入)";}}
function fs2_inputOnkeydown(evnt)
{if(fs2_data.length>1)
{if(evnt.preventDefault)
{evnt.preventDefault();}
else
{evnt.returnValue=0;}}
$("active").style.width=b_strlen($("active").value)*6+20+"px";if(evnt.keyCode==13)
{return false;}
var activenum=fs2_hasActive();if(evnt.keyCode==8&&fs2_data[activenum-1]&&$("active").value=="")
{var fs2_data2=[];var j=0;for(var i=0;i<fs2_data.length;i++)
{if(activenum-1==i)
{continue;}
fs2_data2[j]=fs2_data[i];j++;}
fs2_data=fs2_data2;fs2_dirty=true;fs2_superView();return;}
if(evnt.keyCode==37&&fs2_data[activenum-1]&&$("active").value=="")
{return;var obj=fs2_data[activenum];fs2_data[activenum]=fs2_data[activenum-1];fs2_data[activenum-1]=obj;fs2_superView();return;}
if(evnt.keyCode==39&&fs2_data[activenum+1]&&$("active").value=="")
{return;var obj=fs2_data[activenum];fs2_data[activenum]=fs2_data[activenum+1];fs2_data[activenum+1]=obj;fs2_superView();return;}
var hotinfo=fs2_getHotNum();var hotnum=hotinfo.hotnum;var num=hotinfo.totalnum;if(evnt.keyCode==40)
{if($("suggest_0")!=null&&$("suggest").style.display=="block")
{if(hotnum==-1)
{$("suggest_0").className="sgt_on";}
else
{var nextnum=hotnum==num-1?0:hotnum+1;$("suggest_"+hotnum).className="sgt_of";$("suggest_"+nextnum).className="sgt_on";}
return false;}}
if(evnt.keyCode==38)
{if($("suggest_0")!=null&&$("suggest").style.display=="block")
{if(hotnum==-1)
{$("suggest_"+(num-1)).className="sgt_on";}
else
{var prevnum=hotnum==0?num-1:hotnum-1;$("suggest_"+hotnum).className="sgt_of";$("suggest_"+prevnum).className="sgt_on";}}}}
function fs2_inputOnkeyup(evnt)
{if(evnt.keyCode==13)
{var hotinfo=fs2_getHotNum();var hotnum=hotinfo.hotnum;var totalnum=hotinfo.totalnum;var hasuser=$("suggest").style.display=="block"&&hotnum!=-1&&totalnum>0;if(fs2_mode==1&&!hasuser&&$("active").value.length)
{var escape_real_name=$("active").value.replace(/&/g,"&amp;");escape_real_name=escape_real_name.replace(/</g,"&lt;");escape_real_name=escape_real_name.replace(/>/g,"&gt;");var friendobj={uid:"0",real_name:escape_real_name,real_name_unsafe:$("active").value,type:"static"};var activenum=fs2_hasActive();for(var i=fs2_data.length;i>activenum;i--)
{fs2_data[i]=fs2_data[i-1];}
fs2_data[activenum]=friendobj;fs2_dirty=true;fs2_superView();}
else if(hasuser)
{var friendobj=fs2_frienddata[hotnum];friendobj.type="static";var activenum=fs2_hasActive();for(var i=fs2_data.length;i>activenum;i--)
{fs2_data[i]=fs2_data[i-1];}
fs2_data[activenum]=friendobj;fs2_dirty=true;fs2_superView();}}
if(evnt.keyCode==38||evnt.keyCode==40)
{}
else if(evnt.keyCode==27)
{fs2_suggestClose();}
else
{fs2_ajax_submit();}}
function fs2_ajax_submit()
{var url="/interface/suggestfriend.php";var text=encodeURIComponent($("active").value);var pars="pars="+fs2_pars+"&text="+text+"&maxnum="+fs2_maxnum;var myAjax=new Ajax.Request(url,{method:"get",parameters:pars,onComplete:function(req){fs2_ajax_show(req);}});}
var fs2_frienddata=[];function fs2_ajax_show(req)
{var arr=eval(req.responseText);fs2_frienddata=arr;if(arr.length==0)
{$("suggest").style.display="none";if(fs2_data.length>1)
{$("emptysuggest").style.display="none";}
else
{$("emptysuggest").style.display="block";}
if($("active").value=="")
{$("emptysuggest").innerHTML="请输入好友的姓名(支持拼音首字母输入)";}
else
{if(fs2_mode==1)
{$("emptysuggest").innerHTML="姓名不在好友列表哦";}
else
{$("emptysuggest").innerHTML="姓名不在好友列表哦，请重新输入";}}
return;}
var html="";for(var i=0;i<arr.length;i++)
{html+='<div id=suggest_'+i+' class="sgt_of" style="width:200px;" onmouseover="fs2_suggestOnmouseover(this)" onmousedown="fs2_suggestOnmousedown(this);">'+arr[i].real_name+'　'+fs2_logo20(arr[i])+'</div>';}
$("suggest").innerHTML=html;$("suggest").style.display="block";$("emptysuggest").style.display="none";if($("suggest_0")!=null&&$("suggest").style.display=="block")
{$("suggest_0").className="sgt_on";}}
function fs2_suggestcloseOnMouseover()
{var num=0;while((obj=$("suggest_"+num))!=null)
{if(obj.className=="sgt_on")
{obj.className="sgt_of";}
num++;}}
function fs2_suggestClose()
{fs2_superView();}
function fs2_suggestOnmouseover(thisobj)
{var arr=thisobj.id.split('_');var thisnum=arr[1];var obj;var num=0;while((obj=$("suggest_"+num))!=null)
{if(thisnum==num)
{obj.className="sgt_on";}
else
{obj.className="sgt_of";}
num++;}}
function fs2_suggestOnmousedown(thisobj)
{var arr=thisobj.id.split('_');var num=arr[1];var friendobj=fs2_frienddata[num];friendobj.type="static";var activenum=fs2_hasActive();for(var i=fs2_data.length;i>activenum;i--)
{fs2_data[i]=fs2_data[i-1];}
fs2_data[activenum]=friendobj;fs2_dirty=true;fs2_superView();}
function fs2_viewAllfriend()
{if($("suggest"))
{$("suggest").style.display="none";}
var fsgnrname="fsg_nr";if(fs2_fsgnrname!="")
{fsgnrname=fs2_fsgnrname;}
var xxshname="xx_sh";if(fs2_xxshname!="")
{xxshname=fs2_xxshname;}
if($(fsgnrname).style.display=="block")
{$(fsgnrname).style.display="none";$(xxshname).innerHTML='<img src="http://img1.kaixin001.com.cn/i/xx_xx1.gif" class="cp" onmouseover="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx2.gif\';" onmouseout="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx1.gif\';" alt="选择好友" />';}
else
{var url="/interface/suggestfriend.php";var pars="pars="+fs2_pars+"&type=all"+"&maxnum="+fs2_maxnum;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){fs2_ajax_allfriendshow(req);}});$(fsgnrname).style.display="block";$(xxshname).innerHTML='<img src="http://img1.kaixin001.com.cn/i/xx_xs1.gif" class="cp" onmouseover="this.src=\'http://img1.kaixin001.com.cn/i/xx_xs2.gif\';" onmouseout="this.src=\'http://img1.kaixin001.com.cn/i/xx_xs1.gif\';" alt="选择好友" />';}}
var fs2_allfrienddata=[];function fs2_ajax_allfriendshow(req)
{var arr=eval(req.responseText);fs2_allfrienddata=arr;var html="";for(var i=0;i<Math.ceil(arr.length/3)*3;i++)
{if(i%3==0)
{html+='<div class="sgt_of" style="width:300px;">\n';}
if(arr[i])
{html+='<div class="l" style="width:100px;"><input id="radio'+i+'" type="radio" name="friend"/>'+arr[i].real_name+'&nbsp;&nbsp;'+fs2_logo20(arr[i])+'</div>\n';}
if(i%3==2)
{html+='<div class="c"></div>\n';html+='</div>\n';}}
if(fs2_allfriendname=="")
{$("allfriend").innerHTML=html;}
else
{$(fs2_allfriendname).innerHTML=html;}}
function fs2_selectFriend()
{for(var i=0;i<fs2_allfrienddata.length;i++)
{if($("radio"+i).checked)
{var obj=fs2_allfrienddata[i];obj.type="static";fs2_data[0]=fs2_allfrienddata[i];}}
var fs2_data2=[];var j=0;for(var i=0;i<fs2_data.length;i++)
{if(fs2_data[i].type=="active")
{continue;}
fs2_data2[j]=fs2_data[i];j++;}
fs2_data=fs2_data2;fs2_dirty=true;if(fs2_fsgnrname=="")
{$('fsg_nr').style.display="none";}
else
{$(fs2_fsgnrname).style.display="none";}
var xxshname="xx_sh";if(fs2_xxshname!="")
{xxshname=fs2_xxshname;}
$(xxshname).innerHTML='<img src="http://img1.kaixin001.com.cn/i/xx_xx1.gif" class="cp" onmouseover="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx2.gif\';" onmouseout="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx1.gif\';" alt="选择好友" />';fs2_superView();}
function fs2_refresh(uid)
{var url="/interface/user.php";var pars="uid="+uid;if(fs2_withex!="")
{pars+="&withex=1&t="+(new Date()).getTime();}
var myAjax=new Ajax.Request(url,{method:"get",parameters:pars,onComplete:function(req){fs2_refreshShow(req);}});}
function fs2_refreshShow(req)
{eval("r="+req.responseText);if($("icon120"))
{$("icon120").src=r.logo120;}
if($("icon50"))
{$("icon50").src=r.logo50;}
if($("icon25"))
{$("icon25").src=r.logo25;}
if($("fs2_icon"))
{$("fs2_icon").style.display="block";}
if('function'==typeof(fs2_onrefresh))
{fs2_onrefresh(r);}}
function fs2_logo20(obj)
{var logo20="";if(typeof obj.logo20!="undefined")
{logo20="<img src='"+obj.logo20+"' align=absmiddle width=15 />";}
return logo20;}

var fs_selectpars="gf_me";var fs_mode=0;var fs_data=[];var fs_dirty=false;var fs_maxcount=30;var fs_alert=false;var fs_gindex=0;var fs_maxnum=0;var fs_superinput="superinput";var fs_ptrimg="xx_sh";var fs_fsg_nr="fsg_nr";var fs_groupsel="groupsel";var fs_allfriend="allfriend";var fs_selall="selall";function fs_resetElements(superinput,ptrimg,fsg_nr,groupsel,allfriend)
{var inputHTML="";var groupselHTML="";var allfriendHTML="";if(superinput!=fs_superinput)
{if($(fs_fsg_nr))
{$(fs_fsg_nr).style.display="none";}
if($(fs_ptrimg))
{$(fs_ptrimg).innerHTML="<img src=\"http://img1.kaixin001.com.cn/i/xx_xx1.gif\" class=\"cp\" onmouseover=\"this.src='http://img1.kaixin001.com.cn/i/xx_xx2.gif';\" onmouseout=\"this.src='http://img1.kaixin001.com.cn/i/xx_xx1.gif';\" alt=\"选择好友\" />";}
if($(fs_superinput))
{inputHTML=$(fs_superinput).innerHTML;$(fs_superinput).innerHTML="&nbsp;";}
if($(fs_groupsel))
{groupselHTML=$(fs_groupsel).innerHTML;$(fs_groupsel).innerHTML="";}
if($(fs_allfriend))
{allfriendHTML=$(fs_allfriend).innerHTML;$(fs_allfriend).innerHTML="";}
fs_superinput=superinput;fs_ptrimg=ptrimg;fs_fsg_nr=fsg_nr;fs_groupsel=groupsel;fs_allfriend=allfriend;$(fs_superinput).innerHTML=inputHTML;$(fs_groupsel).innerHTML=groupselHTML;$(fs_allfriend).innerHTML=allfriendHTML;}}
function fs_checkCount(v_alert)
{var c=0;var len=fs_data.length;for(var i=0;i<len;i++)
{if(fs_data[i].type=="static")
{c++;}}
if(c>=fs_maxcount)
{fs_alert=v_alert;}
return c<fs_maxcount;}
function fs_hasActive()
{var len=fs_data.length;for(var i=0;i<len;i++)
{if(fs_data[i].type=="active")
{return i;}}
return-1;}
function fs_superOnclick()
{$(fs_fsg_nr).style.display="none";if(fs_hasActive()!=-1)
{if($("active").value!=""&&$("suggest").style.display=="none")
{$("active").value="";}
$("active").focus();}
else
{fs_data[fs_data.length]={type:"active"};fs_superView();}
$(fs_superinput).parentNode.className="it2";}
function fs_activeFocus()
{for(var i=0;i<5;i++)
{if($("active"))
{$("active").focus();}}}
function fs_superView()
{var html="";var len=fs_data.length;for(var i=0;i<len;i++)
{if(fs_data[i].type=="static")
{if(fs_data[i].uid=="0"||fs_data[i].uid==0)
{html+='<div class="fsg_hy2" style="background:#fff9d7;">'+fs_data[i].real_name+'<a style="cursor:pointer;" onclick="javascript:fs_inputDelete('+"'"+i+"'"+');"><img border="0" align="absmiddle" alt="移除" src="http://img1.kaixin001.com.cn/i2/del.gif"/></a></div>';}
else
{var logo=fs_logo20(fs_data[i]);if(logo!="")
{logo='&nbsp;&nbsp;'+logo;}
html+='<div class="fsg_hy2">'+fs_data[i].real_name+logo+'&nbsp;&nbsp;<a style="cursor:pointer;" onclick="javascript:fs_inputDelete('+"'"+i+"'"+');"><img border="0" align="absmiddle" alt="移除" src="http://img1.kaixin001.com.cn/i2/del.gif"/></a></div>';}}
else
{html+='<div class="fsg_id" id="activediv" style="width:50px;"><input onkeypress="return fs_inputOnkeypress(event)" onkeydown="return fs_inputOnkeydown(event)" onkeyup="fs_inputOnkeyup(event)" onblur="fs_inputOnblur(this);" onfocus="fs_inputOnfocus(this);" id="active" name="active" type="text" value="" class="fsg_it" size="2" Autocomplete="off" maxlength=50/><div class="fsg_nl" id="suggest" style="display:none;width:210px;"></div><div id="emptysuggest" class="fsg_nl" style="padding-left:7px;background:#eeeeee;color:#666666;width:220px;">请输入好友的姓名(开心网上姓名)</div></div></div>';}}
$(fs_superinput).innerHTML=html==""?"&nbsp;":html;var childs=$(fs_superinput).childNodes;var mintop=1000000;var maxbottom=0;var len=childs.length;for(var i=0;i<len;i++)
{if(childs[i].className=="fsg_hy2"||childs[i].className=="fsg_id")
{var pos=getpos(childs[i]);if(pos.top<mintop)
{mintop=pos.top;}
if(pos.bottom>maxbottom)
{maxbottom=pos.bottom;}}}
var height=maxbottom-mintop;height=height<23?23:height;$(fs_superinput).style.height=height+"px";fs_activeFocus();if(fs_alert)
{fs_alert=false;alert("最多只能选择"+fs_maxcount+"个用户！");}
if('function'==typeof(fs_refresh))
{fs_refresh();}}
function fs_getHotNum()
{var obj;var num=0;var hotnum=-1;while((obj=$("suggest_"+num))!=null)
{if(obj.className=="sgt_on")
{hotnum=num;}
num++;}
return{"hotnum":hotnum,"totalnum":num};}
function fs_inputOnblur(thisobj)
{if($("active")&&$("active").value!="")
{fs_getUser();$("active").value="";$("active").blur();}
$(fs_superinput).parentNode.className="it1";$("suggest").style.display="none";$("emptysuggest").style.display="none";}
function fs_inputOnfocus(thisobj)
{if(thisobj.value=="")
{$("emptysuggest").style.display="block";$("emptysuggest").innerHTML="请输入好友的姓名(支持拼音首字母输入)";}}
function fs_inputDelete(index)
{$("superinput").blur();var fs_data2=[];var len=fs_data.length;var j=0;for(var i=0;i<len;i++)
{if(i==index)
{continue;}
fs_data2[j]=fs_data[i];j++;}
fs_data=fs_data2;fs_dirty=true;fs_superView();return;}
function fs_inputOnkeypress(evnt)
{if(evnt.keyCode==13)
{if(typeof(evnt.preventDefault)=="function")
{evnt.preventDefault();}}
return true;}
function fs_inputOnkeydown(evnt)
{$("active").style.width=b_strlen($("active").value)*6+20+"px";if(evnt.keyCode==13)
{if($("active"))
{$("active").value="";}
return false;}
var activenum=fs_hasActive();if(evnt.keyCode==8&&fs_data[activenum-1]&&$("active").value=="")
{if(typeof(evnt.preventDefault)=="function")
{evnt.preventDefault();}
var fs_data2=[];var j=0;var len=fs_data.length;for(var i=0;i<len;i++)
{if(activenum-1==i)
{continue;}
fs_data2[j]=fs_data[i];j++;}
fs_data=fs_data2;fs_dirty=true;fs_superView();return;}
if(evnt.keyCode==37&&fs_data[activenum-1]&&$("active").value=="")
{return;var obj=fs_data[activenum];fs_data[activenum]=fs_data[activenum-1];fs_data[activenum-1]=obj;fs_superView();return;}
if(evnt.keyCode==39&&fs_data[activenum+1]&&$("active").value=="")
{return;var obj=fs_data[activenum];fs_data[activenum]=fs_data[activenum+1];fs_data[activenum+1]=obj;fs_superView();return;}
var hotinfo=fs_getHotNum();var hotnum=hotinfo.hotnum;var num=hotinfo.totalnum;if(evnt.keyCode==40)
{if($("suggest_0")!=null&&$("suggest").style.display=="block")
{if(hotnum==-1)
{$("suggest_0").className="sgt_on";}
else
{var nextnum=hotnum==num-1?0:hotnum+1;$("suggest_"+hotnum).className="sgt_of";$("suggest_"+nextnum).className="sgt_on";}
return false;}}
if(evnt.keyCode==38)
{if($("suggest_0")!=null&&$("suggest").style.display=="block")
{if(hotnum==-1)
{$("suggest_"+(num-1)).className="sgt_on";}
else
{var prevnum=hotnum==0?num-1:hotnum-1;$("suggest_"+hotnum).className="sgt_of";$("suggest_"+prevnum).className="sgt_on";}}}}
function fs_getUser()
{var hotinfo=fs_getHotNum();var hotnum=hotinfo.hotnum;var totalnum=hotinfo.totalnum;var hasuser=$("suggest").style.display=="block"&&hotnum!=-1&&totalnum>0;if(fs_mode==1&&!hasuser&&$("active").value.length)
{if(fs_checkCount(true))
{var escape_real_name=$("active").value.replace(/&/g,"&amp;");escape_real_name=escape_real_name.replace(/</g,"&lt;");escape_real_name=escape_real_name.replace(/>/g,"&gt;");var friendobj={uid:"0",real_name:escape_real_name,real_name_unsafe:$("active").value,type:"static"};var activenum=fs_hasActive();for(var i=fs_data.length;i>activenum;i--)
{fs_data[i]=fs_data[i-1];}
fs_data[activenum]=friendobj;fs_dirty=true;}
fs_superView();}
else if(hasuser)
{if(fs_checkCount(true))
{var friendobj=fs_frienddata[hotnum];friendobj.type="static";var activenum=fs_hasActive();for(var i=fs_data.length;i>activenum;i--)
{fs_data[i]=fs_data[i-1];}
fs_data[activenum]=friendobj;fs_dirty=true;}
fs_superView();}}
function fs_inputOnkeyup(evnt)
{if(evnt.keyCode==13)
{fs_getUser();}
if(evnt.keyCode==27)
{return fs_suggestClose();}
else if(evnt.keyCode==38||evnt.keyCode==40)
{}
else
{fs_ajax_submit();}}
function fs_ajax_submit()
{var url="/interface/suggestfriend.php";var text=encodeURIComponent($("active").value);var pars="text="+text+"&maxnum="+fs_maxnum;if("undefined"!=typeof fs_suggestpars)
{pars+="&pars="+fs_suggestpars;}
var myAjax=new Ajax.Request(url,{method:"get",parameters:pars,onComplete:function(req){fs_ajax_show(req);}});}
var fs_frienddata=[];function fs_ajax_show(req)
{var arr=eval(req.responseText);fs_frienddata=arr;if(arr.length==0)
{$("suggest").style.display="none";$("emptysuggest").style.display="block";if($("active").value=="")
{$("emptysuggest").innerHTML="请输入好友的姓名(支持拼音首字母输入)";}
else
{if(fs_mode==1)
{$("emptysuggest").style.display="none";}
else
{$("emptysuggest").innerHTML="姓名不在好友列表哦，请重新输入";}}
return;}
var html="";for(var i=0;i<arr.length;i++)
{html+='<div id=suggest_'+i+' class="sgt_of" style="width:200px;" onmouseover="fs_suggestOnmouseover(this)" onmousedown="fs_suggestOnmousedown(this);">'+arr[i].real_name+'　'+fs_logo20(arr[i])+'</div>';}
$("suggest").innerHTML=html;$("suggest").style.display="block";$("emptysuggest").style.display="none";if($("suggest_0")!=null&&$("suggest").style.display=="block")
{$("suggest_0").className="sgt_on";}}
function fs_suggestcloseOnMouseover()
{var num=0;while((obj=$("suggest_"+num))!=null)
{if(obj.className=="sgt_on")
{obj.className="sgt_of";}
num++;}}
function fs_suggestClose()
{fs_superView();}
function fs_suggestOnmouseover(thisobj)
{var arr=thisobj.id.split('_');var thisnum=arr[1];var obj;var num=0;while((obj=$("suggest_"+num))!=null)
{if(thisnum==num)
{obj.className="sgt_on";}
else
{obj.className="sgt_of";}
num++;}}
function fs_suggestOnmousedown(thisobj)
{if(fs_checkCount(true))
{var arr=thisobj.id.split('_');var num=arr[1];var friendobj=fs_frienddata[num];friendobj.type="static";var activenum=fs_hasActive();for(var i=fs_data.length;i>activenum;i--)
{fs_data[i]=fs_data[i-1];}
fs_data[activenum]=friendobj;fs_dirty=true;}
if($("active"))
{$("active").value="";}
fs_superView();}
function fs_viewFriend()
{var count=0;var len=fs_allfrienddata.length;for(var i=0;i<len;i++)
{if($("checkbox"+i).checked)
{count++;}}
var confirmret=0;if(count==0||((count>0)&&(confirmret=confirm("切换分组后将清空你刚才勾选的好友，你确定要切换分组吗？"))))
{var url="/interface/suggestfriend.php";var pars="type=all"+"&maxnum="+fs_maxnum;if($("group"))
{pars=pars+"&group="+$("group").value;if($("group").value!="")
{if($(fs_selall))
{$(fs_selall).style.display="inline";}}
else
{if($(fs_selall))
{$(fs_selall).style.display="none";}}}
if("undefined"!=typeof fs_selectpars)
{pars+="&pars="+fs_selectpars;}
var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){fs_ajax_allfriendshow(req);}});$(fs_fsg_nr).style.display="block";$(fs_ptrimg).innerHTML='<img src="http://img1.kaixin001.com.cn/i/xx_xs1.gif" class="cp" onmouseover="this.src=\'http://img1.kaixin001.com.cn/i/xx_xs2.gif\';" onmouseout="this.src=\'http://img1.kaixin001.com.cn/i/xx_xs1.gif\';" alt="选择好友" />';if($("group"))
{fs_gindex=$("group").selectedIndex;}}
else if(!confirmret)
{if($("group"))
{$("group").selectedIndex=fs_gindex;}}}
function fs_viewAllfriend()
{if($(fs_groupsel)&&(!$("group")))
{var url="/interface/fgroup.php";var pars="";var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){fs_ajax_groupshow(req);}});}
if($("suggest"))
{$("suggest").style.display="none";}
if($(fs_fsg_nr).style.display=="block")
{$(fs_fsg_nr).style.display="none";$(fs_ptrimg).innerHTML='<img src="http://img1.kaixin001.com.cn/i/xx_xx1.gif" class="cp" onmouseover="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx2.gif\';" onmouseout="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx1.gif\';" alt="选择好友" />';}
else
{fs_viewFriend();}}
function fs_ajax_groupshow(req)
{var arr=eval(req.responseText);var html='<select id="group" name="group" onchange="fs_viewFriend();">';html=html+'<option value="">全部好友</option>';var len=arr.length;for(var i=0;i<len;i++)
{html=html+' <option value="'+arr[i]+'">'+arr[i]+'</option>';}
html=html+'</select>';$(fs_groupsel).innerHTML=html;}
var fs_allfrienddata=[];function fs_ajax_allfriendshow(req)
{var arr=eval(req.responseText);fs_allfrienddata=arr;var html="";var len=Math.ceil(arr.length/3)*3;for(var i=0;i<len;i++)
{if(i%3==0)
{html+='<div class="sgt_of" style="width:300px;">\n';}
if(arr[i])
{html+='<div class="l" style="width:100px;" title="开心ID：'+arr[i].uid+'"><input id="checkbox'+i+'" type="checkbox" title="开心ID：'+arr[i].uid+'" onclick="fs_countcheck(this);" />'+arr[i].real_name+fs_logo20(arr[i])+'</div>\n';}
if(i%3==2)
{html+='<div class="c"></div>\n';html+='</div>\n';}}
$(fs_allfriend).innerHTML=html;}
function fs_selectAll()
{if(!$(fs_selall))
{return;}
var checked=true;if($(fs_selall))
{checked=true;}
else
{return;}
var len=fs_allfrienddata.length;for(var i=0;i<len;i++)
{if($("checkbox"+i).checked)
{checked=false;}}
len=fs_allfrienddata.length;var need_alert=false;if(len>fs_maxcount)
{len=fs_maxcount;need_alert=true;}
for(var i=0;i<len;i++)
{$("checkbox"+i).checked=checked;}
if(need_alert)
{alert("最多只能选择 "+fs_maxcount+" 位好友！");}}
function fs_countcheck(obj)
{var count=0;var len=fs_allfrienddata.length;for(var i=0;i<len;i++)
{if($("checkbox"+i).checked)
{count++;if(count>fs_maxcount)
{obj.checked=false;alert("最多只能选择 "+fs_maxcount+" 位好友！");break;}}}
return count;}
function fs_selectFriend()
{var len=fs_allfrienddata.length;for(var i=0;i<len;i++)
{if($("checkbox"+i).checked)
{var obj=fs_allfrienddata[i];obj.type="static";if(!fs_checkCount(true))
{break;}
fs_data[fs_data.length]=fs_allfrienddata[i];}}
var fs_data2=[];var j=0;len=fs_data.length;for(var i=0;i<len;i++)
{if(fs_data[i].type=="active")
{continue;}
fs_data2[j]=fs_data[i];j++;}
fs_data=fs_data2;fs_dirty=true;$(fs_fsg_nr).style.display="none";$(fs_ptrimg).innerHTML='<img src="http://img1.kaixin001.com.cn/i/xx_xx1.gif" class="cp" onmouseover="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx2.gif\';" onmouseout="this.src=\'http://img1.kaixin001.com.cn/i/xx_xx1.gif\';" alt="选择好友" />';fs_superView();}
function fs_logo20(obj)
{var logo20="";if(typeof obj.logo20!="undefined")
{logo20="<img src='"+obj.logo20+"'  align=absmiddle width=15  />";}
return logo20;}

function wordSuggest(id,type,width,top,left)
{this.id=id;this.type=type;this.input=$(id+"_"+type);if(!this.input)
{this.input=$(id);}
this.width=width;if(!document.all)
{this.width=this.width+2;}
this.top=top;if(this.top==undefined)
{this.top=23;}
this.left=left;if(this.left==undefined)
{this.left=0;}
var html='<div id="'+this.id+'_suggest" class="sgt_o" style="width:'+this.width+'px; top:'+this.top+'px; left:'+this.left+'px;display:none;z-index:3;"></div>';this.input.parentNode.id=this.id+"_parent";new Insertion.After(this.id+"_parent",html);}
function wordsuggest_inputOnfocus(thisobj,evnt)
{var arr=thisobj.id.split("_");var id=arr[0];var type=arr[1];if(type==undefined)
{type=id;}
thisobj.className='it2';if(thisobj.value=="")
{var namelist={"hometown":"家乡","city":"居住城市","company":"工作单位","school":"大学、中小学、中专等校名","stock":"股票代码或名称拼音首字母","film":"电影名","book":"图书名"};var html='<div id="'+id+'_suggest_word" style="width:'+(parseInt($(id+"_suggest").style.width)-10)+'px; border-bottom:1px solid #eee; padding:0px 5px; color:#666; background:#eee;" >';html+='请输入'+namelist[type];html+='</div>';if(navigator.userAgent.indexOf('MSIE 6')!=-1)html+='<iframe style="position:absolute; visibility:inherit; top:0px; left:0px; width:300px; height:25px; z-index:-1; filter=\'progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)\';" frameborder=0 scrolling=no></iframe>';$(id+"_suggest").style.display="block";$(id+"_suggest").parentNode.style.position="relative";$(id+"_suggest").style.background="#eee";$(id+"_suggest").innerHTML=html;}}
function wordsuggest_inputOnblur(thisobj,evnt)
{var arr=thisobj.id.split("_");var id=arr[0];var type=arr[1];if(type==undefined)
{type=id;}
thisobj.className='it1';h(id+"_suggest");$(id+"_suggest").parentNode.style.position="";}
function wordsuggest_inputOnkeyup(thisobj,evnt)
{var arr=thisobj.id.split("_");var id=arr[0];var type=arr[1];if(type==undefined)
{type=id;}
var suggestid=id+"_suggest";var num=0;var obj;var hotobj="";var hotnum="";while((obj=$(suggestid+"_"+num))!=null)
{if(obj.className=="sgt_on")
{hotobj=obj.id;}
num++;}
if(hotobj!="")
{var arr=hotobj.split('_');hotnum=parseInt(arr[2]);}
if(evnt.keyCode==40)
{if($(id+"_suggest_0")!=null&&$(id+"_suggest").style.display=="block")
{if(hotobj=="")
{$(id+"_suggest_0").className="sgt_on";if('function'==typeof(wordsuggest_seling))
{wordsuggest_seling($(id+"_suggest_0").innerHTML);}
else
{thisobj.value=$(id+"_suggest_0").innerHTML;}}
else
{var nextobj=suggestid+"_"+(hotnum==num-1?0:hotnum+1);$(hotobj).className="sgt_of";$(nextobj).className="sgt_on";if('function'==typeof(wordsuggest_seling))
{wordsuggest_seling($(nextobj).innerHTML);}
else
{thisobj.value=$(nextobj).innerHTML;}}
return false;}}
else if(evnt.keyCode==38)
{if($(id+"_suggest_"+(num-1))!=null&&$(id+"_suggest").style.display=="block")
{if(hotobj=="")
{$(id+"_suggest_"+(num-1)).className="sgt_on";if('function'==typeof(wordsuggest_seling))
{wordsuggest_seling($(id+"_suggest_"+(num-1)).innerHTML);}
else
{thisobj.value=$(id+"_suggest_"+(num-1)).innerHTML;}}
else
{var preobj=suggestid+"_"+(hotnum==0?num-1:hotnum-1);$(hotobj).className="sgt_of";$(preobj).className="sgt_on";if('function'==typeof(wordsuggest_seling))
{wordsuggest_seling($(preobj).innerHTML);}
else
{thisobj.value=$(preobj).innerHTML;}}}}
else if(evnt.keyCode!=9&&evnt.keyCode!=27)
{if(evnt.keyCode==13)
{if($(id+"_suggest").style.display=="block")
{if('function'==typeof(wordsuggest_selafter))
{wordsuggest_selafter($(id+"_suggest_"+hotnum).innerHTML);}
else
{thisobj.value=$(id+"_suggest_"+hotnum).innerHTML;}
$(id+"_suggest").style.display="none";}
else
{wordsuggest_ajax_submit(thisobj.value,id,type);}}
else
{wordsuggest_ajax_submit(thisobj.value,id,type);}}
return false;}
function wordsuggest_inputOnkeydown(thisobj,evnt)
{var arr=thisobj.id.split("_");var id=arr[0];if(evnt.keyCode==13)
{return false;}
else if(evnt.keyCode==9||evnt.keyCode==27)
{$(id+"_suggest").style.display="none";}
return true;}
function wordsuggest_ajax_submit(text,id,type)
{var url="/interface/suggest.php";var puretext=text;var text=encodeURIComponent(text);var pars="text="+text+"&name="+type;var myAjax=new Ajax.Request(url,{method:"get",parameters:pars,onComplete:function(req){wordsuggest_ajax_show(req,id,puretext);}});}
function wordsuggest_ajax_show(req,id,text)
{var arr=eval(req.responseText);if(arr.length==0)
{$(id+"_suggest").style.display="none";return;}
if(arr.length==1&&arr[0]==text)
{$(id+"_suggest").style.display="none";return;}
$(id+"_suggest").style.display="block";$(id+"_suggest").parentNode.style.position="relative";$(id+"_suggest").style.background="#fff";var html="";for(var i=0;i<arr.length;i++)
{html+='<div id="'+id+'_suggest_'+i+'" class="sgt_of" style="width:'+(parseInt($(id+"_suggest").style.width)-10)+'px" onmouseover="javascript:return wordsuggest_suggestOnmouseover(this);" onmousedown="javascript:wordsuggest_suggestOnclick(this);">'+arr[i]+'</div>';}
html+='<iframe src="javascript:false" style="position:absolute; visibility:inherit; top:0px; left:0px; width:300px; height:'+(arr.length*23+23)+'px; z-index:-1; filter=\'progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)\';" frameborder=0></iframe>';$(id+"_suggest").innerHTML=html;if($(id+"_suggest_0")!=null&&$(id+"_suggest").style.display=="block")
{$(id+"_suggest_0").className="sgt_on";}}
function wordsuggest_suggestOnclick(thisobj)
{var objid=thisobj.id;var arr=objid.split('_');var id=arr[0];if('function'==typeof(wordsuggest_selafter))
{wordsuggest_selafter(thisobj.innerHTML);}
else
{var childNodes=extractNodes(thisobj.parentNode.parentNode);childNodes=extractNodes(childNodes[0]);childNodes[0].value=thisobj.innerHTML;}
$(id+"_suggest").style.display="none";return false;}
function wordsuggest_suggestOnmouseover(thisobj)
{var objid=thisobj.id;var arr=objid.split('_');var id=arr[0];var suggestid=arr[0]+'_'+arr[1];var objnum=arr[2];var num=0;var obj;while((obj=$(suggestid+"_"+num))!=null)
{obj.className="sgt_of";num++;}
thisobj.className="sgt_on";return false;}