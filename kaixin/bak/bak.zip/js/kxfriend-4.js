

function af_addfriend(v_uid,v_privacy,v_gender,v_isfriend,v_option)
{if(typeof(v_option)=="undefined"||v_option=="")
{v_option="";}
else
{v_option="&"+v_option;}
var ta=(v_gender=="0")?"他":"她";var title="请求加"+ta+"为好友";if(v_privacy==2)
{title="请求成为粉丝";}
var width=430;var height=280;if(v_isfriend==1||v_isfriend==3)
{width=330;height=150;}
else if(v_privacy>0)
{width=480;height=260;}
openWindow("/friend/new.php?touid="+v_uid+v_option,width,height,title);}
function af_addverify_do(v_touid,v_content,v_rcode,v_code,v_usercode,v_email)
{if(v_content.length==0)
{alert("请输入好友请求附言！");return false;}
if(v_rcode!=undefined&&v_rcode.length>0&&v_code.length==0)
{alert("请输入验证码！");return false;}
document.addverifyform.touid.value=v_touid;document.addverifyform.content.value=v_content;document.addverifyform.rcode.value=v_rcode;document.addverifyform.code.value=v_code;document.addverifyform.usercode.value=v_usercode;document.addverifyform.email.value=v_email;document.addverifyform.submit();}
function af_delfriend(v_uid,v_start,v_privacy,v_callback)
{var title="删除好友";if(v_privacy!=undefined&&v_privacy==2)
{title="断开粉丝";}
af_delfriend_do.callback=v_callback;openWindow('/friend/del_dialog.php?touid='+v_uid+'&start='+v_start,440,230,title);}
function af_delfriend_do(v_uid,v_start)
{if(typeof(af_delfriend_do.callback)!="function")
{document.delfriendform.touid.value=v_uid;document.delfriendform.start.value=v_start;document.delfriendform.ref.value=window.location;document.delfriendform.submit();}
else
{var pars="touid="+encodeURIComponent(v_uid)+"&start="+encodeURIComponent(v_start)+"&ref="+encodeURIComponent(window.location)+"&ajax=1";var myAjax=new Ajax.Request("/friend/del.php",{method:"post",parameters:pars,onComplete:function(req){af_delfriend_do.callback(req);}});}}
function af_addform(uri)
{document.write('<div>');document.write('<form name=addverifyform action="/friend/addverify.php" method=post>');document.write('<input type=hidden name=from value="'+uri+'">');document.write('<input type=hidden name=touid value="">');document.write('<input type=hidden name=content value="">');document.write('<input type=hidden name=rcode value="">');document.write('<input type=hidden name=code value="">');document.write('<input type=hidden name=usercode value="">');document.write('<input type=hidden name=email value="">');document.write('<input type=hidden name=bidirection value="">');document.write('</form>');document.write('</div>');}
function af_editFriend(v_fuid)
{openWindow('/friend/editfriend_dialog.php?from=self&fuid='+v_fuid,350,350,'好友属性');}

function a_appfriend_show(aid,appurl,appname)
{a_appfriend_hidden();var url="/interface/appfriend.php";var text=encodeURIComponent(text);var pars="aid="+aid;if(-1==appurl.indexOf('?'))
{appurl=appurl+'?';}
var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){a_appfriend_ajaxshow(req,aid,appurl,appname);}});}
function a_appfriend_ajaxshow(req,aid,appurl,appname)
{r=req.responseText;eval("r="+r);var html='<div style="border:1px solid #CFCFCF;padding:5px;*height:238px;"><div><div class="l">好友的'+appname+'&nbsp：</div><div class="r"><a href="javascript:a_appfriend_hidden();"><img src="http://img1.kaixin001.com.cn/i2/shut.gif" width="8" height="7" alt="关闭" align="absmiddle" /></a></div><div class="c" style="height:1px;"></div></div>';html+='<div style="height:219px; overflow:scroll; overflow-x:hidden;">';for(var i=0;i<r.length;i++)
{html+='<div class="bb1d8"><a  style="cursor:pointer;" class="sl2_r" href="'+appurl+'&uid='+r[i].uid+'"><div class="l" style="width:5em;">'+r[i].name+'</div><div class="l" style="width:3em;">'+'('+r[i].index_num+')</div><div class="l" style="width:2em;">'+'&gt;&gt;</div><div class="c"></div></a>'+'</div>';}
if(r.length==0)
{html+='<div class="p5 c9">你的好友还没有添加过该组件</div>';}
html+='</div></div>';$("app_friend_tip").innerHTML=html;$("app_friend_tip").style.display="block";var pos=getpos($("app_friend_"+aid));$("app_friend_tip").style.left=parseInt(pos.left)+"px";$("app_friend_tip").style.top=parseInt(pos.bottom+2)+"px";}
function a_appfriend_hidden()
{$("app_friend_tip").innerHTML="";$("app_friend_tip").style.display="none";}

function addallfriendShowEx(req)
{if(g_listcount)
{s("addfrienddiv2");}
else
{s("addfrienddiv1");}
addfriendskip();}
function addfriendskip()
{h("reguserdiv");if(g_listcount)
{s("listdiv");}}
function accountAjaxShow(res)
{h("gettingdiv");h("gettingdiv1");if(res=="error")
{h("getempty");s("geterror");}
else if(res=="empty")
{h("geterror");s("getempty");}
else
{eval("r="+res);if($("postofficename1")&&$("postofficename2")&&$("postofficename3")&&$("postofficename4"))
{$("postofficename1").innerHTML=r.postoffice;$("postofficename2").innerHTML=r.postoffice;$("postofficename3").innerHTML=r.postoffice;$("postofficename4").innerHTML=r.postoffice;}
g_listcount=r.list.length;var html="<div style=\"width:500px;\"><div class=\"it_s\"><div class=\"it2 xzhy\" style=\"margin:0px\">";$("regusercount").innerHTML=r.reg.length;html+="<div class=\"xzhy_t\"><input type=checkbox onclick=\"javascript:selallreguid(this);\" checked>全选</div>";for(i=0;i<r.reg.length;i++)
{html+=getreguserhtml(r.reg[i],i);}
html+="</div></div></div>";html+="<div class=\"mt5 c\"><div class=\"l\"><span class=\"rbs1\"><input type=\"button\" value=\"加为好友\"  class=\"rb1-12\" onmouseover=\"this.className='rb2-12';\" onmouseout=\"this.className='rb1-12';\" onclick=\"javascript:addallfriend('"+g_gid+"');\" /></span></div><div class=\"flw5\">&nbsp;</div> ";if(r.list.length)
{html+="<div class=\"l\"><span class=\"gbs1\"><input type=\"button\"  value=\" 跳过 \" class=\"gb1-12\" onmouseover=\"this.className='gb2-12';\" onmouseout=\"this.className='gb1-12';\" onclick=\"javascript:addfriendskip();\" /></span></div><div class=\"c\"></div></div>";}
else
{html+="<div class=\"l\"><span class=\"gbs1\"><input type=\"button\"  value=\" 取消 \" class=\"gb1-12\" onmouseover=\"this.className='gb2-12';\" onmouseout=\"this.className='gb1-12';\" onclick=\"javascript:window.location='/friend/invite.php?group="+encodeURIComponent(g_groupname)+"&gid="+v_gid+"';\" /></span></div><div class=\"c\"></div></div>";}
$("reguserhtml").innerHTML=html;html="<div style=\"width:500px;\"><div class=\"it_s\"><div class=\"it2 xzhy\">";html+="<div class=\"xzhy_t\"><input type=checkbox onclick=\"javascript:selallemail(this);\" "+(g_checkemail?"checked":"")+">全选</div>";for(i=0;i<r.list.length;i++)
{if(i%2==0)
{html+="<div class=\"xzhy1\"><p class=\"yx_l\"><input type=checkbox name=email value='"+r.list[i].email+"' "+(g_checkemail?"checked":"")+"> "+r.list[i].nick+"</p><p class=\"l\">&lt;"+r.list[i].email+"&gt;</p><p class=\"c\"></p></div>";}
else
{html+="<div class=\"xzhy2\"><p class=\"yx_l\"><input type=checkbox name=email value='"+r.list[i].email+"' "+(g_checkemail?"checked":"")+"> "+r.list[i].nick+"</p><p class=\"l\">&lt;"+r.list[i].email+"&gt;</p><p class=\"c\"></p></div>";}}
html+="</div></div></div>";$("checkdiv").innerHTML=html;if(r.reg.length)
{s("listuser1");}
else
{s("listuser2");}
if(r.list.length)
{s("reguser1");}
else
{s("reguser2");}
if(r.reg.length)
{s("reguserdiv");}
else
{s("listdiv");}
h("getdiv");s("showdiv");}}
function getreguserhtml(reguser,i)
{var html='';if(i%2==0)
{html+='<div class="l xzhy1" style="width:590px;padding:10px 0;">';}
else
{html+='<div class="l xzhy2" style="width:590px;padding:10px 0;">';}
html+='<div class="l">'+'<div class=l><input type=checkbox name=reguid value="'+reguser.uid+'" checked></div>'+'<div class="l50_s"><a target="_blank" href="/home/?uid='+reguser.uid+'" title="'+reguser.real_name+'"><img src="'+reguser.icon+'" border=0></a></div>'+'</div>'+'<div class="l">'+'<div>'+'<p class="l">'+reguser.online+' '+' <a  target="_blank" href="/home/?uid='+reguser.uid+'" class="sl" title="'+reguser.real_name+'" >'+reguser.real_name+'</a><br /> '+(parseInt(reguser.gender)?'女&nbsp;':'男&nbsp;')+reguser.city+'</p>'+'<div class="c"></div>'+'</div>'+'</div>'+'<div class="c"></div>'+'</div>'+'<div class="c"></div>';return html;}
function addallfriend(v_gid)
{var uids="";if("undefined"!=typeof(document.reguidform.reguid))
{if("undefined"!=typeof(document.reguidform.reguid.length))
{for(i=0;i<document.reguidform.reguid.length;i++)
{if(document.reguidform.reguid[i].checked)
{uids+=document.reguidform.reguid[i].value+" ";}}}
else
{if(document.reguidform.reguid.checked)
{uids+=document.reguidform.reguid.value;}}}
if(uids.length==0)
{alert("请选择要添加的用户！");return;}
var url="/friend/addusers.php";var pars="uids="+uids+"&gid="+v_gid;var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){addallfriendShow(req);}});}
function invite_do()
{var emails="";if("undefined"!=typeof(document.listform.email))
{if("undefined"!=typeof(document.listform.email.length))
{for(i=0;i<document.listform.email.length;i++)
{if(document.listform.email[i].checked)
{emails+=document.listform.email[i].value+" ";}}}
else
{if(document.listform.email.checked)
{emails+=document.listform.email.value;}}}
document.inviteform.real_name.value=document.listform.real_name.value;document.inviteform.content.value=document.listform.content.value;document.inviteform.group.value=document.listform.group.options[document.listform.group.selectedIndex].value;document.inviteform.emails.value=emails;if(document.inviteform.emails.value.length==0)
{alert("请选择邀请对象");return;}
if(document.inviteform.group.value.length==0)
{alert("请选择好友分组！");return;}
if(document.inviteform.real_name.value.length==0)
{alert("请输入你的真实姓名！");document.listform.real_name.focus();return;}
var url="/interface/checkname.php";var pars="real_name="+encodeURIComponent(document.inviteform.real_name.value);var myAjax=new Ajax.Request(url,{method:"post",parameters:pars,onComplete:function(req){checkinviteformShow(req);}});}
function checkinviteformShow(req)
{var r=req.responseText;r=parseInt(r);if(r)
{document.inviteform.submit();}
else
{if(confirm("这个好像不是真实姓名吧？！\n 如果确认要使用这个姓名邀请，请点击确认按钮"))
{document.inviteform.submit();}
else
{if(document.listform)
{document.listform.real_name.focus();}
else
{document.inviteform.real_name.focus();}}}}
function selallemail(v_check)
{if("undefined"!=typeof(document.listform.email))
{if("undefined"!=typeof(document.listform.email.length))
{for(i=0;i<document.listform.email.length;i++)
{document.listform.email[i].checked=v_check.checked;}}
else
{document.listform.email.checked=v_check.checked;}}}
function selallreguid(v_check)
{if("undefined"!=typeof(document.reguidform.reguid))
{if("undefined"!=typeof(document.reguidform.reguid.length))
{for(i=0;i<document.reguidform.reguid.length;i++)
{document.reguidform.reguid[i].checked=v_check.checked;}}
else
{document.reguidform.reguid.checked=v_check.checked;}}}
function addgroup(v_from)
{openWindow('/friend/addgroup_dialog.php?from='+v_from,330,160,'添加好友分组');}
function addgroup_ok(v_group)
{var len=$("groupsel").options.length;var i;for(i=0;i<len;i++)
{if($("groupsel").options[i].value==v_group)
{break;}}
if(i<len)
{$("groupsel").options[i].selected=true;}
else
{var oOption=document.createElement("OPTION");$("groupsel").options.add(oOption);oOption.text=v_group;oOption.value=v_group;oOption.selected=true;}}