﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class admin_login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        check ck = new check();
        string username = FormsAuthentication.HashPasswordForStoringInConfigFile(ck.CheckInput(txtName.Text.ToString()), "MD5");
        string password = FormsAuthentication.HashPasswordForStoringInConfigFile(ck.CheckInput(txtPass.Text.ToString()), "MD5");
        data_conn cn = new data_conn();
        DataSet ds = new DataSet();
        string sql = "";

        //定义SQL语句，查询某一用户发布的3种运价及货盘各自的总数
        sql = sql + "SELECT * FROM ALLIN_SUPER ";
        sql = sql + "WHERE ALLIN_SUPER_CALL = '" + username + "' ";
        sql = sql + "AND ALLIN_SUPER_THEKEY = '" + password + "' ";
        ds = cn.mdb_ds(sql, "count");

        if (ds.Tables["count"].Rows.Count > 0)
        {
            Response.Cookies["admin"].Value = "yes";
            Response.Redirect("/admin/");
        }
        else 
        {
            Response.Cookies["admin"].Value = "no";
            Response.Redirect("/admin/");
            MessageBox("error", "用户名或密码错误");
        }
    }

    protected void MessageBox(string strKey, string strInfo)
    {

        if (!this.Page.ClientScript.IsClientScriptBlockRegistered(strKey))
        {
            string strjs = "alert('" + strInfo + "');";
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), strKey, strjs, true);
        }
    }
}
